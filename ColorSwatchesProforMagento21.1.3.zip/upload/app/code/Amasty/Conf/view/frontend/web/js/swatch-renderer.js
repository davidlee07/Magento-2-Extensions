define(
[
    'jquery',
    'Magento_Catalog/js/price-utils',
    'Magento_Catalog/js/price-box',
    'magento-swatch.renderer'
],
function ($ ,utils) {
    'use strict';

    $.widget('amasty_conf.SwatchRenderer', $.mage.SwatchRenderer, {

        _init: function () {
            if (this.options.jsonConfig !== '' && this.options.jsonSwatchConfig !== '') {
                this._sortAttributes();
                this._RenderControls();

                var isProductViewExist = $('body.catalog-product-view').size() > 0;
                if (isProductViewExist) {
                    this._RenderPricesForControls();
                }
            } else {
                console.log('SwatchRenderer: No input data received');
            }
        },

        _EventListener: function () {
            this.amasty_conf_config = window.amasty_conf_config;
            var $widget = this;

            if(this.amasty_conf_config.share.enable == '1') {
                $widget.element.on('click', '.' + this.options.classes.optionClass, function () {
                    return $widget._AmOnClick($(this), $widget);
                });

                this._createShareBlock()
            }
            else{
                $widget.element.on('click', '.' + this.options.classes.optionClass, function () {
                    return $widget._OnClick($(this), $widget);
                });
            }

            $widget.element.on('change', '.' + this.options.classes.selectClass, function () {
                return $widget._OnChange($(this), $widget);
            });

            $widget.element.on('click', '.' + this.options.classes.moreButton, function (e) {
                e.preventDefault();

                return $widget._OnMoreClick($(this));
            });
        },

        _createShareBlock: function () {
            var parent = $('.product-social-links');
            var link = jQuery('<a/>', {
                class: 'action share amasty_conf mailto friend',
                title: this.amasty_conf_config.share.title,
                text: this.amasty_conf_config.share.title
            }).appendTo(parent);

            link.on('click', function () {
                $('.amconf-share-container').toggle();
            });

            var container = jQuery('<div/>', {
                class: 'amconf-share-container'
            }).appendTo(parent);

            var input = jQuery('<input/>', {
                class: 'amconf-share-input',
                type: 'text'
            }).appendTo(container);

            var button = jQuery('<button/>', {
                class: 'amconf-share-buton action primary',
                html: '<span>' + this.amasty_conf_config.share.link + '</span>'
            }).appendTo(container);

            button.on('click', function () {
                $('.amconf-share-input').select();
                var status = document.execCommand('copy');
                if(!status){
                    console.error("Can't copy text");
                }
            });
        },

        _AmOnClick: function ($this, $widget) {
            $widget._OnClick($this, $widget);

            $widget._addHashToUrl($this, $widget);
            $widget._reloadProductInformation($this, $widget);
        },

        _addHashToUrl: function ($this, $widget) {
            var addParamsToHash = 1,
                isProductViewExist = $('body.catalog-product-view').size() > 0,
                attributeCode = $this.parents('.' + this.options.classes.attributeClass).attr('attribute-code'),
                optionId = $this.attr('option-id');

            if (addParamsToHash && isProductViewExist){
                var hash = window.location.hash;
                if (hash.indexOf(attributeCode + '=') >= 0) {
                    var replaceText = new RegExp(attributeCode + '=' + '.*');
                    if(optionId) {
                        hash = hash.replace(replaceText, attributeCode + '=' + optionId);
                    }
                    else{
                        hash = hash.replace(replaceText, "");
                    }
                }
                else {
                    if (hash.indexOf('#') >= 0) {
                        hash = hash + '&' + attributeCode + '=' + optionId;
                    }
                    else {
                        hash = hash + '#' + attributeCode + '=' + optionId;
                    }
                }

                window.location.replace(window.location.href.split('#')[0] + hash);
                $('.amconf-share-input').prop('value', window.location);
            }

            if(!isProductViewExist) {
                var parent = $widget.element.parents('.item');
                if (parent.length > 0) {
                    var productLinks = parent.find('a:not([href^="#"]):not([data-post*="action"]):not([href*="#reviews"])');
                    $.each(productLinks, function(i, link ) {
                        link = $(link);
                        var href = link.prop('href');
                        if (href.indexOf(attributeCode + '=') >= 0) {
                            var replaceText = new RegExp(attributeCode + '=' + '\\d+');
                            href = href.replace(replaceText, attributeCode + '=' + optionId)
                            link.prop('href', href);
                        }
                        else {
                            if (href.indexOf('#') >= 0) {
                                link.prop('href', href + '&' + attributeCode + '=' + optionId);
                            }
                            else {
                                link.prop('href', href + '#' + attributeCode + '=' + optionId);
                            }
                        }
                    });
                }
            }
        },

        _reloadProductInformation: function ($this, $widget) {
            var $widget = this,
                options = _.object(_.keys($widget.optionsMap), {});

            if(!$widget.options.jsonConfig.product_information) {
                return;
            }

            $widget.element.find('.' + $widget.options.classes.attributeClass + '[option-selected]').each(function () {
                var attributeId = $(this).attr('attribute-id');
                options[attributeId] = $(this).attr('option-selected');
            });

            var result = $widget.options.jsonConfig.product_information[_.findKey($widget.options.jsonConfig.index, options)],
                defaultResult = $widget.options.jsonConfig.product_information['default'];

            if(result) {
                for(var component in result) {
                    this._updateSimpleData(result[component], defaultResult[component]);
                }
            }
            else {
                for(var component in defaultResult) {
                    this._updateSimpleData(defaultResult[component]);
                }
            }
        },

        _updateSimpleData: function (data, defaultData) {
            if (data && data.selector && data.value) {
                $(data.selector).html(data.value);
            }
            else{
                $(defaultData.selector).html(defaultData.value);
            }
        },

        _RenderPricesForControls: function () {
            var $widget = this;
            if(this.options.jsonConfig.attributes.length != 1 ||
                this.options.jsonConfig.show_prices != 1
            ) {
                return;
            }


            var attributeJson = this.options.jsonConfig.attributes[0];
            $.each(attributeJson.options, function () {
                if (this.products.length > 0) {
                    var price = $widget.optionsMap[attributeJson.id][this.id].price,
                        priceConfig = $('[data-role=priceBox]').priceBox('option').priceConfig,
                        priceFormat = (priceConfig && priceConfig.priceFormat) || {},
                        formatted = utils.formatPrice(price, priceFormat),
                        option = $('.swatch-option[option-id="' + this.id + '"]');
                    if (option.length && formatted) {
                        option.wrap( "<div class='swatch-option-container'></div>" );
                        option.after( '<span class="swatch-option-price">' + formatted + '</span>' );
                        option.css('float', 'none');
                        option.parent().css('float', 'left');
                    }
                }
            });
        }

    });

    return $.amasty_conf.SwatchRenderer;
});
