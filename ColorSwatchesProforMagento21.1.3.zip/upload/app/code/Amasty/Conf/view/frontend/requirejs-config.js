var config = {
    map: {
        '*': {
            'Magento_Swatches/js/swatch-renderer' : 'Amasty_Conf/js/swatch-renderer',
            'magento-swatch.renderer'             : 'Magento_Swatches/js/swatch-renderer'
        }
    }
};
