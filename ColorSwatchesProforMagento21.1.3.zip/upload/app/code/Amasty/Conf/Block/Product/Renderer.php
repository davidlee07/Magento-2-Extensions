<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2017 Amasty (https://www.amasty.com)
 * @package Amasty_Conf
 */

namespace Amasty\Conf\Block\Product;

class Renderer extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Amasty\Conf\Helper\Data
     */
    protected $_helper;
    /**
     * @var \Magento\Framework\Json\EncoderInterface
     */
    protected $jsonEncoder;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        array $data = [],
        \Amasty\Conf\Helper\Data $helper,
        \Magento\Framework\Json\EncoderInterface $jsonEncoder
    ) {
        parent::__construct($context, $data);

        $this->_helper = $helper;
        $this->_scopeConfig = $context->getScopeConfig();
        $this->setTemplate('Amasty_Conf::product/view/renderer.phtml');
        $this->jsonEncoder = $jsonEncoder;
    }

    /**
     * @return \Amasty\Conf\Helper\Data
     */
    public function getHelper() {
        return $this->_helper;
    }

    /**
     * @return string
     */
    public function getConfig() {
        $config = [
            'share'           =>  [
                'enable' => $this->_helper->getModuleConfig('general/share'),
                'title'  => __('SHARE'),
                'link'   => __('COPY')
            ]
        ];

        return $this->jsonEncoder->encode($config);
    }
}
