<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2017 Amasty (https://www.amasty.com)
 * @package Amasty_Conf
 */
namespace Amasty\Conf\Plugin\Product\View\Type;
use \Magento\ConfigurableProduct\Block\Product\View\Type\Configurable as TypeConfigurable;

class Configurable
{
    /**
     * @var \Amasty\Conf\Helper\Data
     */
    protected $_helper;

    /**
     * @var \Magento\Framework\View\LayoutFactory
     */
    protected $layoutFactory;
    /**
     * @var \Magento\Framework\Json\EncoderInterface
     */
    protected $jsonEncoder;
    /**
     * @var \Magento\Framework\Json\Decoder
     */
    protected $jsonDecoder;
    /**
     * @var \Magento\Catalog\Helper\Output
     */
    protected $output;
    /**
     * @var \Magento\Framework\Registry
     */
    private $_coreRegistry;

    public function __construct(
        \Amasty\Conf\Helper\Data $helper,
        \Magento\Framework\View\LayoutFactory $layoutFactory,
        \Magento\Framework\Json\EncoderInterface $jsonEncoder,
        \Magento\Framework\Json\Decoder $jsonDecoder,
        \Magento\Framework\Registry $registry,
        \Magento\Catalog\Helper\Output $output
    ) {
        $this->_helper = $helper;
        $this->layoutFactory = $layoutFactory;
        $this->jsonEncoder = $jsonEncoder;
        $this->jsonDecoder = $jsonDecoder;
        $this->output = $output;
        $this->_coreRegistry = $registry;
    }

    /**
     * @param TypeConfigurable $subject
     * @param $result
     * @return string
     */
    public function afterGetJsonConfig(
        TypeConfigurable $subject,
        $result
    ) {
        if ($result &&
            $subject->getNameInLayout() == 'product.info.options.swatches'
        ) {
            $config = $this->jsonDecoder->decode($result);
            $config['product_information'] = $this->_getProductsInformation($subject);
            $config['show_prices'] = $this->_helper->getModuleConfig('general/show_price');

            $result = $this->jsonEncoder->encode($config);
        }

        return $result;
    }

    /**
     * @param TypeConfigurable $subject
     * @return array
     */
    protected function _getProductsInformation(TypeConfigurable $subject)
    {
        $info = [];
        $reloadValues = $this->_helper->getModuleConfig('reload/content');
        if ($reloadValues && strpos($reloadValues, 'none') === false) {
            $reloadValues = explode(',', $reloadValues);

            $info['default'] = $this->_getProductInfo($subject->getProduct(), $reloadValues);
            foreach ($subject->getAllowProducts() as $product) {
                $info[$product->getId()] = $this->_getProductInfo($product, $reloadValues);
            }
        }

        return $info;
    }

    /**
     * @param $product
     * @param $reloadValues
     * @param $block
     * @return array
     */
    protected function _getProductInfo($product, $reloadValues)
    {
        $productInfo = [];

        $layout = $this->layoutFactory->create();
        foreach ($reloadValues as $reloadValue) {
            $selector  = $this->_helper->getModuleConfig('reload/' . $reloadValue);
            if (!$selector) {
                continue;
            }
            if ($reloadValue == 'attributes') {
                $block = $layout->createBlock(
                    'Magento\Catalog\Block\Product\View\Attributes',
                    'product.attributes',
                    [ 'data' => [] ]
                )->setTemplate('product/view/attributes.phtml');

                $currentProduct = $this->_coreRegistry->registry('product');
                $this->_coreRegistry->unregister('product');
                $this->_coreRegistry->register('product', $product);

                $value = $block->setProduct($product)->toHtml();

                $this->_coreRegistry->unregister('product');
                $this->_coreRegistry->register('product', $currentProduct);
            } else {
                $value = $this->output->productAttribute($product, $product->getData($reloadValue), $reloadValue);
            }
            if ($value) {
                $productInfo[$reloadValue] = [
                    'selector'  => $selector,
                    'value'     => $value
                ];
            }
        }

        return $productInfo;
    }
}
