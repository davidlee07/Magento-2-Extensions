<?php

namespace Dotdigitalgroup\Email\Controller\Adminhtml\Cron;

class Grid extends Index
{
    /**
     * @return $this
     */
    public function setPageData()
    {
        return $this;
    }
}
