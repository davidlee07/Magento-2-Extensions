<?php

namespace Dotdigitalgroup\Email\Controller\Adminhtml\Rules;

class Grid extends Index
{
    /**
     * Set page data.
     *
     * @return $this
     */
    public function setPageData()
    {
        return $this;
    }
}
