<?php
/**
 * @author Plumslice Team
 * @copyright Copyright (c) 2016 Plumslice (http://www.plumslice.com)
 * @package Plumslice_Api
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Plumslice_Api',
    __DIR__
);