<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2017 Amasty (https://www.amasty.com)
 * @package Amasty_Notfound
 */  
class Amasty_Notfound_Model_Attempt extends Amasty_Notfound_Model_Abstract
{
    protected $modelName = 'attempt';
}