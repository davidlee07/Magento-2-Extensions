<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2017 Amasty (https://www.amasty.com)
 * @package Amasty_Notfound
 */
class Amasty_Notfound_Adminhtml_Amnotfound_ErrorController extends Amasty_Notfound_Controller_Abstract
{
    protected $_title     = 'System errors';
    protected $_modelName = 'error'; 
}