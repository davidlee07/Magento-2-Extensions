<?php 

namespace J2t\Payplug\Controller\Payment; 


use Magento\Framework\Controller\ResultFactory;
use Magento\Quote\Api\CartManagementInterface;


class Redirect extends \Magento\Framework\App\Action\Action
{
    /**
     * Customer session model
     *
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;
    protected $resultPageFactory;
    protected $_paymentMethod;
    protected $_checkoutSession;
    protected $checkout;
    protected $cartManagement;
    protected $orderRepository;
    protected $_scopeConfig;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Customer\Model\Session $customerSession
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \J2t\Payplug\Model\PaymentMethod $paymentMethod,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        CartManagementInterface $cartManagement
    ) {
        $this->_customerSession = $customerSession;
        parent::__construct($context);
        $this->_paymentMethod = $paymentMethod;
        $this->_checkoutSession = $checkoutSession;
        $this->cartManagement = $cartManagement;
        $this->orderRepository = $orderRepository;
        $this->_scopeConfig = $scopeConfig;
    }

    
    public function execute()
    {
        //$this->_initCheckout();
        //$this->getCheckout()->place($this->getRequest()->getParam('token'));
        $orderId = $this->cartManagement->placeOrder($this->_checkoutSession->getQuote()->getId());
        $order = $this->orderRepository->get($orderId);
        if ($order){
            $order->setState($this->_scopeConfig->getValue('payment/j2tpayplug/new_order_status', \Magento\Store\Model\ScopeInterface::SCOPE_STORE));
            $order->setStatus($this->_scopeConfig->getValue('payment/j2tpayplug/new_order_status', \Magento\Store\Model\ScopeInterface::SCOPE_STORE));
            $order->save();
        }
        
        /*
        // prepare session to success or cancellation page
        $this->_checkoutSession->clearHelperData();

        // "last successful quote"
        $quoteId = $this->_checkoutSession->getQuote()->getId();
        $this->_checkoutSession->setLastQuoteId($quoteId)->setLastSuccessQuoteId($quoteId);

        // an order may be created
        $order = $this->getCheckout()->getOrder();
        if ($order) {
            $this->_checkoutSession->setLastOrderId($order->getId())
                ->setLastRealOrderId($order->getIncrementId())
                ->setLastOrderStatus($order->getStatus());
        }
        */
        
        $url = $this->_paymentMethod->getPayplugCheckoutRedirection();
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setUrl($url);
        return $resultRedirect;
    }
    
    
    /*public function dispatch(RequestInterface $request)
    {
        $url = $this->_paymentMethod->getPayplugCheckoutRedirection();
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setUrl($url);
        return $resultRedirect;
    }*/
}


