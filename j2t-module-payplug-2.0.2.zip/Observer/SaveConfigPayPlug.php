<?php

/**
 *
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace J2t\Payplug\Observer;

use Magento\Framework\Event\ObserverInterface;

class SaveConfigPayPlug implements ObserverInterface {
    
    protected $request;
    protected $_storeInterface;
    protected $_scopeConfig;
    protected $_moduleList;
    protected $curl;
    protected $messageManager;
    const URL_AUTOCONFIG = 'https://www.payplug.fr/portal/ecommerce/autoconfig';
    const URL_AUTOCONFIG_TEST = 'https://www.payplug.fr/portal/test/ecommerce/autoconfig';
    
    public function __construct($eventManager = null)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $this->request = $objectManager->get('Magento\Framework\App\Request\Http');
        $this->_storeInterface = $objectManager->get('Magento\Store\Model\StoreManagerInterface');
        $this->_scopeConfig = $objectManager->get('Magento\Framework\Config\Scope');
        $this->_moduleList = $objectManager->get('Magento\Framework\Module\ModuleList');
        $this->curl = $objectManager->get('Magento\Framework\HTTP\Adapter\Curl');
        $this->messageManager = $objectManager->get('Magento\Framework\Message\ManagerInterface'); 
    }
    
    
    protected function createCertFile($request, $groups, $user, $pass){
        $url = self::URL_AUTOCONFIG;
        if (isset($groups['j2tpayplug']) && isset($groups['j2tpayplug']['fields']) 
                && isset($groups['j2tpayplug']['fields']['sandbox']) && isset($groups['j2tpayplug']['fields']['sandbox']['value'])
                && $groups['j2tpayplug']['fields']['sandbox']['value']){
            $url = self::URL_AUTOCONFIG_TEST;
        }
        
        $process = curl_init($url);

        curl_setopt($process, CURLOPT_USERPWD, $user.':'.$pass);
        curl_setopt($process, CURLOPT_RETURNTRANSFER, TRUE);
        //curl_setopt($process, CURLOPT_SSLVERSION, 3);
        curl_setopt($process, CURLOPT_SSL_VERIFYPEER, false);
        $answer = curl_exec($process);

        $errorCurl = curl_errno($process);

        curl_close($process);
        if($errorCurl == 0) {
            $jsonAnswer = json_decode($answer);
            $authorizationSuccess = false;
            if ($jsonAnswer->status == 200) {
                $authorizationSuccess = true;
                //$payplug_install = new InstallPayplug();
                if (!is_array($jsonAnswer->currencies)){
                    $currencies = implode(json_decode($jsonAnswer->currencies), ';');
                }
                else {
                    $currencies = $jsonAnswer->currencies[0];
                }
                
                if (isset($groups['j2tpayplug']) && isset($groups['j2tpayplug']['fields'])){
                    $groups['j2tpayplug']['fields']['private_key'] = array('value' => $jsonAnswer->yourPrivateKey);
                    $groups['j2tpayplug']['fields']['public_key'] = array('value' => $jsonAnswer->payplugPublicKey);
                    $groups['j2tpayplug']['fields']['module_url'] = array('value' => $jsonAnswer->url);
                    $groups['j2tpayplug']['fields']['min_amount'] = array('value' => $jsonAnswer->amount_min);
                    $groups['j2tpayplug']['fields']['max_amount'] = array('value' => $jsonAnswer->amount_max);
                    $groups['j2tpayplug']['fields']['currencies'] = array('value' => $currencies);
                    //$request->setPost('groups', $groups);
                    $request->setPostValue('groups', $groups);
                    //var_dump($request->getPost('groups')['j2tpayplug']);
                    //die;
                }
            } else {
                if (isset($groups['j2tpayplug']) && isset($groups['j2tpayplug']['fields'])){
                    $groups['j2tpayplug']['fields']['private_key'] = array('value' => "");
                    $groups['j2tpayplug']['fields']['public_key'] = array('value' => "");
                    $groups['j2tpayplug']['fields']['module_url'] = array('value' => "");
                    $groups['j2tpayplug']['fields']['min_amount'] = array('value' => "");
                    $groups['j2tpayplug']['fields']['max_amount'] = array('value' => "");
                    $groups['j2tpayplug']['fields']['currencies'] = array('value' => "");
                    //$request->setPost('groups', $groups);
                    $request->setPostValue('groups', $groups);
                }
                $this->messageManager->addError(__("Unable to retrieve account details."));
            }
            //$this->assign_context_for_PS_VERSION ('authorizationSuccess', $authorizationSuccess);
        } else {
            if (isset($groups['j2tpayplug']) && isset($groups['j2tpayplug']['fields'])){
                $groups['j2tpayplug']['fields']['private_key'] = array('value' => "");
                $groups['j2tpayplug']['fields']['public_key'] = array('value' => "");
                $groups['j2tpayplug']['fields']['module_url'] = array('value' => "");
                $groups['j2tpayplug']['fields']['min_amount'] = array('value' => "");
                $groups['j2tpayplug']['fields']['max_amount'] = array('value' => "");
                $groups['j2tpayplug']['fields']['currencies'] = array('value' => "");
                //$request->setPost('groups', $groups);
                $request->setPostValue('groups', $groups);
            }
            $this->messageManager->addError(__("CURL error %1", $errorCurl));
        }
    }

    public function execute(\Magento\Framework\Event\Observer $observer) {
        
        $controller = $observer->getControllerAction();
        $groups = $observer->getControllerAction()->getRequest()->getPost('groups');
        
        //$this->request->getParam('section')
        
        if (isset($groups['j2tpayplug'])
                && isset($groups['j2tpayplug']['fields']) && isset($groups['j2tpayplug']['fields']['user'])
                && isset($groups['j2tpayplug']['fields']['pwd']) && isset($groups['j2tpayplug']['fields']['user']['inherit'])
                && isset($groups['j2tpayplug']['fields']['pwd']['inherit'])){
            $groups['j2tpayplug']['fields']['private_key'] = array('inherit' => '1');
            $groups['j2tpayplug']['fields']['public_key'] = array('inherit' => '1');
            $groups['j2tpayplug']['fields']['module_url'] = array('inherit' => '1');
            $groups['j2tpayplug']['fields']['min_amount'] = array('inherit' => '1');
            $groups['j2tpayplug']['fields']['max_amount'] = array('inherit' => '1');
            $groups['j2tpayplug']['fields']['currencies'] = array('inherit' => '1');
            //$observer->getControllerAction()->getRequest()->setPost('groups', $groups);
            $observer->getControllerAction()->getRequest()->setPostValue('groups', $groups);
        } 
        
        if (isset($groups['j2tpayplug'])
                && isset($groups['j2tpayplug']['fields']) && isset($groups['j2tpayplug']['fields']['user'])
                && isset($groups['j2tpayplug']['fields']['pwd']) && (isset($groups['j2tpayplug']['fields']['user']['inherit'])
                || isset($groups['j2tpayplug']['fields']['pwd']['inherit']))){
            throw new \RuntimeException("Both username and password must be defined.");
        } else if (isset($groups['j2tpayplug'])
                && isset($groups['j2tpayplug']['fields']) && isset($groups['j2tpayplug']['fields']['user'])
                && isset($groups['j2tpayplug']['fields']['pwd']) && isset($groups['j2tpayplug']['fields']['user']['value'])
                && isset($groups['j2tpayplug']['fields']['pwd']['value'])
                && ($user = $groups['j2tpayplug']['fields']['user']['value']) && ($pwd = $groups['j2tpayplug']['fields']['pwd']['value'])
                && $pwd != "******"){
            $this->createCertFile($observer->getControllerAction()->getRequest(), $groups, $user, $pwd);
        }
    }

}
