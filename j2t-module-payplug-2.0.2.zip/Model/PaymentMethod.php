<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace J2t\Payplug\Model;

use Magento\Quote\Api\Data\CartInterface;
use Magento\Payment\Model\Method\AbstractMethod;
use Magento\Sales\Model\Order;

class PaymentMethod extends AbstractMethod
{
    const CODE = 'j2tpayplug';
 
    protected $_code = self::CODE;
    
    protected $_isInitializeNeeded      = true;
    //protected $_formBlockType = 'j2tpayplug/form';
    //protected $_infoBlockType = 'j2tpayplug/info';
    
    protected $_formBlockType = 'J2t\Payplug\Block\Form';
    protected $_infoBlockType = 'J2t\Payplug\Block\Info';
 
    protected $_isGateway                   = false;
    protected $_canAuthorize                = false;
    protected $_canCapture                  = false;
    protected $_canCapturePartial           = false;
    protected $_canRefund                   = false;
    protected $_canRefundInvoicePartial     = false;
    protected $_canVoid                     = false;
    protected $_canUseInternal              = false;
    protected $_canUseCheckout              = true;
    protected $_canUseForMultishipping      = false;
    protected $_canSaveCc                   = false;
    
    protected $urlBuilder;
    protected $_moduleList;
    protected $checkoutSession;
    protected $_orderFactory;
 
    
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        \Magento\Payment\Helper\Data $paymentData,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Payment\Model\Method\Logger $logger,
        \Magento\Framework\Module\ModuleListInterface $moduleList,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Framework\Url $urlBuilder,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []){
        $this->urlBuilder = $urlBuilder;
        $this->_moduleList = $moduleList;
        $this->checkoutSession = $checkoutSession;
        $this->_orderFactory = $orderFactory;
        parent::__construct($context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $logger,
            $resource,
            $resourceCollection,
            $data);
    }
    
    public function canUseForCurrency($currencyCode)
    {
        return $this->getConfigData('currencies') == $currencyCode;
        //return Mage::getStoreConfig('payment/j2tpayplug/currencies', $this->getQuote()->getStoreId()) == $currencyCode;
        
    }
    
    public function initialize($paymentAction, $stateObject)
    {
        $payment = $this->getInfoInstance();
        //$order = $payment->getOrder();

        $state = $this->getConfigData('new_order_status');

        //$state = Mage_Sales_Model_Order::STATE_PENDING_PAYMENT;
        $stateObject->setState($state);
        $stateObject->setStatus('pending_payment');
        $stateObject->setIsNotified(false);
    }
   
    public function getPayplugCheckoutRedirection()
    {
        $orderIncrementId = $this->checkoutSession->getLastRealOrderId();
        $order = $this->_orderFactory->create()->loadByIncrementId($orderIncrementId);

        $url_payment = $this->getConfigData('module_url');
        
        $moduleDetails = $this->_moduleList->getOne('J2t_Payplug');
        $version = $moduleDetails['setup_version'];
        $params = array(
            'amount'        =>  ($order->getBaseGrandTotal()*100),
            'custom_data'   =>  $order->getStoreId(),
            'origin'        =>  'Magento  '.\Magento\Framework\AppInterface::VERSION.' module '.$version,
            'currency'      =>  $order->getOrderCurrencyCode(),
            'ipn_url'       =>  $this->urlBuilder->getUrl('j2tpayplug/payment/ipn'),
            'cancel_url'    =>  $this->urlBuilder->getUrl('j2tpayplug/payment/cancel'),
            'return_url'    =>  $this->urlBuilder->getUrl('checkout/onepage/success'),
            'email'         =>  $order->getCustomerEmail(),
            'firstname'     =>  $order->getCustomerFirstname(),
            'lastname'      =>  $order->getCustomerLastname(),
            'first_name'     =>  $order->getCustomerFirstname(),
            'last_name'      =>  $order->getCustomerLastname(),
            //'order'         =>  $this->getQuote()->getId(),
            'order'         =>  $orderIncrementId,
            'customer'      =>  $order->getCustomerId()
        );

        if($this->getConfigData('sandbox')){
            $params['is_test'] = 'true';
        }
        
        $url_params = http_build_query($params);
        
        $privatekey = $this->getConfigData('private_key');
        openssl_sign($url_params, $signature, $privatekey, $signature_alg = OPENSSL_ALGO_SHA1);
        $url_param_base_encode = base64_encode($url_params);
        $signature = base64_encode($signature);
        $redirect_url = $url_payment."?data=".urlencode($url_param_base_encode)."&sign=".urlencode($signature);

        return $redirect_url;
    }
    
    public function isAvailable(\Magento\Quote\Api\Data\CartInterface $quote = null)
    {
        $min = $this->getConfigData('min_amount');
        $max = $this->getConfigData('max_amount');
        if (parent::isAvailable($quote) && $quote && $quote->getGrandTotal() >= $min && $quote->getGrandTotal() <= $max
                && $this->getConfigData('private_key')
                && $this->getConfigData('public_key')
                && $this->getConfigData('module_url')
                && $this->getConfigData('currencies')
                        ) {
            return true;
        }
        return false;
    }
   


    public function getOrderPlaceRedirectUrl()
    {
        return $this->urlBuilder->getUrl('j2tpayplug/payment/redirect', ['_secure' => true]);
    }
}
