<?php
namespace Socialannex\Referafriend\Model;
use Magento\Framework\Model\AbstractModel;
class Referafriend extends AbstractModel
{
    protected function __construct()
    {
    }
}
