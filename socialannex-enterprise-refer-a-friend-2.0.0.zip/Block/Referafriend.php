<?php
namespace Socialannex\Referafriend\Block;
use \Magento\Framework\View\Element\Template;
class Referafriend extends Template
{
}

