<?php
namespace Socialannex\Referafriend\Helper;
use \Magento\Framework\App\Helper\AbstractHelper;
class Data extends AbstractHelper
{
    protected $rfHelperObj;
    protected $objectManager = '';
    protected $siteId = '';
    protected $_saPageId = '';

    public function __construct()
    {
        $this->objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $this->rfHelperObj = $this->objectManager->get('Socialannex\Saadmin\Helper\Data');
        $this->siteId = $this->rfHelperObj->getConfig('saadmin/sageneral/siteid');
    }

    public function getPageId($config_path)
    {
        return $this->rfHelperObj->getConfig($config_path);
    }

    protected function loadSaUniversal($_saPageId)
    {
        $saSiteId = $this->siteId;
        $jsUrl = "//cdn.socialannex.com/partner/$saSiteId/universal.js";
        $script = "<div id='sa_refer_friend'><div id='sa_raf_referral_coupon_code'>" . PHP_EOL;
        $script .= "<script type='text/javascript'>" . PHP_EOL;
        $script .= "var sa_uni = sa_uni || [];" . PHP_EOL;
        $script .= "sa_uni.push(['sa_pg', $_saPageId]);" . PHP_EOL;
        $script .= "(function () { function sa_async_load() { " . PHP_EOL;
        $script .= "var sa = document.createElement('script'); " . PHP_EOL;
        $script .= "sa.type = 'text/javascript'; " . PHP_EOL;
        $script .= "sa.async = true; " . PHP_EOL;
        $script .= "sa.src = '$jsUrl'; " . PHP_EOL;
        $script .= "var sax = document.getElementsByTagName ";
        $script .= "('script')[0]; " . PHP_EOL;
        $script .= "sax.parentNode.insertBefore(sa, sax);} " . PHP_EOL;
        $script .= "if (window.attachEvent) { " . PHP_EOL;
        $script .= "window.attachEvent('onload', sa_async_load); " . PHP_EOL;
        $script .= "} else { window.addEventListener ";
        $script .= "('load', sa_async_load, false);} " . PHP_EOL;
        $script .= "})();" . PHP_EOL;
        $script .= "</script> " . PHP_EOL;
        $script .= "<!-- End Social Annex Universal JS -->" . PHP_EOL;
        return $script;
    }

    //Share & Save Widget Version
    public function loadRafWidgetVersion($_saPageId)
    {
        $loadUniversal = $this->loadSaUniversal($_saPageId);
        return $loadUniversal;
    }
    //End Here
}

