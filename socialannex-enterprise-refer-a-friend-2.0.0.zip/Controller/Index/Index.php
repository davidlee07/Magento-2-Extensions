<?php
namespace Socialannex\Referafriend\Controller\Index;
use \Magento\Framework\App\Action\Action;
class Index extends Action
{
    public function execute()
    {


    }
}

