var config = {
    paths: {
        keen: 'Pixlee_Pixlee/dropCookie'
    }
};
