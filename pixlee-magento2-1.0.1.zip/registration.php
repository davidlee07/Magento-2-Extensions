<?php
/**
 * Copyright © 2015 Pixlee. All rights reserved.
 * See COPYING.txt for license details.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Pixlee_Pixlee',
    __DIR__
);
