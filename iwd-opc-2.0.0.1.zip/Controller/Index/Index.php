<?php
/**
 * Created by: IWD Agency "iwdagency.com"
 * Developer: Andrew Chornij "iwd.andrew@gmail.com"
 * Date: 12.01.2016
 */

namespace IWD\Opc\Controller\Index;

class Index extends \Magento\Checkout\Controller\Index\Index{

}