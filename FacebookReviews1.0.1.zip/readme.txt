Thank you for using the extension. 

Installation:
1) Create full backup of your site (both files and database)

2) Go to admin panel -> System -> Tools -> Compilation and make sure that Compiler Status is disabled. If it's not, please change it to disabled. If you plan to use the compilation after installing the extension, please click 'Run Compilation Process' button after you complete the extension installation.

3) Copy files  to the magento root folder

4) Log in as admin and refresh all caches (System > Cache Management)

Installation is complete.
