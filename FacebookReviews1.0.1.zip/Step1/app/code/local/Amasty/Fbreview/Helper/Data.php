<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2017 Amasty (https://www.amasty.com)
 * @package Amasty_Fbreview
 */

class Amasty_Fbreview_Helper_Data extends Mage_Core_Helper_Abstract
{
}