<?php
namespace Eflyermaker\Eflyermakerformbuilder\Controller\Adminhtml\SavePopup;


use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context as Context;
use Magento\Framework\View\Result\PageFactory as PageFactory;
use Magento\Framework\Controller\ResultFactory; 
use Magento\Framework\App\ResourceConnection as appResource;
use Magento\Framework\Stdlib\DateTime\DateTime as StdlibDateTime;
use Magento\Framework\Message\ManagerInterface as messageManager;
use Eflyermaker\Eflyermakerformbuilder\Model\EflyermakerFormData;


class Index extends Action
{
	/**
     * @var _resultPageFactory
     * @var _eflyermakerFormData
     * @var _dateTime
     * @var _messageManager
     * @var _resource
     */
     protected $_resultPageFactory;
     protected $_eflyermakerFormData;
     protected $_dateTime;
     protected $_messageManager;
     protected $_resource;



 /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory     resultPageFactory
     */
    public function __construct(
        Context $context, 
        PageFactory $resultPageFactory, 
        appResource $resource,
        EflyermakerFormData $eflyermakerFormData,
        StdlibDateTime $dateTime,
        messageManager $messageManager)
    {
        $this->_resultPageFactory = $resultPageFactory;
        $this->_eflyermakerFormData = $eflyermakerFormData;
        $this->_dateTime = $dateTime; 
        $this->_messageManager = $messageManager;
        $this->_resource = $resource;
        
        parent::__construct($context);
    }



  /**
  * Index Action*
  * @return void
  */
  	public function execute()
  	{
  		
		$efmfb_popup_title_has_body_bgcolor = $this->getRequest()->getParam('efmfb_popup_title_has_body_bgcolor') ? "checked" : "";
		$efmfb_popup_rotate_in_success = $this->getRequest()->getParam('efmfb_popup_rotate_in_success') ? "checked" : "";


        $efmfb_popup_db_options = array(
                    "efmfb_popup_classes" => trim($this->getRequest()->getParam('efmfb_popup_classes')),
                    "efmfb_popup_width" => trim($this->getRequest()->getParam('efmfb_popup_width')),
                    "efmfb_popup_height" => trim($this->getRequest()->getParam('efmfb_popup_height')),
                    "efmfb_popup_bg_img_url" => trim($this->getRequest()->getParam('efmfb_popup_bg_img')),
                    "efmfb_popup_overlay_color" => trim($this->getRequest()->getParam('efmfb_popup_overlay_color')),
                    "efmfb_popup_overlay_opacity" => trim($this->getRequest()->getParam('efmfb_popup_overlay_opacity_slider_val')),
                    "efmfb_popup_border_color" => trim($this->getRequest()->getParam('efmfb_popup_border_color')),
                    "efmfb_popup_border_radius" => trim($this->getRequest()->getParam('efmfb_popup_border_radius_slider_val')),
                    "efmfb_popup_close_icon_color" => trim($this->getRequest()->getParam('efmfb_popup_close_color')),
                    "efmfb_popup_bg_color" => trim($this->getRequest()->getParam('efmfb_popup_bg_color')),
                    "efmfb_popup_box_shadow" => trim($this->getRequest()->getParam('efmfb_popup_box_shadow')),
                    "efmfb_popup_footer_text" => trim($this->escapeHtml( $this->getRequest()->getParam('efmfb_popup_footer_text'))),
                    "efmfb_popup_header_text" => trim($this->escapeHtml( $this->getRequest()->getParam('efmfb_popup_header_text'))),
                    "efmfb_popup_title" => trim($this->escapeHtml( $this->getRequest()->getParam('efmfb_popup_title_text'))),
                    "efmfb_popup_title_color" => trim($this->getRequest()->getParam('efmfb_popup_title_color')),
                    "efmfb_popup_title_img_url" => trim($this->getRequest()->getParam('efmfb_popup_title_img')),
                    "efmfb_popup_title_img_pos" => trim($this->getRequest()->getParam('efmfb_popup_title_img_pos')),
                    "efmfb_popup_title_styles" => trim($this->getRequest()->getParam('efmfb_popup_title_styles')),
                    "efmfb_popup_title_has_body_bgcolor" => $efmfb_popup_title_has_body_bgcolor,
                    "efmfb_popup_body_bg_color" => trim($this->getRequest()->getParam('efmfb_popup_body_bg_color')),
                    "efmfb_popup_body_bg_rgba" => trim($this->getRequest()->getParam('efmfb_popup_body_bg_rgba')),
                    "efmfb_popup_body_bg_opacity" => trim($this->getRequest()->getParam('efmfb_popup_body_bg_opacity')),
                    "efmfb_popup_body_styles" => trim($this->getRequest()->getParam('efmfb_popup_body_styles')),
                    "efmfb_popup_body_classes" => trim($this->getRequest()->getParam('efmfb_popup_body_classes')),
                    "efmfb_popup_show_animation" => trim($this->getRequest()->getParam('efmfb_popup_animatecss_show')),
                    "efmfb_popup_hide_animation" => trim($this->getRequest()->getParam('efmfb_popup_animatecss_hide')),
                    "efmfb_popup_delay" => trim($this->getRequest()->getParam('efmfb_popup_delay')),
                    "efmfb_popup_rotate_in_success" => $efmfb_popup_rotate_in_success);


		        	$connection = $this->_resource->getConnection('core_write');
			        $resource = $this->_eflyermakerFormData;

		        $response = array( "success" => "1" );

		        try 
		        {          
		            $update = $connection->update( $resource->getMainTable(), $efmfb_popup_db_options, array('efmfb_id = ?' => '1' ) );
		            $response["success"] = 1;
		        } 
		        catch (\Exception $e) 
		        { 
		                $response["success"] = 0; 
		        }

		        echo Mage::helper('core')->jsonEncode($response);
		        return;
	}
}
