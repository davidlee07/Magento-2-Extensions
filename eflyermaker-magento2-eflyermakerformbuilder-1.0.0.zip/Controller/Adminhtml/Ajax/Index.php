<?php
namespace Eflyermaker\Eflyermakerformbuilder\Controller\Adminhtml\Ajax;


use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context as Context;
use Magento\Framework\View\Result\PageFactory as PageFactory;
use Magento\Framework\Controller\ResultFactory; 
use Magento\Framework\App\ResourceConnection as appResource;
use Magento\Framework\Stdlib\DateTime\DateTime as StdlibDateTime;
use Magento\Framework\Message\ManagerInterface as messageManager;
//use Magento\Framework\Validator\Exception;
// use Magento\Framework\Controller\Result\JsonFactory;
use Psr\Log\LoggerInterface as Logger;
use Eflyermaker\Eflyermakerformbuilder\Model\EflyermakerFormData;
use Eflyermaker\Eflyermakerformbuilder\Model\EflyermakerPopupData;



class Index extends Action
{



	/**
     * @var _resultPageFactory
     * @var _eflyermakerFormData
     * @var _dateTime
     * @var _messageManager
     * @var _resource
     */
     protected $_resultPageFactory;
     protected $_eflyermakerFormData;
     protected $_eflyermakerPopupData;
     protected $_dateTime;
     protected $_messageManager;
     protected $_resource;
     protected $_logger;
     //protected $_exp;
     // protected $_resultJsonFactory;



 /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory     resultPageFactory
     */
    public function __construct(
        Context $context, 
        PageFactory $resultPageFactory, 
        appResource $resource,
        EflyermakerFormData $eflyermakerFormData,
        EflyermakerPopupData $eflyermakerPopupData,
        StdlibDateTime $dateTime,
        Logger $logger,
        //Exception $exp,
        messageManager $messageManager)
    {
        $this->_resultPageFactory = $resultPageFactory;
        $this->_eflyermakerFormData = $eflyermakerFormData;
        $this->_eflyermakerPopupData = $eflyermakerPopupData;
        $this->_dateTime = $dateTime; 
        $this->_messageManager = $messageManager;
        $this->_resource = $resource;
        $this->_logger = $logger;
        //$this->_exp = $exp;
        
        parent::__construct($context);
    }








  /**
  * Index Action*
  * @return void
  */
  public function execute()
  {
        $action = $this->getRequest()->getParam('efmfb_action');
        

          if( method_exists( $this, $action ) )
          {
            call_user_func( array( $this, $action ) );
          }
          else
          {
            echo "ERROR!";
            return;
          }
}


//===================================


function getFormById()
{

            $efmfb_form_id = $this->getRequest()->getParam('efmfb_form_id');

            $formData = $this->_eflyermakerFormData->load($efmfb_form_id);


            $form_obj = array(
                 'efmfb_id' => $formData->getData('efmfb_id'),
                 'efmfb_list_id' => $formData->getData('efmfb_list_id'),
                 'efmfb_form_key' => $formData->getData('efmfb_form_key'),
                 'efmfb_form_name' => $formData->getData('efmfb_form_name'), 
                 'efmfb_form_description' => $formData->getData('efmfb_form_description'),
                 'efmfb_form_structure' => htmlspecialchars($formData->getData('efmfb_form_structure') ),
                 'efmfb_custom_styles' => $formData->getData('efmfb_custom_styles'),
                 'efmfb_custom_classes' => $formData->getData('efmfb_custom_classes'),
                 'efmfb_creation_date' => $formData->getData('efmfb_creation_date'),
                 'efmfb_last_modification' => $formData->getData('efmfb_last_modification'));


            echo json_encode($form_obj);
            
            return;
}

//============================================



public function saveForm()
{



            $response = array( "success" => "1" , "error_info" => "");

            $efmfb_form_key =  trim($this->getRequest()->getParam('efmfb_form_key'));
            $efmfb_form_name =  trim($this->getRequest()->getParam('efmfb_form_info_name'));
            $efmfb_form_description =  trim($this->getRequest()->getParam('efmfb_form_info_desc'));
            $efmfb_form_structure = trim(htmlspecialchars_decode(  $this->getRequest()->getParam('efmfb_form_structure') ));
            $efmfb_custom_classes =  trim($this->getRequest()->getParam('efmfb_form_info_classes'));
            $efmfb_custom_styles =  trim($this->getRequest()->getParam('efmfb_form_info_styles'));
            $efmfb_id =  trim($this->getRequest()->getParam('efmfb_form_old_id'));
            $efmfb_form_isEdit =  trim($this->getRequest()->getParam('efmfb_form_isEdit'));


            $success = 0;

            



            if( !$efmfb_form_name  )
            {
                 $response["success"] = 3; // Form name is required
            }
            else
            {
                $count =  $this->_eflyermakerFormData->getNbFormsWithName( $efmfb_form_name );

                    $data = array(
                    "efmfb_form_key" =>  $efmfb_form_key,
                    "efmfb_form_name" =>  $efmfb_form_name,
                    "efmfb_form_description" =>  $efmfb_form_description,
                    "efmfb_form_structure" =>  $efmfb_form_structure,
                    "efmfb_custom_classes" =>  $efmfb_custom_classes,
                    "efmfb_custom_styles" =>  $efmfb_custom_styles,
                    "efmfb_creation_date" => $this->_dateTime->date('Y-m-d H:i:s'),
                    "efmfb_last_modification" => $this->_dateTime->date('Y-m-d H:i:s')
                    );

                    if($efmfb_form_isEdit === '1') // update existing Form
                    {
                            try 
                            {
                                $actForm = $this->_eflyermakerFormData->load( $efmfb_id );


                                $actFormName = $actForm["efmfb_form_name"];
                                $nameAllowed = 0;
                                if( $actFormName === $efmfb_form_name ) $nameAllowed = 1;
                                else if( $count === 0 ) $nameAllowed = 1;
                                
                                if( $nameAllowed === 1 )
                                {

                                    $connection = $this->_resource->getConnection();
                                    $resource = $this->_eflyermakerFormData;

                                    
                                    $update = null;
                                    
                                    try {
                                            $update = $connection->update(
                                        $connection->getTableName("eflyermakerformbuilder_form"),
                                        array(
                                            'efmfb_form_key' => $efmfb_form_key,
                                            'efmfb_form_name' => $efmfb_form_name,
                                            'efmfb_form_description' => $efmfb_form_description,
                                            'efmfb_form_structure' => $efmfb_form_structure,
                                            'efmfb_custom_classes' => $efmfb_custom_classes,
                                            'efmfb_custom_styles' => $efmfb_custom_styles,
                                            'efmfb_last_modification' => $this->_dateTime->date('Y-m-d H:i:s') ),
                                        array('efmfb_id = ?' => $efmfb_id )) ;
                                    } catch (\Exception $e) {
                                        $this->_logger->addDebug('UPDTAE exception :::: '.$e);  
                                        $this->_logger->addDebug('UPDTAE :::: '.$update);  

                                    }


                              

                                    if($update >= 0)
                                    {
                                        $success = 1;
                                         $response["success"] = 1;
                                    }
                                    else
                                    {
                                        $success = 0;
                                        $error = 1;
                                         $response["success"] = 0;
                                         $response["error_info"] = "update error";
                                    }
                                }
                                else
                                {
                                    $data['efmfb_id'] = $efmfb_id;
                                     $response["success"] = 2;
                                }
                                
                            } 
                            catch (\Exception $e) 
                            {
                                $success = 0;
                                $error = 2;
                                 $response["success"] = 0;
                                 $response["error_info"] = "update form exeption !";
                            }
                    }   
                    else // New Form
                    {
                            if( $count > 0 ) // Test if name exists in db 
                            {
                                 $response["success"] = 2;
                            }
                            else
                            {
                                    $model = $this->_eflyermakerFormData->setData($data);
                                    try 
                                    {
                                            $insertId = $model->save()->getId();
                                            if($insertId)
                                            {
                                                $success = 1;
                                                 $response["success"] = 1;

                                            }
                                    } 
                                    catch (\Exception $e)
                                    {
                                        $success = 0;
                                        $error = 3;
                                         $response["success"] = 0;
                                         $response["error_info"] = "new form exception";
                                        //echo $e->getMessage();
                                    }
                            }
                    }// end new form
            } 



            echo json_encode($response );
            return; 

}


//===========================================




    /**************
    *
    * DELETE FORM FROM DB
    *
    *****************/ 
    
    public function deleteForm()
    {


        $response = array( "success" => "0" );
        

        try 
        {
            $efmfb_form_id = $this->getRequest()->getParam('efmfb_form_id');

             $connection = $this->_resource->getConnection(appResource::DEFAULT_CONNECTION);
            $delete = $connection->delete(
                               $connection->getTableName("eflyermakerformbuilder_form"),
                               array('efmfb_id = ?' => $efmfb_form_id )) ;    
            
            if($delete)  $response['success'] = 1;
        } 
        catch (\Exception $e) 
        {
            $response['success'] = 0;
        }


           echo json_encode($response );
            return; 
    }




    /***************
    *
    * DUPLICATE FORM
    *
    *****************/ 
    
    public function duplicateForm()
    {
            $response = array( "success" => "0" );           
           

            try 
            {
                $efmfb_form_id = $this->getRequest()->getParam('efmfb_form_id');
                $duplicate_this_form = $this->_eflyermakerFormData->load( $efmfb_form_id );
                $new_form_name = $this->_eflyermakerFormData->getDuplicatedName($duplicate_this_form['efmfb_form_name']);

        $data = array(
        "efmfb_form_key" =>  $duplicate_this_form['efmfb_form_key'],
        "efmfb_form_name" =>  $new_form_name,
        "efmfb_form_description" =>  $duplicate_this_form['efmfb_form_description'],
        "efmfb_form_structure" =>  $duplicate_this_form['efmfb_form_structure'],
        "efmfb_custom_classes" =>  $duplicate_this_form['efmfb_custom_classes'],
        "efmfb_custom_styles" =>  $duplicate_this_form['efmfb_custom_styles'],
        "efmfb_creation_date" =>  $this->_dateTime->date('Y-m-d H:i:s'),
        "efmfb_last_modification" =>  $this->_dateTime->date('Y-m-d H:i:s')
        );




                        //save to db
                        $model = $this->_eflyermakerFormData->setData($data);
                        try 
                        {
                                $insertId = $model->save()->getId();
                                if($insertId)
                                {
                                    $response['success'] = 1;
                                }
                        } 
                        catch (\Exception $e)
                        {
                            $response['success'] = 2;
                            Mage::getSingleton('core/session')->addError('An error has occurred');
                        }
            } 
            catch (\Exception $e) 
            {
                
                $response['success'] = 0;

            }


            echo json_encode($response );

            return; 


    }




//============================================


function savePopup()
{
        $efmfb_popup_title_has_body_bgcolor = $this->getRequest()->getParam('efmfb_popup_title_has_body_bgcolor') ? "checked" : "";
        $efmfb_popup_rotate_in_success = $this->getRequest()->getParam('efmfb_popup_rotate_in_success') ? "checked" : "";


        $efmfb_popup_db_options = array(
                    "efmfb_popup_classes" => trim($this->getRequest()->getParam('efmfb_popup_classes')),
                    "efmfb_popup_width" => trim($this->getRequest()->getParam('efmfb_popup_width')),
                    "efmfb_popup_height" => trim($this->getRequest()->getParam('efmfb_popup_height')),
                    "efmfb_popup_bg_img_url" => trim($this->getRequest()->getParam('efmfb_popup_bg_img')),
                    "efmfb_popup_overlay_color" => trim($this->getRequest()->getParam('efmfb_popup_overlay_color')),
                    "efmfb_popup_overlay_opacity" => trim($this->getRequest()->getParam('efmfb_popup_overlay_opacity_slider_val')),
                    "efmfb_popup_border_color" => trim($this->getRequest()->getParam('efmfb_popup_border_color')),
                    "efmfb_popup_border_radius" => trim($this->getRequest()->getParam('efmfb_popup_border_radius_slider_val')),
                    "efmfb_popup_close_icon_color" => trim($this->getRequest()->getParam('efmfb_popup_close_color')),
                    "efmfb_popup_bg_color" => trim($this->getRequest()->getParam('efmfb_popup_bg_color')),
                    "efmfb_popup_box_shadow" => trim($this->getRequest()->getParam('efmfb_popup_box_shadow')),
                    "efmfb_popup_footer_text" => trim(htmlspecialchars_decode( $this->getRequest()->getParam('efmfb_popup_footer_text'))),
                    "efmfb_popup_header_text" => trim(htmlspecialchars_decode( $this->getRequest()->getParam('efmfb_popup_header_text'))),
                    "efmfb_popup_title" => trim(htmlspecialchars_decode( $this->getRequest()->getParam('efmfb_popup_title_text'))),
                    "efmfb_popup_title_color" => trim($this->getRequest()->getParam('efmfb_popup_title_color')),
                    "efmfb_popup_title_img_url" => trim($this->getRequest()->getParam('efmfb_popup_title_img')),
                    "efmfb_popup_title_img_pos" => trim($this->getRequest()->getParam('efmfb_popup_title_img_pos')),
                    "efmfb_popup_title_styles" => trim($this->getRequest()->getParam('efmfb_popup_title_styles')),
                    "efmfb_popup_title_has_body_bgcolor" => $efmfb_popup_title_has_body_bgcolor,
                    "efmfb_popup_body_bg_color" => trim($this->getRequest()->getParam('efmfb_popup_body_bg_color')),
                    "efmfb_popup_body_bg_rgba" => trim($this->getRequest()->getParam('efmfb_popup_body_bg_rgba')),
                    "efmfb_popup_body_bg_opacity" => trim($this->getRequest()->getParam('efmfb_popup_body_bg_opacity')),
                    "efmfb_popup_body_styles" => trim($this->getRequest()->getParam('efmfb_popup_body_styles')),
                    "efmfb_popup_body_classes" => trim($this->getRequest()->getParam('efmfb_popup_body_classes')),
                    "efmfb_popup_show_animation" => trim($this->getRequest()->getParam('efmfb_popup_animatecss_show')),
                    "efmfb_popup_hide_animation" => trim($this->getRequest()->getParam('efmfb_popup_animatecss_hide')),
                    "efmfb_popup_delay" => trim($this->getRequest()->getParam('efmfb_popup_delay')),
                    "efmfb_popup_rotate_in_success" => $efmfb_popup_rotate_in_success);


        $connection = $this->_resource->getConnection(appResource::DEFAULT_CONNECTION);
        $resource = $this->_eflyermakerPopupData;
        $response = array( "success" => "1" );

        try 
        {          
            $update = $connection->update( $connection->getTableName("eflyermakerformbuilder_popup"), $efmfb_popup_db_options, array('efmfb_id = ?' => '1' ) );
            $response["success"] = 1;
        } 
        catch (\Exception $e) 
        { 
                $response["success"] = 0; 
        }

         echo json_encode($response );
        return;


}

//==============================================================



}
