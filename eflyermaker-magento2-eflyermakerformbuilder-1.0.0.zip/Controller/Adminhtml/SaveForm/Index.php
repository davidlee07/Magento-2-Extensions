<?php
namespace Eflyermaker\Eflyermakerformbuilder\Controller\Adminhtml\SaveForm;


use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context as Context;
use Magento\Framework\View\Result\PageFactory as PageFactory;
use Magento\Framework\Controller\ResultFactory; 
use Magento\Framework\App\ResourceConnection as appResource;
use Magento\Framework\Stdlib\DateTime\DateTime as StdlibDateTime;
use Magento\Framework\Message\ManagerInterface as messageManager;
use Eflyermaker\Eflyermakerformbuilder\Model\EflyermakerFormData;


class Index extends Action
{
	/**
     * @var _resultPageFactory
     * @var _eflyermakerFormData
     * @var _dateTime
     * @var _messageManager
     * @var _resource
     */
     protected $_resultPageFactory;
     protected $_eflyermakerFormData;
     protected $_dateTime;
     protected $_messageManager;
     protected $_resource;



 /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory     resultPageFactory
     */
    public function __construct(
        Context $context, 
        PageFactory $resultPageFactory, 
        appResource $resource,
        EflyermakerFormData $eflyermakerFormData,
        StdlibDateTime $dateTime,
        messageManager $messageManager)
    {
        $this->_resultPageFactory = $resultPageFactory;
        $this->_eflyermakerFormData = $eflyermakerFormData;
        $this->_dateTime = $dateTime; 
        $this->_messageManager = $messageManager;
        $this->_resource = $resource;
        
        parent::__construct($context);
    }




/*
Success -

$this->messageManager->addSuccess( __('This is your success message.') );

Error -

$this->messageManager->addError( __('This is your error message.') );

Warning -

$this->messageManager->addWarning( __('This is your warning message.') );

Notice

$this->messageManager->addNotice( __('This is your notice message.') );
*/

  /**
  * Index Action*
  * @return void
  */
  public function execute()
  {



	        $efmfb_form_key =  trim($this->getRequest()->getParam('efmfb_form_key'));
	        $efmfb_form_name =  trim($this->getRequest()->getParam('efmfb_form_info_name'));
	        $efmfb_form_description =  trim($this->getRequest()->getParam('efmfb_form_info_desc'));
	        $efmfb_form_structure = trim(htmlspecialchars_decode(  $this->getRequest()->getParam('efmfb_form_structure') ));
	        $efmfb_custom_classes =  trim($this->getRequest()->getParam('efmfb_form_info_classes'));
	        $efmfb_custom_styles =  trim($this->getRequest()->getParam('efmfb_form_info_styles'));
	        $efmfb_id =  trim($this->getRequest()->getParam('efmfb_form_old_id'));
	        $efmfb_form_isEdit =  trim($this->getRequest()->getParam('efmfb_form_isEdit'));



	        $success = 0;


	        
			if( !$efmfb_form_name  )
			{
			    $this->_messageManager->addError( __('Form name is required') );
			}
			else
			{
			    $count =  $this->_eflyermakerFormData->getNbFormsWithName( $efmfb_form_name );



			        $data = array(
			        "efmfb_form_key" =>  $efmfb_form_key,
			        "efmfb_form_name" =>  $efmfb_form_name,
			        "efmfb_form_description" =>  $efmfb_form_description,
			        "efmfb_form_structure" =>  $efmfb_form_structure,
			        "efmfb_custom_classes" =>  $efmfb_custom_classes,
			        "efmfb_custom_styles" =>  $efmfb_custom_styles,
			        "efmfb_creation_date" => $this->_dateTime->date('Y-m-d H:i:s'),
			        "efmfb_last_modification" => $this->_dateTime->date('Y-m-d H:i:s')
			        );



			        if($efmfb_form_isEdit === '1') // update Form
			        {
			                try 
			                {
			                    $actForm = $this->_eflyermakerFormData->load( $efmfb_id );
			                   


			                    $actFormName = $actForm["efmfb_form_name"];
			                    
			                    $nameAllowed = 0;
			                    if( $actFormName === $efmfb_form_name ) $nameAllowed = 1;
			                    else if( $count === 0 ) $nameAllowed = 1;
			                    
			                    if( $nameAllowed === 1 )
			                    {

			                        $connection = $this->_resource->getConnection('core_write');
			                        $resource = $this->_eflyermakerFormData;

			                        
			                        $update = $connection->update(
			                            
			                            $connection->getTableName("eflyermakerformbuilder_form"),
			                            array(
			                                'efmfb_form_key' => $efmfb_form_key,
			                                'efmfb_form_name' => $efmfb_form_name,
			                                'efmfb_form_description' => $efmfb_form_description,
			                                'efmfb_form_structure' => $efmfb_form_structure,
			                                'efmfb_custom_classes' => $efmfb_custom_classes,
			                                'efmfb_custom_styles' => $efmfb_custom_styles,
			                                'efmfb_last_modification' => $this->_dateTime->date('Y-m-d H:i:s') ),
			                            array('efmfb_id = ?' => $efmfb_id )) ;

			                        

			                        if($update)
			                        {
			                            $success = 1;
			                            $this->_messageManager->addSuccess( __('Your form was saved with success') );
			                            session_write_close();
			                            // $this->_redirect('admin_eflyermakerformbuilder/adminhtml_eflyermakerformbuilder/getFormsList');
			                            return $this->resultRedirectFactory->create()->setPath( '*/CreateForm' );
			                        }
			                        else
			                        {
			                            $success = 0;
			                            $error = 1;
			                            $this->_messageManager->addError( __('An error has occurred') );
			                        }
			                    }
			                    else
			                    {
			                        $data['efmfb_id'] = $efmfb_id;
			                        // Mage::register('formData', $data);
			                        $this->_messageManager->addError( __('A form with the same name already exists!') );
			                    }
			                    
			                } 
			                catch (\Exception $e) 
			                {
			                    $success = 0;
			                    $error = 2;
			                    $this->_messageManager->addError( __('An error has occurred') );
			                }
			        }   
			        else // New Form
			        {
			                if( $count > 0 ) // Test if name exists in db 
			                {
			                    $this->_messageManager->addError( __('A form with the same name already exists!') );
			                }
			                else
			                {
			                        
			                        $model = $this->_eflyermakerFormData->setData($data);
			                        try 
			                        {
			                                $insertId = $model->save()->getId();
			                                if($insertId)
			                                {
			                                    $success = 1;
			                                    $this->_messageManager->addSuccess( __('Your form was saved with success') );
			                                    session_write_close();
			                                    return $this->resultRedirectFactory->create()->setUrl( '*/EditForm' );

			                                }
			                        } 
			                        catch (\Exception $e)
			                        {
			                            $success = 0;
			                            $error = 3;
			                            $this->_messageManager->addError( __('An error has occurred') );
			                            
			                        }
			                }
			        }// end new form
			} 


  }
}
