<?php

/**
 *
 * @category    Eflyermaker
 * @package     Eflyermaker_Eflyermakerformbuilder
 * @author      eFlyerMaker Team <welcome@eflyermaker.com>
 * @copyright   eFlyermaker (http://www.eflyermaker.com)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
 
namespace Eflyermaker\Eflyermakerformbuilder\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\App\ObjectManager;


class InstallSchema implements InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
		$installer->startSetup();

        $tableName = $installer->getTable('eflyermakerformbuilder_form');


		if ( $installer->getConnection()->isTableExists( $tableName ) ) 
		{
			$installer->getConnection()->dropTable( $tableName );
		}
		
		
$table = $installer->getConnection()->newTable( $tableName )
    ->addColumn('efmfb_id',                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 11, ['unsigned' => true, 'nullable' => false, 'primary' => true, 'identity' => true], 'Form ID')
    ->addColumn('efmfb_list_id',           \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 11, ['unsigned' => true, 'nullable' => true], 'List ID (not used)')
    ->addColumn('efmfb_form_key',          \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => true, 'default' => ''], 'Fform Key')
    ->addColumn('efmfb_form_name',         \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false, 'default' => ''], 'Form Name')
    ->addColumn('efmfb_form_description',  \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => true, 'default' => ''], 'Form Desc')
    ->addColumn('efmfb_form_structure',    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => true, 'default' => ''], 'Form Strucure')
    ->addColumn('efmfb_custom_styles',     \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => true, 'default' => ''], 'Form Style')
    ->addColumn('efmfb_custom_classes',    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => true, 'default' => ''], 'Form Classes')
    ->addColumn('efmfb_creation_date',     \Magento\Framework\DB\Ddl\Table::TYPE_DATE, null, ['nullable' => true, 'default' => null], 'Created Date')
    ->addColumn('efmfb_last_modification', \Magento\Framework\DB\Ddl\Table::TYPE_DATE, null, ['nullable' => true, 'default' => null], 'Update Date')    
    ->setComment('eFlyerMaker Form Builder table');

	$installer->getConnection()->createTable($table);


	

//==================== POPUP TABLE =====================


        $tableName = $installer->getTable('eflyermakerformbuilder_popup');

		if ($installer->getConnection()->isTableExists( $tableName ) ) 
		{
			$installer->getConnection()->dropTable( $tableName );
		}
		

$table = $installer->getConnection()->newTable( $tableName )
    ->addColumn('efmfb_id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 11, ['unsigned' => true, 'nullable' => false, 'primary' => true, 'identity' => true], 'Popup ID')
    ->addColumn('efmfb_form_id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 11, ['unsigned' => true, 'nullable' => true], 'Form ID')
    ->addColumn('efmfb_popup_classes', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => true, 'default' => ''], 'Popup classes')
    ->addColumn('efmfb_popup_width', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 10, ['nullable' => true, 'default' => '400'], 'Popup width')
    ->addColumn('efmfb_popup_height', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 10, ['nullable' => true, 'default' => '400'], 'Popup height')
    ->addColumn('efmfb_popup_bg_img_url', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => true, 'default' => ''], 'Popup img url')
    ->addColumn('efmfb_popup_overlay_color', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 10, ['nullable' => true, 'default' => '#000000'], 'Popup overlay color')
    ->addColumn('efmfb_popup_overlay_opacity', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 10, ['nullable' => true, 'default' => '0.7'], 'Popup overlay opacity')
    ->addColumn('efmfb_popup_border_color', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 10, ['nullable' => true, 'default' => '#ffffff'], 'Popup border color')
    ->addColumn('efmfb_popup_border_radius', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 10, ['nullable' => true, 'default' => '0'], 'Popup border radius')
    ->addColumn('efmfb_popup_close_icon_color', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 10, ['nullable' => true, 'default' => '#ffffff'],'Popup close icon')
    ->addColumn('efmfb_popup_bg_color', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 10, ['nullable' => true, 'default' => '#f0f0f0'], 'Popup bg color')
    ->addColumn('efmfb_popup_box_shadow', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 100, ['nullable' => true, 'default' => '0px 0px 4px #666666'], 'Popup box shadow')
    ->addColumn('efmfb_popup_footer_text', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => true, 'default' => ''], 'Popup footer text')
    ->addColumn('efmfb_popup_header_text', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => true, 'default' => ''], 'Popup header text')
    ->addColumn('efmfb_popup_title', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => true, 'default' => ''], 'Popup title')
    ->addColumn('efmfb_popup_title_color', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 10, ['nullable' => true, 'default' => '#000000'], 'Popup title color')
    ->addColumn('efmfb_popup_title_img_url', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => true, 'default' => ''], 'Popup title img url')
    ->addColumn('efmfb_popup_title_img_pos', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 10, ['nullable' => true, 'default' => 'left'], 'Popup title img pos')
    ->addColumn('efmfb_popup_title_styles', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => true, 'default' => ''], 'Popup title style')
    ->addColumn('efmfb_popup_title_has_body_bgcolor', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 10, ['nullable' => true, 'default' => ''], 'Popup has bgcolor')
    ->addColumn('efmfb_popup_body_bg_color', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 10, ['nullable' => true, 'default' => ''], 'Popup body bg')
    ->addColumn('efmfb_popup_body_bg_rgba', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 100, ['nullable' => true, 'default' => ''], 'Popup body bg')
    ->addColumn('efmfb_popup_body_bg_opacity', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 10, ['nullable' => true, 'default' => '0'], 'Popup body opacity')
    ->addColumn('efmfb_popup_body_styles', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => true, 'default' => ''], 'Popup body style')
    ->addColumn('efmfb_popup_body_classes', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => true, 'default' => ''], 'Popup body style')
    ->addColumn('efmfb_popup_show_effect', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 30, ['nullable' => true, 'default' => 'fade'], 'Popup show effect')
    ->addColumn('efmfb_popup_show_effect_duration', \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT, 6, ['nullable' => true, 'default' => '400'], 'Popup show effect duration')
    ->addColumn('efmfb_popup_hide_effect', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 30, ['nullable' => true, 'default' => 'fade'], 'Popup hide effect')
    ->addColumn('efmfb_popup_hide_effect_duration', \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT, 6, ['nullable' => true, 'default' => '400'], 'Popup hide duration')
    ->addColumn('efmfb_popup_show_animation', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 30, ['nullable' => true, 'default' => ''], 'Popup show animation')
    ->addColumn('efmfb_popup_hide_animation', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 30, ['nullable' => true, 'default' => ''], 'Popup hide animation')
    ->addColumn('efmfb_popup_delay', \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT, 6, ['nullable' => true, 'default' => '0'], 'Popup delay')
    ->addColumn('efmfb_popup_rotate_in_success', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 10, ['nullable' => true, 'default' => ''], 'Popup success')
    ->setComment('eFlyerMaker Popup table');


	$installer->getConnection()->createTable($table);

//===== Init popup options =====

 $installer->run("
        INSERT INTO {$tableName} (`efmfb_id`) values ('1');
    ");


	$installer->endSetup();



    }
}


