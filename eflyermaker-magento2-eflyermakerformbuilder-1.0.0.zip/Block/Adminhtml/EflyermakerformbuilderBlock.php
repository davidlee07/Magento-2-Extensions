<?php
namespace Eflyermaker\Eflyermakerformbuilder\Block\Adminhtml;

// use Magento\Backend\Block\Template;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Elyermaker\Eflyermakerformbuilder\Helper\ConfigHelper;
use Eflyermaker\Eflyermakerformbuilder\Model\EflyermakerFormData;
use Eflyermaker\Eflyermakerformbuilder\Model\EflyermakerPopupData;


class EflyermakerformbuilderBlock extends Template
{
    /**
     * @var Elyermaker\Eflyermakerformbuilder\Helper\ConfigHelper
     */
    protected $_config;
// 
    protected $_eflyermakerFormData;
    protected $_eflyermakerPopupData;

    /**
    * @param Context $context
    * @param array $data
    */
    public function __construct( 
                Context $context, 
                EflyermakerFormData $eflyermakerformModel, 
                EflyermakerPopupData $eflyermakerpopupModel ) {
        
        $this->_eflyermakerFormData = $eflyermakerformModel;
        $this->_eflyermakerPopupData = $eflyermakerpopupModel;
        parent::__construct($context);
    }





    /**
     * @return array
     */

    public function getFormsList()
    {
        return $this->_eflyermakerFormData->getFormsList();

    }


    public function getFormById( $form_id )
    {
        return $this->_eflyermakerFormData->getFormById( $form_id );
    }


    /**
     * @return array
     */

    public function getPopupData()
    {

        return $this->_eflyermakerPopupData->getPopupData();
    }


}
