<?php
namespace Eflyermaker\Eflyermakerformbuilder\Block\Frontend;


use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\ObjectManagerInterface;
use Magento\Framework\Filter\Template as Filter;
use Elyermaker\Eflyermakerformbuilder\Helper\ConfigHelper;
use Eflyermaker\Eflyermakerformbuilder\Model\EflyermakerFormData;
use Eflyermaker\Eflyermakerformbuilder\Model\EflyermakerPopupData;


class efmfbBlock extends Template
{
    /**
     * @var Eflyermaker\Eflyermakerformbuilder\Helper\ConfigHelper
     */
    protected $_config;
// 
    protected $_objectManager;
    protected $_filter;
    protected $_eflyermakerFormData;
    protected $_eflyermakerPopupData;

    /**
    * @param Context $context
    * @param array $data
    */
    public function __construct( 
                Context $context, 
                ObjectManagerInterface $objectManager,
                Filter $filter,
                EflyermakerFormData $eflyermakerformModel, 
                EflyermakerPopupData $eflyermakerpopupModel ) {
        
        // $this->_config = $config;
        $this->_objectManager = $objectManager;
        $this->_filter = $filter;
        $this->_eflyermakerFormData = $eflyermakerformModel;
        $this->_eflyermakerPopupData = $eflyermakerpopupModel;
        parent::__construct($context);
    }





    /**
     * @return array
     */

    public function getFormsList()
    {
        return $this->_eflyermakerFormData->getFormsList();

    }


    public function getFormById( $form_id )
    {
        return  $this->_eflyermakerFormData->load( $form_id );
    }


    /**
     * @return array
     */

    public function getPopupData()
    {

        return $this->_eflyermakerPopupData->getPopupData();
    }

// =================================================================

    public function getFrontendForm($efmfb_id, $is_popup, $popup_onclick)
    {
        if ( empty( $efmfb_id ) || '' == $efmfb_id ) 
        {
            return '';
        }


            $form = '';

            $form_results = $this->_eflyermakerFormData->load( $efmfb_id );

            $classes = $form_results->getData("efmfb_custom_classes");
            $styles = $form_results->getData("efmfb_custom_styles");
            $form .='<div class="efmfb_form_outer_container">';
            $form .='<div id="eFlyerMaker_msg" class="efmfb-alert"></div>';
            $form .= '<form id="sub_form" method="post" action=""   efmfb-formsource="tinymce" class="'.$classes.'" style="'.$styles.'">';
            $form .= '<input type="hidden" name="simple" value="simple" style="display:none !important;">';
            $form .= html_entity_decode( $form_results->getData("efmfb_form_structure") );
            $form .= '</form>';
            
			if( strpos($form, 'name="form_lang" value="fr"') === false  )
			{
				$form .= '<center><span style="font-size:11px; font-weight:normal;">Signup form powered by <a href="http://www.eflyermaker.com" title="Best email marketing software" target="_blank">eFlyerMaker.com</a>, powerful and easy-to-use email marketing software.</span></center>';
			}
			else
			{
				$form .= '<center><span style="font-size:11px; font-weight:normal;">Formulaire d\'inscription fourni par <a href="http://www.eflyermaker.com/accueil.html" title="Meilleur logiciel de marketing par courriel" target="_blank">eFlyerMaker.com</a>, email marketing performant et intuitif.</span></center>';
			}
			$form .= '</div>';






            if($is_popup == "1")
            {
                $popup_options_db = $this->_eflyermakerPopupData->load( "1" );
                
                $id = $popup_options_db->getData('efmfb_id');
                $efmfb_form_id = $popup_options_db->getData('efmfb_form_id');
                $efmfb_popup_classes = $popup_options_db->getData('efmfb_popup_classes');
                $efmfb_popup_width = $popup_options_db->getData('efmfb_popup_width');
                $efmfb_popup_height = $popup_options_db->getData('efmfb_popup_height');
                $efmfb_popup_bg_img = $popup_options_db->getData('efmfb_popup_bg_img_url');
                $efmfb_popup_overlay_color = $popup_options_db->getData('efmfb_popup_overlay_color');
                $efmfb_popup_overlay_opacity = $popup_options_db->getData('efmfb_popup_overlay_opacity');
                $efmfb_popup_border_color = $popup_options_db->getData('efmfb_popup_border_color');
                $efmfb_popup_border_radius = $popup_options_db->getData('efmfb_popup_border_radius');
                $efmfb_popup_close_icon_color = $popup_options_db->getData('efmfb_popup_close_icon_color');
                $efmfb_popup_bg_color = $popup_options_db->getData('efmfb_popup_bg_color');
                $efmfb_popup_box_shadow = $popup_options_db->getData('efmfb_popup_box_shadow');
                $efmfb_popup_footer_text = html_entity_decode($popup_options_db->getData('efmfb_popup_footer_text'));
                $efmfb_popup_header_text = html_entity_decode($popup_options_db->getData('efmfb_popup_header_text'));
                $efmfb_popup_title_text = html_entity_decode($popup_options_db->getData('efmfb_popup_title'));
                $efmfb_popup_title_color = $popup_options_db->getData('efmfb_popup_title_color');
                $efmfb_popup_title_img = $popup_options_db->getData('efmfb_popup_title_img_url');
                $efmfb_popup_title_img_pos = $popup_options_db->getData('efmfb_popup_title_img_pos');
                $efmfb_popup_title_styles = $popup_options_db->getData('efmfb_popup_title_styles');
                $efmfb_popup_title_has_body_bgcolor = $popup_options_db->getData('efmfb_popup_title_has_body_bgcolor');
                $efmfb_popup_body_bg_color = $popup_options_db->getData('efmfb_popup_body_bg_color');
                $efmfb_popup_body_bg_rgba = $popup_options_db->getData('efmfb_popup_body_bg_rgba');
                $efmfb_popup_body_bg_opacity = $popup_options_db->getData('efmfb_popup_body_bg_opacity');
                $efmfb_popup_body_styles = $popup_options_db->getData('efmfb_popup_body_styles');
                $efmfb_popup_body_classes = $popup_options_db->getData('efmfb_popup_body_classes');
                $efmfb_popup_show_effect = $popup_options_db->getData('efmfb_popup_show_effect');
                $efmfb_popup_show_effect_duration = $popup_options_db->getData('efmfb_popup_show_effect_duration');
                $efmfb_popup_hide_effect = $popup_options_db->getData('efmfb_popup_hide_effect');
                $efmfb_popup_hide_effect_duration = $popup_options_db->getData('efmfb_popup_hide_effect_duration');
                $efmfb_popup_animatecss_show = $popup_options_db->getData('efmfb_popup_show_animation');
                $efmfb_popup_animatecss_hide = $popup_options_db->getData('efmfb_popup_hide_animation');
                $efmfb_popup_delay = $popup_options_db->getData('efmfb_popup_delay');
                $efmfb_popup_rotate_in_success = $popup_options_db->getData('efmfb_popup_rotate_in_success');
                    
                


                $efmfb_popup_Form_html = '';
                $efmfb_popup_Form_html .= '<div id="efmfb_popup_form_data" style="display:none;">';
                $efmfb_popup_Form_html .= '<input type="hidden" style="display:none !important;" name="efmfb_popup_on_click"  id="efmfb_popup_on_click" value="'.$popup_onclick.'"/>';
                $efmfb_popup_Form_html .= '<input type="hidden" style="display:none !important;" name="efmfb_popup_overlay_color"  id="efmfb_popup_overlay_color" value="'.$efmfb_popup_overlay_color.'"/>';
                $efmfb_popup_Form_html .= '<input type="hidden" style="display:none !important;" name="efmfb_popup_animatecss_show"  id="efmfb_popup_animatecss_show" value="'.$efmfb_popup_animatecss_show.'"/>';
                $efmfb_popup_Form_html .= '<input type="hidden" style="display:none !important;" name="efmfb_popup_animatecss_hide"  id="efmfb_popup_animatecss_hide" value="'.$efmfb_popup_animatecss_hide.'"/>';
                $efmfb_popup_Form_html .= '<input type="hidden" style="display:none !important;" name="efmfb_popup_delay"  id="efmfb_popup_delay" value="'.$efmfb_popup_delay.'"/>';
                $efmfb_popup_Form_html .= '<input type="hidden" style="display:none !important;" name="efmfb_popup_overlay_opacity"  id="efmfb_popup_overlay_opacity" value="'.$efmfb_popup_overlay_opacity.'"/>';
                $efmfb_popup_Form_html .= '<input type="hidden" style="display:none !important;" name="efmfb_popup_rotate_in_success"  id="efmfb_popup_rotate_in_success" value="'.$efmfb_popup_rotate_in_success.'"/>';
                $efmfb_popup_Form_html .= '</div>';
                   





                $efmfb_popup_style = 'style="';
                $efmfb_popup_style .= 'width:'.$efmfb_popup_width.'px; max-width:100%;';
                // $efmfb_popup_style .= 'height:'.$efmfb_popup_height.'px; ';
                $efmfb_popup_style .= 'box-shadow:'.$efmfb_popup_box_shadow.'; ';
                if( $efmfb_popup_bg_color ) $efmfb_popup_style .= 'background-color:'.$efmfb_popup_bg_color.';';
                if( $efmfb_popup_bg_img ) $efmfb_popup_style .= 'background-image:url('.$efmfb_popup_bg_img.') ; background-repeat:no-repeat; background-position:center;';
                if( $efmfb_popup_border_color ) $efmfb_popup_style .= 'border:1px solid '.$efmfb_popup_border_color.';';
                if( $efmfb_popup_border_radius ) $efmfb_popup_style .= 'border-radius:'.$efmfb_popup_border_radius.'px;';
                $efmfb_popup_style .= 'max-height:100%;   padding:0px; overflow-x:hidden; overflow-y:auto;';
                // $efmfb_popup_style .= ' overflow:auto; ';
                $efmfb_popup_style .= '"';





                $close_height = '20';

                $efmfb_popup_title_style = 'style="';
                $efmfb_popup_title_style .= $efmfb_popup_title_styles;
                $efmfb_popup_title_style .= 'color: '.$efmfb_popup_title_color.';';
                $efmfb_popup_title_style .= '  font-weight:bold; font-size:18px;"';




                if($efmfb_popup_body_bg_rgba) $efmfb_popup_body_bg_rgba = 'background-color:'.$efmfb_popup_body_bg_rgba.';';



                $efmfb_popup_body_style = 'style="';
                $efmfb_popup_body_style .= $efmfb_popup_body_styles.' ';
                $efmfb_popup_body_style .= '  "';


                $close_color = 'color:'.$efmfb_popup_close_icon_color;



                if( $efmfb_popup_title_img_pos ) $efmfb_popup_title_img_pos = "text-align:".$efmfb_popup_title_img_pos."; ";
                else $efmfb_popup_title_img_pos = "";


                $efmfb_popup_Form_html .= '<div id="efmfb_popup_container" style="display:none;">';
                $efmfb_popup_Form_html .= '<div  id="efmfb_popup_form"  class="'.$efmfb_popup_classes.'" '.$efmfb_popup_style.'  > ';
                $efmfb_popup_Form_html .= '<div class="efmfb-popup-container" >';
                $efmfb_popup_Form_html .= '<div class="efmfb-popup" style="height:'.$efmfb_popup_height.'px; '.$efmfb_popup_body_bg_rgba.'">';
                $efmfb_popup_Form_html .= '<div id="close_popup_container" style="display: block; width: 100%; height: '.$close_height.'px;"><span class="efmfb-close-ui-dialog" style="display:block; cursor:pointer; float:right; padding-top:10px; padding-right:20px; '.$close_color.'">X</span></div>';
                $efmfb_popup_Form_html .= '<div class="efmfb-popup-body-container '.$efmfb_popup_body_classes.'" style="padding:20px;">';
                $efmfb_popup_Form_html .= '<div class="title" '.$efmfb_popup_title_style.'>';
                if($efmfb_popup_title_text) $efmfb_popup_Form_html .= '<div class="title-text"  >'.$efmfb_popup_title_text.'</div>';
                if($efmfb_popup_title_img) $efmfb_popup_Form_html .= '<div class="efmfb-title-img" style="'.$efmfb_popup_title_img_pos.' "><img src="'.$efmfb_popup_title_img.'" /></div>';
                $efmfb_popup_Form_html .= '</div>';//title
                if($efmfb_popup_header_text) $efmfb_popup_Form_html .= '<div class="efmfb-popup-header" '.$efmfb_popup_body_style.' >'.$efmfb_popup_header_text.'</div>';
                $efmfb_popup_Form_html .= '<div class="efmfb-popup-body" '.$efmfb_popup_body_style.'>';
                $efmfb_popup_Form_html .= '<div class="efmfb-popup-body-text" style="opacity:1;">';
                $efmfb_popup_Form_html .= '<div class="efmfb-init-color">';
                $efmfb_popup_Form_html .= $form;
                $efmfb_popup_Form_html .= '</div>';
                $efmfb_popup_Form_html .= '</div>';
                $efmfb_popup_Form_html .= '</div>';
                if($efmfb_popup_footer_text) $efmfb_popup_Form_html .= '<div class="efmfb-popup-footer"  '.$efmfb_popup_body_style.' >'.$efmfb_popup_footer_text.'</div>';
                $efmfb_popup_Form_html .= '</div>';//.efmfb-popup-body-container
                $efmfb_popup_Form_html .= '</div>';//.efmfb-popup
                $efmfb_popup_Form_html .= '</div>';//.efmfb-popup-container
                $efmfb_popup_Form_html .= '</div>';//#efmfb_popup_form
                $efmfb_popup_Form_html .= '</div>';




                $form = $efmfb_popup_Form_html;
            }
            

        return $form;

    }
}
