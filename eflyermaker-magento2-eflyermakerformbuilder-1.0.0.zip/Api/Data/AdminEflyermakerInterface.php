<?php

namespace Eflyermaker\Eflyermakerformbuilder\Api\Data;

interface AdminEflyermakerInterface
{

}