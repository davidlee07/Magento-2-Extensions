var config = {
map: {
    "*": {

        efmfb_jquery: "Eflyermaker_Eflyermakerformbuilder/js/jquery/jquery-1.11.3.min",
        efmfb_jquery_ui: "Eflyermaker_Eflyermakerformbuilder/js/jquery-ui/1.11.4/jquery-ui.min",
        efmfb_globals: "Eflyermaker_Eflyermakerformbuilder/js/efmfb_globals",
        efmfb_noconflict: "Eflyermaker_Eflyermakerformbuilder/js/noconflict",
        efmfb_popup_options: "Eflyermaker_Eflyermakerformbuilder/js/efmfb_popup_options",
        efmfb_popup_setup: "Eflyermaker_Eflyermakerformbuilder/js/efmfb_popup_setup",
        noUiSlider: "Eflyermaker_Eflyermakerformbuilder/js/noUiSlider.8.3.0/nouislider",
        wNumb: "Eflyermaker_Eflyermakerformbuilder/js/noUiSlider.8.3.0/wNumb",
        bPopup:"Eflyermaker_Eflyermakerformbuilder/js/jquery.bpopup"
    }
}
};

require.config(config);