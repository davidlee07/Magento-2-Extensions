require(['jquery', 'jquery/ui'],function($){

/*
efmfb-inputtype : 
0 - button
1 - int
2 - L int
3 - varchar (email)
4 - Text
5 - select
6 - 
7 - 
8 - float
*/









// ==== GLOBALS ====


var admin_url = "";//gParams.admin_url;
var plugin_url = "";//gParams.plugin_url;
var plugin_path = "";//gParams.plugin_path;


$.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};


//======================

function goTo(elem)
{
	if(typeof elem == "undefined" || elem == '' || elem== 'top')
	{
		elem = 'body';
	}

	var offset = -100;

    $('html, body').stop(true, true).animate({
        scrollTop: $(elem).offset().top + offset
    }, 800);


}


//======================

function showMessage(txt, type) {
    var html = '<ul class="messages"><li class="'+type+'-msg"><ul><li>' + txt + '</li></ul></li></ul>';
    $('messages').update(html);
}



//======================




	
// 	var error_timeout;


// 	function efmfb_display_msg(msg, t)
// 	{

// console.log('efmfb_display_msg');
// 		var error_div = $('#efmfb_admin_error');
// 		var d = ( typeof t !== 'undefined' ) ? t : 8000; 

// 		if( typeof error_timeout !== 'undefined') clearTimeout( error_timeout );

// 		error_div.html( msg );

// 		error_div.hide().slideDown('slow');

// 		error_timeout = setTimeout(function(){ dismiss_msg();}, d);

// 	}

// 	function dismiss_msg()
// 	{
// 		var error_div = $('#efmfb_admin_error');
// 		error_div.slideUp('slow', function(){
// 			error_div.empty();
// 		});
// 	}
//============================================



function hexToRgba(color, opacity)
{
	console.log('color : '+color);
	var rgbaColor = '';
	if(color)
	{
		rgbaColor = 'rgba(' + parseInt(color.slice(-6,-4),16)
	    + ',' + parseInt(color.slice(-4,-2),16)
	    + ',' + parseInt(color.slice(-2),16)
	    +','+opacity+')';		
	}


return rgbaColor;
}









function SelectText(element) {
    var doc = document
        , range, selection
    ;    
    if (doc.body.createTextRange) {
        range = document.body.createTextRange();
        range.moveToElementText(element);
        range.select();
    } else if (window.getSelection) {
        selection = window.getSelection();        
        range = document.createRange();
        range.selectNodeContents(element);
        selection.removeAllRanges();
        selection.addRange(range);
    }
}



//=============== COLORS CONVERSIONS =========================

function rgbToHex(r, g, b) {
    return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}






// Here's a version of hexToRgb() that also parses a shorthand hex triplet such as "#03F":
function hexToRgb(hex) {
    // Expand shorthand form (e.g. "03F") to full form (e.g. "0033FF")
    var shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
    hex = hex.replace(shorthandRegex, function(m, r, g, b) {
        return r + r + g + g + b + b;
    });

    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}


// ==== /GLOBALS ====






//=====================================

var eFlyerMakerForm = new Object();

function eFlyerMakerForm_init()
{
	eFlyerMakerForm.inList = 1;
	eFlyerMakerForm.inRadio = 1;	
	eFlyerMakerForm.user_input_num = 0;	
}

eFlyerMakerForm_init();

//=====================================



function goTo(elem)
{
	if(typeof elem == "undefined" || elem == '' || elem== 'top')
	{
		elem = 'body';
	}

	var offset = -100;

    $('html, body').stop(true, true).animate({
        scrollTop: $(elem).offset().top + offset
    }, 600);
}



function setVisible( elem )
{
	elem.css('visibility', 'visible');
}

function setInvisible( elem )
{
	elem.css('visibility', 'hidden');
}







$('#efmfb_empty_form_layout').on('click', function(){
	$('#efmfb_form_container').empty();
});



// $('#efmfb_save_form').on('click', function(){

// $('#efmfb_form_structure').val($('#efmfb_form_container').html());

// 	$('#efmfb_create_info_form').submit();

// });



//=================  Form Inputs Options

$('#close_form_contents_options').on('click', function(){
	$('#form_contents_options_container').slideUp('fast');
});



function setFormContentsOptionsPosition()
{

var left_container = $('.efmfb_container_l');
var left_container_pos = left_container.position();
var left_container_width = left_container.width();
var form_contents_options_width = $('#form_contents_options_container').width();


// console.log('left_container_width : '+left_container_width);
// console.log('left_container_pos.left : '+left_container_pos.left);

$('#form_contents_options_container').css('top', left_container_pos.top+50 );
$('#form_contents_options_container').css('left', left_container_width+left_container_pos.left - form_contents_options_width );

}


if( $('#form_contents_options_container').length ) setFormContentsOptionsPosition();



// on click outside the form area
$(document).click(function(event) { 
    if(!$(event.target).closest('#efmfb_form_container').length && !$(event.target).closest('#form_contents_options_container').length) 
    {
    	$('.efmfb-form-group').removeClass('efmfb-active-input');
    	$('#form_contents_options_container').slideUp('fast');
    }        


    // hide message 
	if( !$(event.target).closest('#efmfb_admin_error').length  && $('#efmfb_admin_error').is(':visible')  )
	{
		dismiss_msg();
	}

})



$( "#form_contents_options_container" ).draggable({
	handle:"#form_contents_options_handle"
	// containment: "parent"
});




//=========== Make form sortable ============



$( "#efmfb_form_container" ).sortable({
	// handle: ".handle"
});


$( "#efmfb_form_container" ).on( "sortstart", function( event, ui ) {
// $('.efmfb_form_container').trigger('click');
// console.log(ui.item[0]);
var elem = ui.item[0];
// if($(elem).hasClass('efmfb_form_container') )
{
	// console.log('has class');
	$('.efmfb-form-group').removeClass('efmfb-active-input');
	$('#form_contents_options_container').slideUp('fast');
	// $(elem).addClass('efmfb-active-input');
	// $(elem).triiger('click');
}
} );

$( "#efmfb_form_container" ).disableSelection();

//===========


$('#efmfb_form_info').on('click', function(){
		var self = $(this);

	$('#efmfb_form_options').slideToggle();

});


$('.efmfb-form-input-title-toggle').on('click', function(){
	var self = $(this);

	var target = self.attr('efmfb-target');
	if( !$('#'+target).hasClass('efmfb-visible'))
	{	
		if( self.hasClass('active') ) 
		{
			self.removeClass('active');
			$('#'+target).slideUp('fast');
		}
		else
		{
			$('.efmfb-form-input-title-toggle.active').parent().find('.efmfb-create-form-options').slideUp('fast', function(){});
			$('.efmfb-form-input-title-toggle').removeClass('active');
			self.addClass('active');
			$('#'+target).slideDown('fast');
		}
	}
});






$('.efmfb-clear-form').on('click', function(){
	$(this).closest("form").trigger("reset");
});





$('#add_to_list_group').on('click', function(){

++eFlyerMakerForm.inList;

var add_to_list = '';
add_to_list += '<div  id="add_to_list_group'+eFlyerMakerForm.inList+'" class="add-to-list-group">';
add_to_list += '<div class="efmfb-inline" style="width:48%;">';
add_to_list += '<input id="create_list_text'+eFlyerMakerForm.inList+'" class="efmfb-form-control" placeholder="Text" type="text" />';
add_to_list += '</div>';
add_to_list += '<div class="efmfb-inline" style="width:48%;">';
add_to_list += '<input id="create_list_val'+eFlyerMakerForm.inList+'" class="efmfb-form-control" placeholder="Value" type="text" />';
add_to_list += '</div>';
add_to_list += '</div>';


$('#efmfb_add_to_list_container').append(add_to_list);

});


$('#remove_from_list_group').on('click', function(){
	if( eFlyerMakerForm.inList > 1 )
	{
		$('#add_to_list_group'+eFlyerMakerForm.inList).remove();
		--eFlyerMakerForm.inList;
	}
});



// =============  ADD NEW TEXT INPUT BY USER ==================

$('#efmfb_create_text_input_btn').on('click', function(e){
e.preventDefault();
var source = $('#efmfb_create_text_input_form');



var create_input_required = source.find('#efmfb_create_input_required').is(':checked');
var create_input_hidden = source.find('#efmfb_create_input_hidden').is(':checked');
var create_input_hide_label = source.find('#efmfb_create_input_hide_label').is(':checked');
var create_input_name = source.find('#efmfb_create_input_name').val();
var create_input_label = source.find('#efmfb_create_input_label').val();
var create_input_val = source.find('#efmfb_create_input_val').val();
var create_input_placeholder = source.find('#efmfb_create_input_placeholder').val();
var create_input_desc = source.find('#efmfb_create_input_desc').val();
var create_input_classes = source.find('#efmfb_create_input_classes').val();
var create_input_styles = source.find('#efmfb_create_input_styles').val();
var create_input_error_msg = source.find('#efmfb_create_input_error_msg').val();


if( create_input_desc.length ) create_input_desc = '('+create_input_desc+')';

var type = 'text';
if( create_input_hidden ) type = 'hidden';

var required = '';

if( create_input_required ) required = 'required';

// console.log('required : '+required);


++eFlyerMakerForm.user_input_num;

var input_html = '';
input_html += '<div id="user_input_'+eFlyerMakerForm.user_input_num+'" class="efmfb-form-group">';
input_html += '<label class="efmfb-label">'+create_input_label+'</label> <span class="efmfb_input_desc">'+create_input_desc+'</span>';
input_html += '<input type="'+type+'"  name="'+create_input_name+'" class="efmfb-form-control '+create_input_classes+'" style="'+create_input_styles+'" placeholder="'+create_input_placeholder+'" value="'+create_input_val+'" '+required+' efmfb-input="1" efmfb-inputtype="3" efmfb-isuser="1"/>';
input_html += '<div class="efmfb-errors">'+create_input_error_msg+'</div>';
input_html += '</div>';

// $('#efmfb_form_container').find('#efmfb_submit_form_btn').before(input_html);
$('#efmfb_form_container').append( input_html );

source.trigger("reset");// clear data

goTo('#user_input_'+eFlyerMakerForm.user_input_num);

});

//==================================================================







function CreateFormFromJson( form_json )
{

	var form_html = '';

	$.each(form_json.inputs,function(index, input){
	   var type = input.type;
	   var type_id = input.type_id;
	   var name = input.name;
	   var val = input.value;
	   var label_text = input.description;
	   var is_mandatory = input.is_mandatory;
	   var required = '';


	   if( is_mandatory == 1 ) required = 'required';

	if( type == 'text')
	{
		form_html += '<div class="efmfb-form-group" efmfb-inputtype="'+type_id+'">';	
		form_html += '<label class="efmfb-label">'+label_text+'</label> <span class="efmfb_input_desc"></span>';	
		form_html += '<input type="text" name="'+name+'" efmfb-input="1" efmfb-isuser="0" efmfb-isrequired="'+required+'" value="" class="efmfb-form-control" '+required+'/>';
		form_html += '<div class="efmfb-errors"></div>';
		form_html += '</div>';
	}
	else if(type == 'email')
	{
		form_html += '<div class="efmfb-form-group " efmfb-inputtype="'+type_id+'">';	
		form_html += '<label class="efmfb-label">'+label_text+'</label> <span class="efmfb_input_desc"></span>';	
		form_html += '<input type="email" name="'+name+'" efmfb-input="1" efmfb-isuser="0" efmfb-isrequired="'+required+'" value="" class="efmfb-form-control" '+required+'/>';
		form_html += '<div class="efmfb-errors"></div>';
		form_html += '</div>';
	}
	else if(type == 'select')
	{
		form_html += '<div class="efmfb-form-group " efmfb-inputtype="'+type_id+'">';	
		form_html += '<label class="efmfb-label">'+label_text+'</label> <span class="efmfb_input_desc"></span>';	
		form_html += '<select name="'+name+'" efmfb-input="1" efmfb-isuser="0" efmfb-isrequired="'+required+'" class="efmfb-form-control" '+required+' >';
		// var optionsList = input.value.split('/');
		// for(i in optionsList)
		// {
		// 	form_html += '<option value="yes">Yes</option>';	
		// }
		form_html += '<option value="yes">Yes</option>';
		form_html += '<option value="no">No</option>';
		form_html += '</select>';
		form_html += '<div class="efmfb-errors"></div>';
		form_html += '</div>';
	}

	});


	return form_html;


}


$('#efmfb_create_form_info_btn').on('click', function(e){

	e.preventDefault();
	var form_name = $('#create_info_name').val(); 
	var form_desc = $('#create_info_desc').val(); 
	var form_classes = $('#create_info_classes').val(); 
	// var btn_text = $('#create_info_btn_text').val();
	// var form_publication_key = $('#create_info_publication_key').val(); 
	
	var form_json = null;
	if( $('#efmfb_form_info_json').val() )
	{

		var json_val = jQuery('#efmfb_form_info_json').val();
		try
		{
			form_json = $.parseJSON( json_val );
		}
		catch(err)
		{
			form_json = null;
		}


		// form_json = $.parseJSON( $('#efmfb_form_info_json').val() );
	}

	if( form_json !== null)
	{

		var form_publication_key = form_json.publication_key; 
		var form_lg = form_json.lang;
		var publication_agreement_text = {
										'fr':'Je consens à recevoir cette publication.',
										'en':'I agree to receive this publication.' 
										};
		var consent_policy_text = {
										'fr':'Je consens à recevoir des communications électroniques.',
										'en':'I consent to receive electronic communications.' 
										};
		var send_btn_text = {
							'fr':'Envoyer',
							'en':'Send' 
							};




$("#efmfb_create_info_form").find('#efmfb_form_key').val(form_publication_key);







		var form_html = '';
		form_html += '<input type="hidden" name="action" value="Campaigns_subscribe" />';
		form_html += '<input id="form_publication_key" type="hidden" name="p" value="'+form_publication_key+'" />';
		form_html += '<input  class="efmfb_form_action" type="hidden" name="efmfb_form_action" value="'+form_json.url+'" />';
		form_html += '<input id="form_publication_lang" type="hidden" name="form_lang" value="'+form_lg+'" />';

		form_html += CreateFormFromJson( form_json );



		form_html += '<div class="efmfb-form-group " efmfb-inputtype="100" >';	
		form_html += '<div efmfb-checkbox-container="1">';
		form_html += '<label for="publication_agreement">';
		form_html += '<input type="checkbox" name="publication_agreement" id="publication_agreement" value="1" efmfb-formsource="tinymce" required/> <span class="efmfb-chechbox-text" id="publication_agreement_text">'+publication_agreement_text[form_lg]+'</span>';
		form_html += '</label>';
		form_html += '</div>';
		form_html += '</div>';


		form_html += '<div  class="efmfb-form-group " efmfb-inputtype="100" >';	
		form_html += '<div  efmfb-checkbox-container="1">';
		form_html += '<label for="consent_policy">';
		form_html += '<input type="checkbox" name="consent_policy" id="consent_policy" value="1" efmfb-formsource="tinymce" required /> <span class="efmfb-chechbox-text" id="consent_policy_text">'+consent_policy_text[form_lg]+'</span>';
		form_html += '</label>';
		form_html += '</div>';
		form_html += '</div>';





		form_html += '<div  class="efmfb-form-group handle" efmfb-inputtype="0"  >';	
		form_html += '<input type="submit" id="efmfb_submit_form_btn" class="efmfb-btn" value="'+send_btn_text[form_lg]+'" style="width:200px; margin-top:10px;"/>';
		form_html += '</div>';

		$('#efmfb_form_container').html(form_html);
		// $('#efmfb_form_info').trigger('click');
	}else
	{
		efmfb_display_msg('Not a valid json format!');
		goTo('top');
		// console.log("Error");
	}

return false;
});







//================  ON CHANGE OPTIONS




$('#efmfb_edit_text_input_form input[type="text"], #efmfb_edit_text_input_form textarea').on('input', function(){
	get_text_input_options();
});

$('#efmfb_edit_text_input_form input[type="checkbox"], #efmfb_edit_text_input_form input[type="radio"], #efmfb_edit_text_input_form select').on('change', function(){
	get_text_input_options();
});




//======





$("#efmfb_edit_btn_form input, #efmfb_edit_btn_form textarea").on('change input', function(){
	get_button_options();
});




//============== select

$('#efmfb_edit_list_form input[type="text"], #efmfb_edit_list_form textarea').on('input', function(){

	get_list_options();
});


$('#efmfb_edit_list_form input[type="checkbox"], #efmfb_edit_list_form input[type="radio"], #efmfb_edit_list_form select').on('change', function(){

	get_list_options();
});



//=================  





$('#efmfb_edit_checkbox_form input[type="text"], #efmfb_edit_checkbox_form textarea').on('input', function(){
	get_checkbox_options();
});


$('#efmfb_edit_checkbox_form input[type="checkbox"], #efmfb_edit_checkbox_form input[type="radio"], #efmfb_edit_checkbox_form select').on('change', function(){
	get_checkbox_options();
});






	// if( input.attr('efmfb-isrequired') == 'required' )
	// {
	// 	$('#form_text_options_panel').find('.efmfb_remove_active_input_btn').prop('disabled', true)	
	// }
	// else
	// {
	// 	$('#form_text_options_panel').find('.efmfb_remove_active_input_btn').prop('disabled', false);	
	// }	




//================  REMOVE ACTIVE INPUT FROM FORM ===

$('.efmfb_remove_active_input_btn').on('click', function(){

console.log('remove it');
	var remove_btn = $(this);
	var target = $('.efmfb-form-group.efmfb-active-input');

	if( target.find('[efmfb-isrequired="required"]').length > 0 ) // INPUT IS REQUIRED
	{
		setTimeout(function(){
			efmfb_display_msg('The field is required!');	
		},300);
		
	}
	else 
	{
		$('#form_contents_options_container').slideUp('fast');
		target.remove();
		console.log('removed');
	}	
	
});




//*******************************************
//========== TEXT INPUT PROCESSING ==========  
//*******************************************

//===== when user modify options ( options == to ==> form)
function get_text_input_options()
{
	console.log('get_text_input_options()');
	var source = $('#efmfb_edit_text_input_form');
	var target = $('.efmfb-form-group.efmfb-active-input');

// console.log('source : ');
// console.log(source);
// console.log('target : ');
// console.log(target);
// console.log('============');

	var input = target.find('[efmfb-input="1"]');
	var label = target.find('.efmfb-label');
	var description = target.find('.efmfb_input_desc');
	var error = target.find('.efmfb-errors');

	var name = source.find('#efmfb_edit_input_name').val();
	var value = source.find('#efmfb_edit_input_val').val();
	var placeholder = source.find('#efmfb_edit_input_placeholder').val();
	var classes = source.find('#efmfb_edit_input_classes').val();
	var styles = source.find('#efmfb_edit_input_styles').val();
	var label_text = source.find('#efmfb_edit_input_label').val();
	var error_msg = source.find('#efmfb_edit_input_error').val();
	var desc_text = source.find('#efmfb_edit_input_desc').val();



	if(input.attr("name") === name )
	{

		if( desc_text.length ) desc_text = '('+desc_text+')';
		

		var required = $('#efmfb_edit_input_required').prop('checked');

		if( required )
		{
			// input.addClass("required");
			input.prop('required', true);
		}
		else
		{
			// input.removeClass('required');
			input.prop('required', false);		
		}

		
		var hide_label = $('#efmfb_edit_input_hide_label').prop('checked');

		if( hide_label )
		{
			label.css('display','none');
		}
		else
		{
			label.css('display','block');	
		}


		
		input.attr("value", value);
		input.attr("placeholder", placeholder);
		input.attr("class", classes);
		input.attr("style", styles);

		label.text( label_text )
		if( !hide_label) label.css('display', 'inline-block');
		description.text( desc_text );
		error.text( error_msg );
	}

}


//===== Show available options ( form == to ==> options )
function set_text_input_options()
{



	var source = $('.efmfb-form-group.efmfb-active-input');
	var target = $('#efmfb_edit_text_input_form');

	var input = source.find('[efmfb-input="1"]');
	var label = source.find('.efmfb-label');
	var description = source.find('.efmfb_input_desc');
	var error = source.find('.efmfb-errors');

	var isUserInput = input.attr('efmfb-isuser') == 1 ? true : false;
	var isRequiredByeFlyerMaker = input.attr("efmfb-isrequired") == 'required' ? true : false;
	var is_required = input.prop('required') || ( input.attr('efmfb-isrequired') == "required"  );

	var name = input.attr("name");
	var value = input.attr("value");
	var placeholder = input.attr("placeholder");
	var classes = input.attr("class");
	var styles = input.attr("style");

	var error_msg = error.text();
	// var desc = input.attr("placeholder");

	
	var is_hidden = input.attr('type') == 'hidden' ? true : false;
	var label_is_hidden = !label.is(':visible') && ( label.text().length !== 0 ) ;

	var desc_text = description.text();

	if( desc_text.length )
	{
		desc_text = desc_text.substring( 1, desc_text.length - 1 );
	}



	if( $(input).attr('efmfb-isuser') == "1" ) target.find('#efmfb_edit_input_name').prop('disabled', false);
	else target.find('#efmfb_edit_input_name').prop('disabled', true);


	if( is_required ) 
	{
		target.find('#efmfb_edit_input_required').prop('checked', true);
		if( !isUserInput && isRequiredByeFlyerMaker ) target.find('#efmfb_edit_input_required').prop('disabled', true);
		else target.find('#efmfb_edit_input_required').prop('disabled', false);
	}
	else 
	{
		target.find('#efmfb_edit_input_required').prop('checked', false);
		target.find('#efmfb_edit_input_required').prop('disabled', false);
	}

/*
	if(is_hidden) target.find('#efmfb_edit_input_hidden').prop('checked', true);
	else target.find('#efmfb_edit_input_hidden').prop('checked', false);
*/

	if(label_is_hidden) target.find('#efmfb_edit_input_hide_label').prop('checked', true);
	else target.find('#efmfb_edit_input_hide_label').prop('checked', false);
	

	target.find('#efmfb_edit_input_name').val(name);
	target.find('#efmfb_edit_input_val').val(value);
	target.find('#efmfb_edit_input_placeholder').val(placeholder);
	target.find('#efmfb_edit_input_classes').val(classes);
	target.find('#efmfb_edit_input_styles').val( styles );
	target.find('#efmfb_edit_input_label').val( label.text() );
	target.find('#efmfb_edit_input_desc').val( desc_text );
	target.find('#efmfb_edit_input_error').val( error_msg );

}





//======


$('#efmfb_form_container').on('click', '.efmfb-form-group', function( event ){
	
	event.stopPropagation();


	$('.form-options-panels').hide();




	var self = $(this);
	var input = self.find('[efmfb-input="1"]');


	$('.efmfb-active-input').removeClass('efmfb-active-input');
	self.addClass('efmfb-active-input');
	$('#form_contents_options_container').slideDown('fast');








var efmfb_inputType = self.attr("efmfb-inputtype");

// console.log('efmfb_inputType :'+efmfb_inputType);

		if( efmfb_inputType == 0)
		{
			set_button_options();
			$('#options_panel_title').text(Button_Options);
			$('#form_button_options_panel').fadeIn();
			// console.log('set_button_options()');
		}
		else if( efmfb_inputType == 5)
		{
			set_list_options();
			$('#options_panel_title').text(List_Options);
			$('#form_select_options_panel').fadeIn();


			if( input.attr('efmfb-isrequired') == 'required' )
			{
				$('#form_select_options_panel').find('.efmfb_remove_active_input_btn').addClass('efmfb-btn-muted')	
			}
			else
			{
				$('#form_select_options_panel').find('.efmfb_remove_active_input_btn').removeClass('efmfb-btn-muted');	
			}	
// console.log('set_list_options()');

		}
		else if( efmfb_inputType == 100)
		{
			set_checkbox_options();
			$('#options_panel_title').text(Checkbox_Options);
			$('#form_checkbox_options_panel').fadeIn();
			console.log('set_checkbox_options()');
		}
		else if( efmfb_inputType == 101)
		{
			set_radio_options();
			$('#options_panel_title').text(Radio_Button_Options);
			$('#form_radio_options_panel').fadeIn();
			console.log('set_radio_options()');
		}
		else
		{
			set_text_input_options();
// console.log('set_text_input_options()');
			if( input.attr('efmfb-isrequired') == 'required' )
			{
				$('#form_text_options_panel').find('.efmfb_remove_active_input_btn').addClass('efmfb-btn-muted')	
			}
			else
			{
				$('#form_text_options_panel').find('.efmfb_remove_active_input_btn').removeClass('efmfb-btn-muted');	
			}	
			$('#options_panel_title').text(Input_Text_Options);
			$('#form_text_options_panel').fadeIn();	



			var option_name = $('#efmfb_edit_input_name').val();
			var input_name = $('.efmfb-active-input').find('[efmfb-input="1"]').attr('name');
			console.log('option_name : '+option_name);
			console.log('input_name : '+input_name);
			if(option_name !== input_name)
			{
				console.log('ERROR');
// 				self.trigger('click');
			}
			
		}




var input_name = $('.efmfb-active-input').find('[efmfb-input="1"]').attr('name');
console.log('::: input_name : '+input_name);


});





//*************************************
//========== LIST PROCESSING ==========  
//*************************************


// efmfb_edit_list_required
// efmfb_edit_list_hidden
// efmfb_edit_list_hide_label
// efmfb_edit_list_name
// efmfb_edit_list_label



//===== Show available options ( form == to ==> options )
function set_list_options()
{
	var source = $('.efmfb-form-group.efmfb-active-input');
	var target = $('#efmfb_edit_list_form');

	var input = source.find('[efmfb-input="1"]');

	var isRequiredByeFlyerMaker = input.attr("efmfb-isrequired") == 'required' ? true : false;
	var is_required = input.prop('required') || ( input.attr('efmfb-isrequired') == "required"  );
	// var efmfb_edit_default_list_val = $('#efmfb_edit_default_list_val');

	var label = source.find('.efmfb-label');
	var description = source.find('.efmfb_input_desc');
	var error = source.find('.efmfb-errors');
	var name = input.attr("name");
	var yes_value = input.find("option[value='yes']").text();
	var no_value = input.find("option[value='no']").text();
	var classes = input.attr("class");
	var styles = input.attr("style");

	var is_hidden = input.attr('type') == 'hidden' ? true : false;
	var label_is_hidden = !label.is(':visible') && ( label.text().length !== 0 ) ;

	var isUserInput = input.attr('efmfb-isuser') == 1 ? true : false;

	var desc_text = description.text();

	if( desc_text.length )
	{
		desc_text = desc_text.substring( 1, desc_text.length - 1 );
	}

	if( $(input).attr('efmfb-isuser') == "1" ) target.find('#efmfb_edit_list_name').prop('disabled', false);
	else target.find('#efmfb_edit_list_name').prop('disabled', true);

	if( is_required ) 
	{
		target.find('#efmfb_edit_list_required').prop('checked', true);
		if( !isUserInput && isRequiredByeFlyerMaker ) target.find('#efmfb_edit_list_required').prop('disabled', true);
		else target.find('#efmfb_edit_list_required').prop('disabled', false);
	}
	else 
	{
		target.find('#efmfb_edit_list_required').prop('checked', false);
		target.find('#efmfb_edit_list_required').prop('disabled', false);
	}



		if(label_is_hidden) target.find('#efmfb_edit_list_hide_label').prop('checked', true);
		else target.find('#efmfb_edit_list_hide_label').prop('checked', false);
	

	target.find('#efmfb_edit_list_name').val(name);
	target.find('#efmfb_edit_list_t1').val(yes_value);
	target.find('#efmfb_edit_list_t2').val(no_value);
	target.find('#efmfb_edit_default_list_val option[value="yes"]').text(yes_value);
	target.find('#efmfb_edit_default_list_val option[value="no"]').text(no_value);
	target.find('#efmfb_edit_list_classes').val(classes);
	target.find('#efmfb_edit_list_styles').val( styles );
	target.find('#efmfb_edit_list_label').val( label.text() );
	target.find('#efmfb_edit_list_desc').val( desc_text );
	// target.find('#efmfb_edit_list_error').val( error_msg );



}


//===== when user modify options ( options == to ==> form )
function get_list_options()
{
	console.log('get_list_options()');
	var source = $('#efmfb_edit_list_form');
	var target = $('.efmfb-form-group.efmfb-active-input');

// console.log('source : ');
// console.log(source);
// console.log('target : ');
// console.log(target);
// console.log('============');


	var input = target.find('[efmfb-input="1"]');
	var label = target.find('.efmfb-label');
	var description = target.find('.efmfb_input_desc');
	var error = target.find('.efmfb-errors');

	var name = source.find('#efmfb_edit_list_name').val();
	var yes_value = source.find('#efmfb_edit_list_t1').val();
	var no_value = source.find('#efmfb_edit_list_t2').val();
	var classes = source.find('#efmfb_edit_list_classes').val();
	var styles = source.find('#efmfb_edit_list_styles').val();
	var label_text = source.find('#efmfb_edit_list_label').val();
	var error_msg = source.find('#efmfb_edit_list_error').val();
	var desc_text = source.find('#efmfb_edit_list_desc').val();
	var efmfb_edit_default_list_val = source.find('#efmfb_edit_default_list_val');

	if( desc_text.length ) desc_text = '('+desc_text+')';
	

	var required = $('#efmfb_edit_list_required').prop('checked');

	if( required )
	{
		// input.addClass("required");
		// input.attr("efmfb-isrequired","required");
		input.prop('required', true);
	}
	else
	{
		// input.removeClass('required');
		// input.attr("efmfb-isrequired","");
		input.prop('required', false);		
	}

	
	var hide_label = $('#efmfb_edit_list_hide_label').prop('checked');

	if( hide_label )
	{
		label.css('display','none');
	}
	else
	{
		label.css('display','block');	
	}


	input.attr("name", name);
	input.find("option[value='yes']").text( yes_value );
	input.find("option[value='no']").text( no_value );
	efmfb_edit_default_list_val.find('option[value="yes"]').text(yes_value);
	efmfb_edit_default_list_val.find('option[value="no"]').text(no_value);
	input.attr("class", classes);
	input.attr("style", styles);

	label.text( label_text )
	if( !hide_label) label.css('display', 'inline-block');
	description.text( desc_text );
	error.text( error_msg );






}


$('#efmfb_edit_list_form').find('#efmfb_edit_default_list_val').on('change', function(){

	var val = $(this).val();
	target = $('.efmfb-form-group.efmfb-active-input');
	target.find('option[value="'+val+'"]').attr('selected', 'selected');

});




//***************************************
//========== BUTTON PROCESSING ==========  
//***************************************




// efmfb_edit_btn_text
// efmfb_edit_btn_width
// efmfb_edit_btn_height
// efmfb_edit_btn_classes
// efmfb_edit_btn_styles


//===== Show available options (form form to options)
function set_button_options()
{
	var source = $('.efmfb-form-group.efmfb-active-input');
	var target = $('#efmfb_edit_btn_form');

	var button = source.find('input[type="submit"]');

	var btn_text = button.val();
	var classes = button.attr('class');
	var styles = button.attr('style');
	var align = source.css('text-align');// || 'left';



// console.log('align : '+align);

	target.find('#efmfb_edit_btn_text').val( btn_text );
	target.find('#efmfb_edit_btn_classes').val( classes );
	target.find('#efmfb_edit_btn_styles').val( styles );
	target.find('[efmfb-align="'+align+'"]').prop( 'checked' , true );
}


//===== when user modify options (from options to form)
function get_button_options()
{
	var source = $('#efmfb_edit_btn_form');
	var target = $('.efmfb-form-group.efmfb-active-input');

	var button = target.find('input[type="submit"]');


	var btn_text = source.find('#efmfb_edit_btn_text').val();
	var classes = source.find('#efmfb_edit_btn_classes').val();
	var styles = source.find('#efmfb_edit_btn_styles').val();
	var align = source.find('[name="efmfb_edit_btn_align"]:checked').val();

	target.css('text-align', align);
	button.val( btn_text );
	button.attr('class', classes);
	button.attr('style', styles);



}







//*****************************************
//========== CHECKBOX PROCESSING ==========  
//*****************************************


//===== Show available options (form form to options)
function set_checkbox_options()
{
	var source = $('.efmfb-form-group.efmfb-active-input');
	var target = $('#efmfb_edit_checkbox_form');

	var checkbox = source.find('input[type="checkbox"]');
	var checkbox_container = source.find('[efmfb-checkbox-container]');
	var name = checkbox.attr('name');
	var label = checkbox_container.find('.efmfb-chechbox-text').text();
	var classes = checkbox_container.attr('class');
	var styles = checkbox_container.attr('style');

	target.find('#efmfb_edit_checkbox_name').val( name );
	target.find('#efmfb_edit_checkbox_label').val( label );
	target.find('#efmfb_edit_checkbox_classes').val( classes );
	target.find('#efmfb_edit_checkbox_styles').val( styles );



}


//===== when user modify options (from options to form)
function get_checkbox_options()
{
	var source = $('#efmfb_edit_checkbox_form');
	var target = $('.efmfb-form-group.efmfb-active-input');

	// var name = source.find('#efmfb_edit_checkbox_name').val();
	var label = source.find('#efmfb_edit_checkbox_label').val();
	var classes = source.find('#efmfb_edit_checkbox_classes').val();
	var styles = source.find('#efmfb_edit_checkbox_styles').val();

	var checkbox = target.find('input[type="checkbox"]');
	var checkbox_container = target.find('div[efmfb-checkbox-container]');


	// checkbox.attr('name', name);
	checkbox_container.find('span.efmfb-chechbox-text').text( label );
	checkbox_container.attr('class', classes);
	checkbox_container.attr('style', styles);
}





//*********************************************
//========== RADIO BUTTON PROCESSING ==========  
//*********************************************


//===== Show available options (form form to options)
function set_radio_options()
{
	// var source = $('.efmfb-form-group.efmfb-active-input');
	// var target = $('#efmfb_edit_btn_form');
}


//===== when user modify options (from options to form)
function get_radio_options()
{
	// var source = $('#efmfb_edit_btn_form');
	// var target = $('.efmfb-form-group.efmfb-active-input');
}
















$('.efmfb-panel-heading').on('click', function(){
	var self = $(this);
	self.closest('.efmfb-panel').find('.efmfb-panel-body').slideToggle('fast');
});



$('.efmfb-picker-container .wp-picker-container').each(function(){
var elem = $(this);
// console.log(elem);
elem.css("cssText", "display:inline-block!important; width:auto !important;");
});









//========================




$(document).on('click', '.efmfb-close-shortcode', function(){
	$(this).closest(".efmfb-shortcode-container").remove()
});






$(document).on("click",".efmfb-shortcode-container", function(){
	var elem = $(this).find(".efmfb-shortcode-selection");
	elem.focus();
	elem.select();


})






});//ready