require([ 'jquery', 'jquery/ui', 'efmfb_globals', 'efmfb_popup_options', 'bPopup'], function($){ 




//================== POPUP OPTIONS ======================


//========================= /POPUP OPTIONS ==============================






$(function(){

//=========================================================


var efmfb_popup_obj = new Object();

var efmfb_popup_form_data = $('#efmfb_popup_options_form');




//=============================== SHOW POPUP DEMO ================================





function efmfbGetPopupOptions()
{
    efmfb_popup_obj.efmfb_popup_on_click = "";
	  efmfb_popup_obj.efmfb_popup_classes = efmfb_popup_form_data.find('#efmfb_popup_classes').val();
    efmfb_popup_obj.efmfb_popup_background_color = efmfb_popup_form_data.find('#efmfb_popup_bg_color').val();
    efmfb_popup_obj.efmfb_popup_width = efmfb_popup_form_data.find('#efmfb_popup_width').val();
    efmfb_popup_obj.efmfb_popup_height = efmfb_popup_form_data.find('#efmfb_popup_height').val();
    efmfb_popup_obj.efmfb_popup_bg_img = efmfb_popup_form_data.find('#efmfb_popup_bg_img').val();
    efmfb_popup_obj.efmfb_popup_overlay_color = efmfb_popup_form_data.find('#efmfb_popup_overlay_color').val();
    efmfb_popup_obj.efmfb_popup_overlay_opacity = efmfb_popup_form_data.find('#efmfb_popup_overlay_opacity_slider_val').val();
    efmfb_popup_obj.efmfb_popup_border_color = efmfb_popup_form_data.find('#efmfb_popup_border_color').val();
    efmfb_popup_obj.efmfb_popup_border_radius = efmfb_popup_form_data.find('#efmfb_popup_border_radius_slider_val').val();
    efmfb_popup_obj.efmfb_popup_close_color = efmfb_popup_form_data.find('#efmfb_popup_close_color').val();
    efmfb_popup_obj.efmfb_popup_box_shadow = efmfb_popup_form_data.find('#efmfb_popup_box_shadow').val();
    efmfb_popup_obj.efmfb_popup_header_text = efmfb_popup_form_data.find('#efmfb_popup_header_text').val();
    efmfb_popup_obj.efmfb_popup_footer_text = efmfb_popup_form_data.find('#efmfb_popup_footer_text').val();
    

    // BOX TITLE
    efmfb_popup_obj.efmfb_popup_title = efmfb_popup_form_data.find('#efmfb_popup_title_text').val();
    efmfb_popup_obj.efmfb_popup_title_styles = efmfb_popup_form_data.find('#efmfb_popup_title_styles').val();
    efmfb_popup_obj.efmfb_popup_title_img = efmfb_popup_form_data.find('#efmfb_popup_title_img').val();
    efmfb_popup_obj.efmfb_popup_title_img_pos = efmfb_popup_form_data.find('input[type="radio"][name="efmfb_popup_title_img_pos"]:checked').val();
    efmfb_popup_obj.efmfb_popup_title_color = efmfb_popup_form_data.find('#efmfb_popup_title_color').val();

    // BOX Body
    efmfb_popup_obj.efmfb_popup_body_bg_color = efmfb_popup_form_data.find('#efmfb_popup_body_bg_color').val();
    efmfb_popup_obj.efmfb_popup_body_bg_opacity = efmfb_popup_form_data.find('#efmfb_popup_body_bg_opacity').val();

    efmfb_popup_obj.efmfb_popup_body_styles = efmfb_popup_form_data.find('#efmfb_popup_body_styles').val();
    efmfb_popup_obj.efmfb_popup_body_classes = efmfb_popup_form_data.find('#efmfb_popup_body_classes').val();

    // BOX EFFETS + ANIMATIONS
    // efmfb_popup_obj.efmfb_popup_show_effect = efmfb_popup_form_data.find('#efmfb_popup_show_effect').val();
    // efmfb_popup_obj.efmfb_popup_show_duration = parseInt( efmfb_popup_form_data.find('#efmfb_popup_show_effect_duration').val() );

    // efmfb_popup_obj.efmfb_popup_hide_effect = efmfb_popup_form_data.find('#efmfb_popup_hide_effect').val();
    // efmfb_popup_obj.efmfb_popup_hide_duration = parseInt( efmfb_popup_form_data.find('#efmfb_popup_hide_effect_duration').val() );

	efmfb_popup_obj.efmfb_popup_animatecss_show = efmfb_popup_form_data.find('#efmfb_popup_animatecss_show').val();
	efmfb_popup_obj.efmfb_popup_animatecss_hide = efmfb_popup_form_data.find('#efmfb_popup_animatecss_hide').val();

    efmfb_popup_obj.efmfb_popup_delay = parseInt( efmfb_popup_form_data.find('#efmfb_popup_delay').val() );
    efmfb_popup_obj.efmfb_popup_title_has_body_bgcolor =  efmfb_popup_form_data.find('#efmfb_popup_title_has_body_bgcolor').is(':checked') ? '1' : '0';
    efmfb_popup_obj.efmfb_popup_rotate_in_success =  efmfb_popup_form_data.find('#efmfb_popup_rotate_in_success').is(':checked') ? '1' : '0';


}




efmfbGetPopupOptions();


$('#efmfb_popup_form_options_demo').on('click', function(e){
e.preventDefault();

// set form data to popup
	var efmb_form_demo_container = $('#efmb_form_demo_container').html();
	$('#efmfb_poup_form_content').html(efmb_form_demo_container);
	efmfbGetPopupOptions();
	efmfbSetPopupOptions(efmfb_popup_obj);

});
//=============================== /SHOW POPUP DEMO ================================







    $("#get_this_form_data").change(function(e){
      e.preventDefault();
        var self = $(this);
        var form_id = self.val();

    })









});// ready

















//=========== Demo Popup Form






//============================





var btnColorOptions = {
	change: function(event, ui){
    	// var color = $('#efmfb_edit_btn_bgcolor').val();
    	// $('#efmfb_submit_form_btn').css('background', color);
      // console.log(event);
      // console.log(ui);
      // console.log($(this));
      color = ui.color.toString();
      $(this).parent().find('.efmfb-show-color').css('background-color', color);
    },
    // clear: function() {},// a callback to fire when the input is emptied or an invalid color
    color: false,
    mode: 'hsl',
    controls: {
        horiz: 's', // horizontal defaults to saturation
        vert: 'l', // vertical defaults to lightness
        strip: 'h' // right strip defaults to hue
    },
    hide: true, // hide the color picker by default
    border: true, // draw a border around the collection of UI elements
    target: false, // a DOM element / $ selector that the element will be appended within. Only used when called on an input.
    width: 200, // the width of the collection of UI elements
    palettes: true // show a palette of basic colors beneath the square.
}


$(document).ready(function($){

// $('.efmfb-color-picker-input').prop('disabled', true);

$('.efmfb-color-picker-input').iris( btnColorOptions );
// $('.efmfb-color-picker-input').iris('hide');


});





$(document).ready(function ($) {    
    $('.efmfb-color-picker-input').iris();    
    $(document).click(function (e) {
        if ($(e.target).closest(".colour-picker, .iris-picker, .iris-picker-inner").length == 0 && $(e.target).closest('#efmfb_body_container').length !== 0 ) {
          console.log($(e.target));
            $('.efmfb-color-picker-input').iris('hide');
            // return false;
        }
    });
    $('.efmfb-color-picker-input').click(function (event) {
        $('.efmfb-color-picker-input').iris('hide');
        $(this).iris('show');
        return false;
    });
});





//============================






$(document).ready(function ($) {    
//====== POPUP Body BG opacity ======

efmfb_popup_body_bg_opacity = (typeof efmfb_popup_body_bg_opacity !== 'undefined' && efmfb_popup_body_bg_opacity ) ? efmfb_popup_body_bg_opacity : 0;


var popup_overlay_opacity_range = document.getElementById('efmfb_popup_body_bg_opacity_slider');
var overlayOpacityValueElement = document.getElementById('efmfb_popup_body_bg_opacity');


noUiSlider.create(popup_overlay_opacity_range, {
  start: [ overlayOpacityValueElement.value ],
  step:0.1,
    format: wNumb({
    decimals: 1
  }),
  range: {
    'min': [ 0 ],
    'max': [ 1 ]
  }
});





popup_overlay_opacity_range.noUiSlider.on('update', function( values, handle ) {
  overlayOpacityValueElement.value = values[handle];
});



});











//====== POPUP Overlay opacity ======

efmfb_popup_opacity = (typeof efmfb_popup_opacity !== 'undefined' && efmfb_popup_opacity ) ? efmfb_popup_opacity : 0.7;


// console.log('efmfb_popup_opacity : '+efmfb_popup_opacity);

// $( "#efmfb_popup_overlay_opacity_slider" ).slider({
//       range: "max",
//       min: 0,
//       max: 1,
//       step:0.1,
//       value: efmfb_popup_opacity,
//       slide: function( event, ui ) {
//         $( "#efmfb_popup_overlay_opacity_slider_val" ).val( ui.value );
//       }
//     });
   

//  $( "#efmfb_popup_overlay_opacity_slider_val" ).val( $( "#efmfb_popup_overlay_opacity_slider" ).slider( "value" )  );
   

$(function(){

var popup_overlay_opacity_range = document.getElementById('efmfb_popup_overlay_opacity_slider');
var overlayOpacityValueElement = document.getElementById('efmfb_popup_overlay_opacity_slider_val');
// noUiSlider.create(range, {
//   start: [ 20, 80 ], // Handle start position
//   step: 10, // Slider moves in increments of '10'
//   margin: 20, // Handles must be more than '20' apart
//   connect: true, // Display a colored bar between the handles
//   direction: 'rtl', // Put '0' at the bottom of the slider
//   // orientation: 'vertical', // Orient the slider vertically
//   behaviour: 'tap-drag', // Move handle on tap, bar is draggable
//   range: { // Slider can select '0' to '100'
//     'min': 0,
//     'max': 100
//   }
//   // ,
//   // pips: { // Show a scale with the slider
//   //   mode: 'steps',
//   //   density: 2
//   // }
// });

noUiSlider.create(popup_overlay_opacity_range, {
  start: [ overlayOpacityValueElement.value ],
  step:0.1,
    format: wNumb({
    decimals: 1
  }),
  range: {
    'min': [ 0 ],
    'max': [ 1 ]
  }
});





popup_overlay_opacity_range.noUiSlider.on('update', function( values, handle ) {
  overlayOpacityValueElement.value = values[handle];
});



});





//====== POPUP border radius ======
$(function(){
efmfb_popup_border_radius = (typeof efmfb_popup_border_radius !== 'undefined') ? efmfb_popup_border_radius : 0;
// $( "#efmfb_popup_border_radius_slider" ).slider({
//       range: "max",
//       min: 0,
//       max: 50,
//       value: efmfb_popup_border_radius,
//       slide: function( event, ui ) {
//         $( "#efmfb_popup_border_radius_slider_val" ).val( ui.value );
//       }
//     });
   

//  $( "#efmfb_popup_border_radius_slider_val" ).val( $( "#efmfb_popup_border_radius_slider" ).slider( "value" ));
   


var popup_border_radius_range = document.getElementById('efmfb_popup_border_radius_slider');
var borderRadiusValueElement = document.getElementById('efmfb_popup_border_radius_slider_val');
noUiSlider.create(popup_border_radius_range, {
  start: [ borderRadiusValueElement.value ],
  step:1,
  // tooltips: [  wNumb({ decimals: 1 }) ],
  format: wNumb({
    decimals: 0
  }),
  range: {
    'min': [  0 ],
    'max': [ 50 ]
  }
});




popup_border_radius_range.noUiSlider.on('update', function( values, handle ) {
  borderRadiusValueElement.value = values[handle];
});





});





/*
slider.noUiSlider.on('update', function(){
  addClassFor(lUpdate, 'tShow', 450);
});

slider.noUiSlider.on('slide', function(){
  addClassFor(lSlide, 'tShow', 450);
});

slider.noUiSlider.on('set', function(){
  addClassFor(lSet, 'tShow', 450);
});

slider.noUiSlider.on('change', function(){
  addClassFor(lChange, 'tShow', 450);
});

slider.noUiSlider.on('start', function(){
  addClassFor(lStart, 'tShow', 450);
});

slider.noUiSlider.on('end', function(){
  addClassFor(lEnd, 'tShow', 450);
});
*/
//=========================


});