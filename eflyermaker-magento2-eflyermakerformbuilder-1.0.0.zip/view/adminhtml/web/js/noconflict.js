require([ 'jquery'], function($){ 
jQuery.noConflict();
});
