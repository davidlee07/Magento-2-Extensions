// 
 


function efmfbSetPopupOptions(efmfb_popup_obj) {
	 


require([ 'jquery', 'jquery/ui', 'efmfb_globals'], function($){ 
	 // console.log('efmfb_popup_obj');

    if (typeof efmfb_popup_obj === 'object') {
        //=========================================
        // set form data to popup
        var efmb_form_demo_container = $('#efmb_form_demo_container').html();
        $('#efmfb_poup_form_content').html(efmb_form_demo_container);
        // BOX
        var efmfb_popup_on_click = efmfb_popup_obj.efmfb_popup_on_click;
        var efmfb_popup_classes = efmfb_popup_obj.efmfb_popup_classes;
        var efmfb_popup_background_color = efmfb_popup_obj.efmfb_popup_background_color;
        var efmfb_popup_width = efmfb_popup_obj.efmfb_popup_width;
        var efmfb_popup_height = efmfb_popup_obj.efmfb_popup_height;
        var efmfb_popup_bg_img = efmfb_popup_obj.efmfb_popup_bg_img;
        var efmfb_popup_overlay_color = efmfb_popup_obj.efmfb_popup_overlay_color;
        var efmfb_popup_overlay_opacity = efmfb_popup_obj.efmfb_popup_overlay_opacity;
        var efmfb_popup_border_color = efmfb_popup_obj.efmfb_popup_border_color;
        var efmfb_popup_border_radius = efmfb_popup_obj.efmfb_popup_border_radius;
        var efmfb_popup_close_color = efmfb_popup_obj.efmfb_popup_close_color;
        var efmfb_popup_box_shadow = efmfb_popup_obj.efmfb_popup_box_shadow;
        var efmfb_popup_header_text = efmfb_popup_obj.efmfb_popup_header_text;
        var efmfb_popup_footer_text = efmfb_popup_obj.efmfb_popup_footer_text;


        // BOX TITLE
        var efmfb_popup_title_text = efmfb_popup_obj.efmfb_popup_title;
        var efmfb_popup_title_styles = efmfb_popup_obj.efmfb_popup_title_styles;
        var efmfb_popup_title_img = efmfb_popup_obj.efmfb_popup_title_img;
        var efmfb_popup_title_img_pos = efmfb_popup_obj.efmfb_popup_title_img_pos;
        var efmfb_popup_title_color = efmfb_popup_obj.efmfb_popup_title_color;
        // BOX Body
        var efmfb_popup_body_bg_color = efmfb_popup_obj.efmfb_popup_body_bg_color;
        var efmfb_popup_body_bg_opacity = efmfb_popup_obj.efmfb_popup_body_bg_opacity;
        var efmfb_popup_body_styles = efmfb_popup_obj.efmfb_popup_body_styles;
        var efmfb_popup_body_classes = efmfb_popup_obj.efmfb_popup_body_classes;
        var efmfb_popup_animatecss_show = efmfb_popup_obj.efmfb_popup_animatecss_show;
        var efmfb_popup_animatecss_hide = efmfb_popup_obj.efmfb_popup_animatecss_hide;
        var efmfb_popup_delay = efmfb_popup_obj.efmfb_popup_delay;
        var efmfb_popup_title_has_body_bgcolor = efmfb_popup_obj.efmfb_popup_title_has_body_bgcolor;

        // console.log('efmfb_popup_animatecss_show : '+efmfb_popup_animatecss_show);
        $('#efmfb_poup_header_text').html(efmfb_popup_header_text);
        $('#efmfb_poup_footer_text').html(efmfb_popup_footer_text);




        // console.log("efmfb_popup_bg_img : "+efmfb_popup_bg_img);

         if(efmfb_popup_on_click !== '') efmfb_popup_delay = 0;

         

        //****** DELAY **********
        setTimeout(function() {
        var efmfb_popup_style = 'style="';
        efmfb_popup_style += 'width:'+efmfb_popup_width+'px; ';
        efmfb_popup_style += 'box-shadow:'+efmfb_popup_box_shadow+'; ';
        if( efmfb_popup_background_color ) efmfb_popup_style += 'background-color:'+efmfb_popup_background_color+';';
        if( efmfb_popup_bg_img ) efmfb_popup_style += 'background-image:url('+efmfb_popup_bg_img+') ; background-repeat:no-repeat; background-position:center;';
        if( efmfb_popup_border_color ) efmfb_popup_style += 'border:1px solid '+efmfb_popup_border_color+';';
        if( efmfb_popup_border_radius ) efmfb_popup_style += 'border-radius:'+efmfb_popup_border_radius+'px;';
        efmfb_popup_style += 'max-height:100%;   padding:0px; overflow-x:hidden; overflow-y:auto;';
        efmfb_popup_style += '"';






        var close_height = '20';

        if(efmfb_popup_body_bg_color )
        {
            body_bg_opacity = '1';
            if(efmfb_popup_body_bg_opacity) body_bg_opacity = efmfb_popup_body_bg_opacity;

            body_bg_rgb = hexToRgb(efmfb_popup_body_bg_color);
            efmfb_popup_body_bg_color = 'rgba('+body_bg_rgb["r"]+','+body_bg_rgb["g"]+','+body_bg_rgb["b"]+','+body_bg_opacity+')';
            $('#efmfb_popup_body_bg_rgba').val(efmfb_popup_body_bg_color);
                
        }


        efmfb_popup_title_style = 'style="';
        efmfb_popup_title_style += efmfb_popup_title_styles;
        efmfb_popup_title_style += 'color: '+efmfb_popup_title_color+';';
        efmfb_popup_title_style += '  font-weight:bold; font-size:18px;"';



        if( efmfb_popup_title_img_pos ) efmfb_popup_title_img_pos = 'text-align:'+efmfb_popup_title_img_pos+'; ';
        else efmfb_popup_title_img_pos = "";


        if(efmfb_popup_body_bg_color) efmfb_popup_body_bg_color = 'background-color:'+efmfb_popup_body_bg_color+';';



        efmfb_popup_body_style = 'style="';
        efmfb_popup_body_style += efmfb_popup_body_styles+' ';
        if(efmfb_popup_body_bg_color )
        {
            // efmfb_popup_body_style += 'background-color:'+efmfb_popup_body_bg_color+"; ";
        }
        // efmfb_popup_body_style += ' padding:10px; ';
        efmfb_popup_body_style += ' "';


        var close_color = 'color:'+efmfb_popup_close_color;



        $('#efmfb_popup_form').remove();

        var efmfb_popup_Form_html = '';
        efmfb_popup_Form_html += '<div  id="efmfb_popup_form"  class="'+efmfb_popup_classes+'" '+efmfb_popup_style+'  > ';
        efmfb_popup_Form_html += '<div class="efmfb-popup-container">';
        // efmfb_popup_Form_html += '<div class="efmfb_popup_form_options"></div>';
        efmfb_popup_Form_html += '<div class="efmfb-popup" style="height:'+efmfb_popup_height+'px; '+efmfb_popup_body_bg_color+'">';
        efmfb_popup_Form_html += '<div id="close_popup_container" style="display: block; width: 100%; height: '+close_height+'px;"><span class="efmfb-close-ui-dialog" style="display:block; cursor:pointer; float:right; padding-top:10px; padding-right:20px; '+close_color+'">X</span></div>';
        efmfb_popup_Form_html += '<div class="efmfb-popup-body-container '+efmfb_popup_body_classes+'" style="padding:20px;">';
        efmfb_popup_Form_html += '<div class="title" '+efmfb_popup_title_style+'  >';
        if(efmfb_popup_title_text) efmfb_popup_Form_html += '<div class="title-text"  style=" ">'+efmfb_popup_title_text+'</div>';
        if(efmfb_popup_title_img) efmfb_popup_Form_html += '<div class="efmfb-title-img" style="'+efmfb_popup_title_img_pos+'"><img src="'+efmfb_popup_title_img+'" /></div>';
        efmfb_popup_Form_html += '</div>';//title
        if(efmfb_popup_header_text) efmfb_popup_Form_html += '<div class="efmfb-popup-header" >'+efmfb_popup_header_text+'</div>';
        efmfb_popup_Form_html += '<div class="efmfb-popup-body" '+efmfb_popup_body_style+'>';
        efmfb_popup_Form_html += '<div class="efmfb-popup-body-text" style="opacity:1;">';
        efmfb_popup_Form_html += '<div class="efmfb-init-color" style="">';
        efmfb_popup_Form_html += $("#efmfb_form_structure").text();
        efmfb_popup_Form_html += '</div>';
        efmfb_popup_Form_html += '</div>';
        efmfb_popup_Form_html += '</div>';
        if(efmfb_popup_footer_text) efmfb_popup_Form_html += '<div class="efmfb-popup-footer"   >'+efmfb_popup_footer_text+'</div>';
        efmfb_popup_Form_html += '</div>';//.efmfb-popup-body-container
        efmfb_popup_Form_html += '</div>';//.efmfb-popup
        efmfb_popup_Form_html += '</div>';//.efmfb-popup-container
        efmfb_popup_Form_html += '</div>';//#efmfb_popup_form

        $('body').append( efmfb_popup_Form_html );



    var efmfb_popup_form = $('#efmfb_popup_form');

    // console.log( options);
    // console.log('content : '+ efmfb_popup_form.text());
        // efmfb_popup_form.dialog(options);
        // efmfb_popup_form.dialog( "open" );


efmfb_bPopup = efmfb_popup_form.bPopup({
    opacity: efmfb_popup_overlay_opacity,
    positionStyle: 'absolute', //'fixed' or 'absolute'
    modalClose: false,
    follow: [true, true], //x, y
    // position: [150, 400] //x, y
    fadeSpeed: 'slow', //can be a string ('slow'/'fast') or int
    followSpeed: 500, //can be a string ('slow'/'fast') or int
    modalColor: efmfb_popup_overlay_color,
    speed: 450,
    modal:true,
    // scrollBar: true,
    appending: false,
    onOpen: function() {
    $('body').addClass('stop-scrolling');
    efmfb_popup_form.addClass('animated ' + efmfb_popup_animatecss_show);

    }, 
    onClose: function() { 
        $('body').removeClass('stop-scrolling');
         }
    }, function(){ }  );







        $(document).on('click', '.efmfb-close-ui-dialog, .efmfb-b-modal', function(){
            efmfb_popup_form.removeClass('animated ' + efmfb_popup_animatecss_show).addClass('animated ' + efmfb_popup_animatecss_hide);
            efmfb_bPopup.close();
        });



        //********** {{ SET OPTIONS }} *************
        var efmfb_dialog = $('.efmfb_dialog_form');
        var efmfb_title = efmfb_dialog.find('.ui-dialog-titlebar');
        var efmfb_popup_body = efmfb_dialog.find('#efmfb_popup_form');
        var efmfb_poup_form_content = efmfb_dialog.find('#efmfb_poup_form_content');
        var efmfb_close_icon = efmfb_title.find('.efmfb-close-ui-dialog');
            $('#efmfb_popup_title_logo').remove();
            //****** BOX STYLES **********
            if (efmfb_popup_border_color) efmfb_popup_border_color = '1px solid ' + efmfb_popup_border_color;
            else efmfb_popup_border_color = '0';
            var box_styles = {
                'background': 'url(' + efmfb_popup_bg_img + ') no-repeat center top',
                'background-color': efmfb_popup_background_color,
                'border': efmfb_popup_border_color,
                'border-radius': efmfb_popup_border_radius + 'px',
                'box-shadow': efmfb_popup_box_shadow
            };
            efmfb_dialog.css(box_styles);
            //****** TITLE STYLES **********
            var box_title_styles = {
                backgroundColor: 'transparent',
                color: efmfb_popup_title_color,
                height: 'auto',
                border: '0'
            };
            var efmfb_dialog_form_ui_titlebar = efmfb_title.attr('style');
            efmfb_title.attr('style', efmfb_dialog_form_ui_titlebar + ' ' + efmfb_popup_title_styles);
            efmfb_title.css(box_title_styles);
            var title_img = '';
            if (efmfb_popup_title_img) 
            {
                title_img_pos_style = 'float:none; margin:0;  display:inline-block';
                if (efmfb_popup_title_img_pos == "center") title_img_pos_style = 'margin:0 auto; display:block;';
                else if (efmfb_popup_title_img_pos == "left") title_img_pos_style = 'margin-right:10px;';
                else if (efmfb_popup_title_img_pos == "right") title_img_pos_style = '';

                title_img = '<img id="efmfb_popup_title_logo" src="' + efmfb_popup_title_img + '" align="'+efmfb_popup_title_img_pos+'" style="' + title_img_pos_style + '"/>';
                $('#efmfb_popup_title_logo').css(title_img_pos_style);
                if (efmfb_popup_title_img_pos == "left" || efmfb_popup_title_img_pos == "center") efmfb_title.find('#close_popup_container').after(title_img);
                else efmfb_title.append(title_img);
            }



            // console.log('rgba : '+hexToRgba(efmfb_popup_body_bg_color, efmfb_popup_body_bg_opacity));
            var box_body_styles = {
            	background:hexToRgba(efmfb_popup_body_bg_color, efmfb_popup_body_bg_opacity)
            }
            efmfb_popup_body.css(box_body_styles);
            // if ($('#efmfb_popup_title_has_body_bgcolor').is(':checked')) efmfb_title.css(box_body_styles);
            // console.log('efmfb_popup_title_has_body_bgcolor : '+efmfb_popup_title_has_body_bgcolor);
            if ( efmfb_popup_title_has_body_bgcolor === '1') efmfb_title.css(box_body_styles);
            //****** BOX CLOSE ICON STYLES **********
            efmfb_close_icon_styles = {
                color: efmfb_popup_close_color
            }
            efmfb_close_icon.css(efmfb_close_icon_styles);
            //****** ANIMATION **********
            efmfb_dialog.addClass('animated ' + efmfb_popup_animatecss_show).one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
                $(this).removeClass('animated ' + efmfb_popup_animatecss_show);
            });



            //****** OVERLAY COLOR + OPACITY  **********
            if (efmfb_popup_overlay_color) efmfb_popup_overlay_color = 'background: ' + efmfb_popup_overlay_color + ';';
            if (efmfb_popup_overlay_opacity) efmfb_popup_overlay_opacity = 'opacity:' + efmfb_popup_overlay_opacity + ';';
            $('<style>.efmfb-ui-widget-overlay { ' + efmfb_popup_overlay_color + ' ' + efmfb_popup_overlay_opacity + ' }</style>').appendTo('body');
            if ($('.efmfb_dialog_form').length > 0) {
                $('.ui-widget-overlay').addClass('efmfb-ui-widget-overlay');
            }
        }, efmfb_popup_delay);
        //=========================================
    } // efmfb_popup is object



});
}








// 










