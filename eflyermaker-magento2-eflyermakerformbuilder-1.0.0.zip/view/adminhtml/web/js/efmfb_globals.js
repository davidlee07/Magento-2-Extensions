require(['jquery'],function($){


var error_timeout;


    
var admin_url = "";//gParams.admin_url;
var plugin_url = "";//gParams.plugin_url;
var plugin_path = "";//gParams.plugin_path;


$.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};







//======================

 window.goTo = function(elem)
{
	if(typeof elem == "undefined" || elem == '' || elem== 'top')
	{
		elem = 'body';
	}

	var offset = -100;

    $('html, body').stop(true, true).animate({
        scrollTop: $(elem).offset().top + offset
    }, 800);


}


//======================

window.showMessage = function(txt, type) {

    var html = '<ul class="messages"><li class="'+type+'-msg"><ul><li>' + txt + '</li></ul></li></ul>';
    $('messages').html(html);
}



//======================




	
	


	window.efmfb_display_msg = function(msg, t, type)
	{


		var msg_div = $('#efmfb_admin_msg');
        var type = ( typeof type !== 'undefined' ) ? type : "success"; 
		var d = ( typeof t !== 'undefined' ) ? t : 8000; 


        msg_div.removeClass("error success info warning").addClass(type);

		if( typeof error_timeout !== 'undefined') clearTimeout( error_timeout );

		msg_div.html( msg );

		msg_div.hide().slideDown('slow');

		error_timeout = setTimeout(function(){ dismiss_msg();}, d);

	}

	window.dismiss_msg = function()
	{
		var msg_div = $('#efmfb_admin_msg');
		msg_div.slideUp('slow', function(){
			msg_div.empty();
		});
	}


$('#efmfb_admin_msg').on("click", function(){
    dismiss_msg();
});


//============================================



 window.hexToRgba = function(color, opacity)
{
	console.log('color : '+color);
	var rgbaColor = '';
	if(color)
	{
		rgbaColor = 'rgba(' + parseInt(color.slice(-6,-4),16)
	    + ',' + parseInt(color.slice(-4,-2),16)
	    + ',' + parseInt(color.slice(-2),16)
	    +','+opacity+')';		
	}


return rgbaColor;
}









window.SelectText = function(element) {
    var doc = document
        , range, selection
    ;    
    if (doc.body.createTextRange) {
        range = document.body.createTextRange();
        range.moveToElementText(element);
        range.select();
    } else if (window.getSelection) {
        selection = window.getSelection();        
        range = document.createRange();
        range.selectNodeContents(element);
        selection.removeAllRanges();
        selection.addRange(range);
    }
}



//=============== COLORS CONVERSIONS =========================

function rgbToHex(r, g, b) {
    return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}






// Here's a version of hexToRgb() that also parses a shorthand hex triplet such as "#03F":
 window.hexToRgb = function(hex) {
    // Expand shorthand form (e.g. "03F") to full form (e.g. "0033FF")
    var shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
    hex = hex.replace(shorthandRegex, function(m, r, g, b) {
        return r + r + g + g + b + b;
    });

    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}


 }); // ready
