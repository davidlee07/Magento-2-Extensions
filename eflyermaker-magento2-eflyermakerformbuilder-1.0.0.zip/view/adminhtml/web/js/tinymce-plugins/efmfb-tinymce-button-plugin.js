( function() {


	/* grab the form data which was passed along */
	var values = jQuery.parseJSON( efmfb_tinymce_forms.data );
	// var translated_notification = alert_translated;
	/* loop over the stored options and decode them for display back to the user */
	/* used to escape quotes and add appropriate spaces */
	var array_length = parseInt( values.length - 1 );
	var i = 0;
	while( i <= array_length ) {
		values[i].text = decodeURI( values[i].text.replace( /\+/g , ' ' ) );
		i++;
	}
	
    tinymce.PluginManager.add( 'efmfb_tinymce_button', function( editor ) {
	
        /* Add eFlyerMaker button that opens a window which contains froms list */
        editor.addButton( 'efmfb_tinymce_button_key', {
			
            image: efmfb_tinymce_forms.tinymce_icon,
			title: efmfb_tinymce_modal_data.button_title,
            onclick: function() {

                /* Open window */
				editor.windowManager.open( {
					title: efmfb_tinymce_modal_data.popup_title,
					body: [
						{
							type: 'listbox',
							name: 'list_id',
							label: efmfb_tinymce_modal_data.list_id_label,
							values: values
						},
						{
							type: 'checkbox',
							name: 'is_popup',
							label: efmfb_tinymce_modal_data.is_popup_label
						}
						
					],      
					id: 'eFlyerMaker_tinyMCE_modal', 
					onsubmit: function( e ) {
						var eFlyerMaker_form_id = e.data.list_id;
						var eFlyerMaker_form_isPopup = e.data.is_popup;

console.log('eFlyerMaker_form_isPopup : '+eFlyerMaker_form_isPopup);

							var shortcode_atts = [];
							shortcode_atts.push( 'form_id="'+eFlyerMaker_form_id+'"' );
							shortcode_atts.push( 'is_popup="'+eFlyerMaker_form_isPopup+'"' );
							editor.insertContent( '[eFlyerMaker-form '+shortcode_atts.join( ' ' )+']' );
						
					}
				} ); // end modal	




				if ( efmfb_no_forms == '1' ) {
					console.log('ji');
					jQuery( '#eFlyerMaker_tinyMCE_modal' ).find( '.mce-foot' ).hide();
					jQuery( '#eFlyerMaker_tinyMCE_modal-body' ).html( '<div style="text-align: center;  padding-top: 25px;">'+efmfb_no_forms_alert+'</div>' );
				}

            }
        } );
    } );
	
} )();