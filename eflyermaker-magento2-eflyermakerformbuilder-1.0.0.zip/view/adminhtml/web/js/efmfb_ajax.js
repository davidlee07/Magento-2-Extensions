jQuery(document).ready(function($) {


//============== SAVE FORM TO DB ==================

	jQuery('#efmfb_save_form').on('click', function(){
		var form_name = jQuery('#efmfb_form_info_name').val();
		

		if(form_name != '')
		{
			save_form();
		}
		else
		{
			efmfb_display_msg('Form name is required')
		}	
		return false;
});








function save_form()
{

		var data = jQuery('#efmfb_create_info_form').serializeObject();
			data['action'] = 'efmfb_save_form';
			data['security'] = ajax_object.security;
			data['efmfb_form_info_structure'] = jQuery('#efmfb_form_container').html();
			data['form_publication_key'] = jQuery('#form_publication_key').val() ? jQuery('#form_publication_key').val() : ''; 
			data['efmfb_form_isEdit'] = jQuery('input#efmfb_form_isEdit').val();
			data['efmfb_form_old_id'] = jQuery('input#efmfb_form_old_id').val();

	var request = jQuery.post(ajax_object.ajax_url, data);
	request.done( function(response) {
		// console.log(response);
		if(response == "-1")
		{
			efmfb_display_msg("Database error!");
			// console.log("-1");
		}
		else
		{
			response = jQuery.parseJSON(response);

			var success = response.success == "1" ? true : false;
			// if( success ) efmfb_display_msg( 'Well done!' ); 
			// else efmfb_display_msg( response.error ); 
			if( ! success ) efmfb_display_msg( response.error ); 


			var redirect = response.redirect;
			// console.log('redirect : '+redirect);
			if( redirect != "0")
			{
				window.location.href = redirect;
			}
		}
				
	});

	 request.fail(function() { efmfb_display_msg("Database error!"); });
  	request.always(function() {  });


}




//============== DUPLICATE FORM ==================

jQuery(document).on('click', '.efmfb-action-duplicate-form', function(){


		var copy_action = jQuery(this); 
		duplicate_manage_row( copy_action );


});


function duplicate_manage_row( copy_action )
{

	 		var tr_container = copy_action.closest('tr');
 		// var first_td = tr_container.find('td:first-child');

		var id = tr_container.attr('efmfb-formid');

		var data = {
					'form_id' : id, 
					'action' : 'efmfb_duplicate_manage_forms',
					'security' : ajax_object.security
					}

		var request = jQuery.post(ajax_object.ajax_url, data);

		request.done( function(response) {
			console.log(response);
			if(response == "-1")
			{
				efmfb_display_msg("Database error!");
			}
			else
			{
				response = jQuery.parseJSON(response);

				var success = response.success == "1" ? true : false;
				if( success ) 
				{
					var duplicated_row = response.duplicated_row;
					var status = ( duplicated_row.form_structure.length > 0 ) ? 'Completed' : 'Editing';

					var row = '';
					row += '<tr efmfb-formid="'+duplicated_row.id+'"  class="efmfb-manage-form-row">';
					row += '<td>'+duplicated_row.form_name+'</td>';
					row += '<td>'+duplicated_row.form_description+'</td>';
					row += '<td>'+status+'</td>';
					row += '<td class="td-creation-date">'+duplicated_row.creation_date+'</td>';
					row += '<td>'+duplicated_row.last_modification+'</td>';
					row += '<td >';
					row += '<a href="'+response.createFormUrl+duplicated_row.id+'"><i class="fa fa-pencil-square-o efmfb-manage-form-actions c-blue efmfb-action-edit-form" title="edit"></i></a> ';
					row +='<i class="fa fa-files-o efmfb-manage-form-actions c-blue efmfb-action-duplicate-form" title="Duplicate"></i> ';
					row += '<i class="fa fa-trash efmfb-manage-form-actions c-red efmfb-action-remove-form" title="Delete" ></i>';
					row += '</td>';
					row += '</tr>';

					tr_container.after(row);
				}	
				else efmfb_display_msg( response.error ); 


			}
					
		});

		 request.fail(function() { efmfb_display_msg("Database error!"); });
	  	request.always(function() {  });
}

//============== DELETE FORM FROM DB ==================

jQuery(document).on('click', '.efmfb-action-remove-form', function(){

var delete_action = jQuery(this);
var tr_container = delete_action.closest('tr');
var first_td = tr_container.find('td:first-child').text();


var confirmation_msg = '';



confirmation_msg += '<span style="margin-right:15px;">This form will be deleted from database! Do you want to continue?</span>';
// confirmation_msg += '<div>';
confirmation_msg += '<span  id="remove_form_db_validated" class="confirmation_btn">YES</span>';
confirmation_msg += '<span id="remove_form_db_dismiss" class="confirmation_btn">NO</span>';
// confirmation_msg += '</div>';

efmfb_display_msg( confirmation_msg , 12000);

jQuery('#remove_form_db_validated').on('click', function(){
	efmfbDeleteForm( delete_action );
});

jQuery('#remove_form_db_dismiss').on('click', function(){
	dismiss_msg();
	

});


return false;
});


function efmfbDeleteForm( delete_action )
{
	

		
		var tr_container = delete_action.closest('tr');
		var first_td = tr_container.find('td:first-child');

		var id = tr_container.attr('efmfb-formid');
		// console.log('id : '+id);
		var data = {
					'form_id' : id, 
					'action' : 'efmfb_delete_form',
					'security' : ajax_object.security
					}

		var request = jQuery.post(ajax_object.ajax_url, data);

		request.done( function(response) {
			console.log(response);
			if(response == "-1")
			{
				efmfb_display_msg("Database error!");
			}
			else
			{
				response = jQuery.parseJSON(response);

				var success = response.success == "1" ? true : false;
				if( success ) 
				{
					efmfb_display_msg( 'Form "'+first_td.text()+'" was deleted with success!' ); 
					tr_container.remove();
				}	
				else efmfb_display_msg( response.error ); 


			}
					
		});

		 request.fail(function() { efmfb_display_msg("Database error!"); });
	  	request.always(function() {  });
}


//============== SORT MANAGE FORMS ==================

var order_dir = 'DESC';

jQuery('.efmfb-sort-forms').on('click', function(){
	var self = jQuery(this);
	reload_manage_forms( self );
});



function reload_manage_forms( self )
{
	var order_by = self.attr('efmfb-orderby');

	var order_icon = [];
		order_icon['DESC'] = '<i class="fa fa-sort-desc efmfb-manage-forms-order"></i>';
		order_icon['ASC'] = '<i class="fa fa-sort-asc efmfb-manage-forms-order"></i>';
		data = {
				'order_by' : order_by,
				'order_dir' : order_dir,
				'action' : 'efmfb_sort_manage_forms',
				'security' : ajax_object.security 
				}
		var request = jQuery.post(ajax_object.ajax_url, data);

		request.done( function(response) {
			// console.log(response);
			if(response == "-1")
			{
				efmfb_display_msg("Database error!");
			}
			else
			{
				response = jQuery.parseJSON(response);
				// console.log(response);
				var success = response.success == "1" ? true : false;
				var data = response.data;
				// console.log(forms_data);
				if( success ) 
				{
					// efmfb_display_msg( '' ); 
					// tr_container.remove();
					var table_container = jQuery('#efmfb_manage_forms_table');
					var table = '';

					table_container.find('.efmfb-manage-forms-order').remove();
					self.append(order_icon[order_dir]);

					for( var i = 0; i < data.length; i++ )
					{
						console.log('data[i].form_description : '+data[i].form_description);
						var status = ( data[i].form_structure.length > 0 ) ? 'Completed' : 'Editing';

						table += '<tr efmfb-formid="'+data[i].id+'"  class="efmfb-manage-form-row">';
						table += '<td>'+data[i].form_name+'</td>';
						table += '<td>'+data[i].form_description+'</td>';
						table += '<td>'+status+'</td>';
						table += '<td class="td-creation-date">'+data[i].creation_date+'</td>';
						table += '<td>'+data[i].last_modification+'</td>';
						table += '<td ><a href="'+response.createFormUrl+data[i].id+'"><i class="fa fa-pencil-square-o efmfb-manage-form-actions c-blue efmfb-action-edit-form" title="edit"></i></a><i class="fa fa-files-o efmfb-manage-form-actions c-blue efmfb-action-duplicate-form" title="Duplicate"></i><i class="fa fa-trash efmfb-manage-form-actions c-red efmfb-action-remove-form" title="Delete" ></i> </td>';
						table += '</tr>';
					}
					table_container.find('.efmfb-manage-form-row').remove();
					table_container.append( table );
					order_dir = ( order_dir == 'DESC' ) ? 'ASC' : 'DESC';
				}	
				else efmfb_display_msg( response.error ); 
			}
					
		});

		 request.fail(function() { efmfb_display_msg("Database error!"); });
	  	request.always(function() {  });	

}



// ==================== SAVE POPUP FORM OPTIONS ==================== 


	jQuery('#efmfb_popup_form_options').on('click', function(){

			save_popup_form_options();
});


function save_popup_form_options()
{

		var data = jQuery('#efmfb_popup_options_form').serializeObject();
			data['action'] = 'efmfb_save_popup_form_options';
			data['security'] = ajax_object.security;


			data['efmfb_popup_bg_color'] = jQuery('#efmfb_popup_bg_color').val();
			data['efmfb_popup_overlay_color'] = jQuery('#efmfb_popup_overlay_color').val();
			data['efmfb_popup_border_color'] = jQuery('#efmfb_popup_border_color').val();
			data['efmfb_popup_close_color'] = jQuery('#efmfb_popup_close_color').val();
			data['efmfb_popup_title_color'] = jQuery('#efmfb_popup_title_color').val();
			data['efmfb_popup_body_bg_color'] = jQuery('#efmfb_popup_body_bg_color').val();
			data['efmfb_popup_title_img_pos'] = jQuery('#efmfb_popup_options_form').find('input[type="radio"][name="efmfb_popup_title_img_pos"]:checked').val();
			data['efmfb_popup_title_has_body_bgcolor'] = jQuery('#efmfb_popup_options_form').find('#efmfb_popup_title_has_body_bgcolor').is(':checked') ? 1 : 0;
			data['efmfb_popup_rotate_in_success'] = jQuery('#efmfb_popup_options_form').find('#efmfb_popup_rotate_in_success').is(':checked') ? 1 : 0;

	var request = jQuery.post(ajax_object.ajax_url, data);
	request.done( function(response) {
		console.log('response');
		console.log(response);
		if(response == "-1")
		{
			efmfb_display_msg("Database error!");
			// console.log("-1");
		}
		else
		{
			response = jQuery.parseJSON(response);

			var success = response.success == "1" ? true : false;
			// if( success ) efmfb_display_msg( 'Well done!' ); 
			// else efmfb_display_msg( response.error ); 
			if( ! success ) efmfb_display_msg( response.error ); 
			else efmfb_display_msg( "Dialog options was successfully saved!" ); 


		}
				
	});

	 request.fail(function() { efmfb_display_msg("Database error!"); });
  	request.always(function() {  });


}




//=========================



	jQuery('#get_this_form_data').on('change', function(){

	var form_id = jQuery(this).val();

			 get_form_data_by_id( form_id );
});




function get_form_data_by_id( form_id )
{

		var data = jQuery('#efmfb_popup_options_form').serializeObject();
			data['action'] = 'efmfb_get_form_data';
			data['security'] = ajax_object.security;
			data['efmfb_form_id'] = form_id;


	var request = jQuery.post(ajax_object.ajax_url, data);
	request.done( function(response) {
		if(response == "-1")
			efmfb_display_msg("Database error!");
		else
		{
			response = jQuery.parseJSON(response);
			var form_data = response.form_data;
			jQuery('#efmb_form_demo_container').html(form_data);
		}
				
	});

	 request.fail(function() { efmfb_display_msg("Database error!"); });
  	request.always(function() {  });


}



//=========================





});

