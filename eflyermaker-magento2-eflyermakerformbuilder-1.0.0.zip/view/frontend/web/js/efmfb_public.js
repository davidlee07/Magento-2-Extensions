






//============================================

function goTo(elem)
{
    if(typeof elem == "undefined" || elem == '' || elem== 'top')
    {
        elem = 'body';
    }

    var offset = -100;
    var elemPos = jQuery(elem).offset().top + offset;
    console.log('elemPos :'+elemPos);
    jQuery('body').stop(true, true).animate({
        scrollTop: elemPos
    }, 600);

    return false;
}

function isEmail( email )
{
    return /^[^@\\s]+@([^@\\s]+\\.)+[^@\\s]+$/.test( email );
}

function startWithZero( value )
{
    return /^0[0-9].*$/.test( value );
}

function filterInt( value ) 
{
  if( /^(\-)?(([0])|([1-9]+\d*))$/.test(value) ) return Number(value);
  return NaN;
}

function isSafeInteger( value )
{
  var safeInt = Math.pow(2, 53) - 1;
  value  = Math.abs(value); 

  return value <= safeInt;
}

function efmfb_isInt( value )
{
    var isInt = true;

    if( value != "0" && value )
    {
        value =  filterInt( value );
        isInt = isSafeInteger( value ) && typeof value === "number" &&  isFinite(value) && Math.floor(value) === value ;        
    }    

    return isInt;

}

//===================================

function filterFloat( value ) 
{
    value =  value.replace(",", ".");


    if(/^(\-)?((([0])|([1-9]+\d*))(\.[0-9]+)?)$/.test(value)) return Number(value);
    
    return NaN;
}



//======================

function efmfb_isFloat( value )
{
    var isFloat = true;

    if( value != "0" && value )
    {
    if(value == '0' || value ) value =  filterFloat( value );
    isFloat =  ( typeof value === "number" &&  isFinite(value) );
        }    

    return isFloat;
}

//========== READY ==============







require([ 'jquery', 'domReady'], function($){ 



//===============================================================================


 jQuery("#efmfb_popup_form").hide();
var efmfb_popup_container = jQuery("#efmfb_popup_container").html();
jQuery("#efmfb_popup_container").empty();
jQuery('body').append(efmfb_popup_container);


function efmfb_bPopup_show()
{
    jQuery('#efmfb_popup_form').removeClass(jQuery("#efmfb_popup_animatecss_hide").val());
    efmfb_bPopup = jQuery('#efmfb_popup_form').bPopup(
    {
        opacity: jQuery("#efmfb_popup_overlay_opacity").val(),
        positionStyle: 'fixed', //'fixed' or 'absolute'
        modalClose: false,
        // follow: [false, false], //x, y
        fadeSpeed: 'slow', //can be a string ('slow'/'fast') or int
        followSpeed: 1500, //can be a string ('slow'/'fast') or int
        modalColor: jQuery("#efmfb_popup_overlay_color").val(),
        speed: 450,
        onOpen: function() {
            jQuery('body').addClass('stop-scrolling');
            jQuery('#efmfb_popup_form').addClass('animated ' + jQuery("#efmfb_popup_animatecss_show").val());
         }, 
        onClose: function() { 
           jQuery('body').removeClass('stop-scrolling');
         }
    }, function(){
        // callback
    });
}





    var delay = jQuery("#efmfb_popup_form_data").find('#efmfb_popup_delay').val();

    var trigger = jQuery("#efmfb_popup_form_data").find('#efmfb_popup_on_click').val();

    console.log(trigger);

    if(trigger) delay = 0;

        setTimeout(function(){

                if(trigger)
                {
                        jQuery(trigger).on('click', function(){
                        var btn_email = jQuery(this).attr('efmfb-email') || '';
                        if( btn_email && $('#'+btn_email).length ) 
                        {
                          var user_email = $('#'+btn_email).val() || '';
                          jQuery('#efmfb_popup_form').find('[name="email"]').val( user_email );
                        }
                        efmfb_bPopup_show();
                        });
                }
                else
                {
                    efmfb_bPopup_show();
                }

        }, delay);





jQuery(document).on('click', '.efmfb-close-ui-dialog, .efmfb-b-modal', function(){
    jQuery('#efmfb_popup_form').removeClass('animated ' + jQuery("#efmfb_popup_animatecss_show").val()).addClass('animated ' + jQuery("#efmfb_popup_animatecss_hide").val());
    efmfb_bPopup.close();

});




//===============================================================================







 var efmfb_popup_form_data = jQuery('#efmfb_popup_form_data');

//=== form errors init
jQuery('form[efmfb-formsource] input, form[efmfb-formsource] select').on('change input click', function(){

    jQuery(this).closest('.efmfb-form-group').removeClass('efmfb-block-error');  
});




// === SUBMIT FORM ====
jQuery('form[efmfb-formsource]').on('submit', function(e){
    e.preventDefault();


    var action_url = $(this).find('.efmfb_form_action').val();
    var efmfb_form_outer_container = $(this).closest('.efmfb_form_outer_container');


    var self = jQuery(this);
    var data = self.serializeArray();
    console.log(data);


    var isPopup = self.closest("#efmfb_popup_form").length > 0 ? true : false;

    var publication_agreement = self.find('[name="publication_agreement"]');
    var consent_policy = self.find('[name="consent_policy"]');

    if(publication_agreement.length > 0 && consent_policy.length > 0)
    {
        if(! publication_agreement.prop('checked')) publication_agreement.closest('.efmfb-form-group').addClass('efmfb-block-error');
        if(! consent_policy.prop('checked')) consent_policy.closest('.efmfb-form-group').addClass('efmfb-block-error');
       
    }


        var errArray = [];

        for(var i=0; i< data.length; i++)
        {
            var name = data[i].name;
            var value = data[i].value;
            var input = self.find('[name="'+name+'"]');
            var hasError = false;



            var required = input.attr('efmfb-isrequired');
            var input_type = input.closest('.efmfb-form-group').attr('efmfb-inputtype');

            var input_val = (input.val() == '' ) ? null : input.val();




            if( input_type == '100' )
            {
                input_val = input.prop('checked') ? 1 : null ;

            }
            else if( input_type == '1' || input_type == '2' ) // int
            {
               var isInt =  efmfb_isInt( input_val );
              
               if( !isInt ) hasError = true;
            }
            else if( input_type == '8' ) // decimal
            {
               var isFloat = efmfb_isFloat( input_val );
              
               if( !isFloat ) hasError = true;
            }

            if( input.attr("type") == "email " && ! isEmail(input_val) ) hasError = true;


            if(required == 'required'  && input_val == null )  hasError = true;

            if( hasError)
            {
                input.closest('.efmfb-form-group').addClass('efmfb-block-error');
                errArray.push(input);
            }
                                
        }


if( typeof errArray[0] !== 'undefined' && errArray[0].length > 0 )
{
    if( !isPopup ) goTo(errArray[0]);
}
else
{
    var ajax_data =  self.serialize();
    ajax_data += '&json=1';

    var ajax_url = action_url+"?"+ajax_data;
    



// 1 : must give consent
// 2 : must agree publication
// 3 : invalid email
// 4 : mandatory field missing
// 5 : user already registered
// 6 : unexpected error
// 7 : max account reached
// 8 : captcha
// 9 : publication list id



            var efmfb_msg = efmfb_form_outer_container.find('#eFlyerMaker_msg');
                
            var success_msg = "";
            success_msg = '<div style="padding:20px;">';
            success_msg += '<h3>Thank you for your interest.</h3>';
            success_msg += '<p>In order to complete, please confirm your subscription by following the steps described in the message sent to the provided email address.</p>';
            success_msg = '</div>';
            var error_msg = "";



var efmfb_popup_rotate_in_success = efmfb_popup_form_data.find('#efmfb_popup_rotate_in_success').val();


    var request = jQuery.ajax({ 
        url:ajax_url+'&callback=?', 
        jsonp: "jsonp", 
        dataType: "JSONP",
        jsonpCallback: "callback",
        type:'GET',
        success: function(data) { 

            console.log(data);

            if(typeof data === 'object')
            {
                var success = data.success;
                var error_type = data.error_type;
                var response_msg = data.response_msg;
                var error_field_name = data.error_field_name;

                if(success == '1')
                {
                    if(isPopup)
                    {
                         var efmfb_popup_form = jQuery('#efmfb_popup_form');

                         console.log('efmfb_popup_rotate_in_success : '+efmfb_popup_rotate_in_success);
                         if(efmfb_popup_rotate_in_success === 'checked')
                            {efmfb_popup_form.attr('class','')
                             efmfb_popup_form.addClass('animated flipInY');
                         }
                         
                         jQuery('.efmfb-popup-body-container').html(response_msg);

                         
                             var el = jQuery(".efmfb-popup");
                             var h = parseInt( jQuery('.efmfb-popup-body-container').outerHeight() )+50;
                             el.animate({ height: h+"px" }, 400 );   
                         
                         


                    }
                    else
                    {

                        efmfb_msg.html(response_msg);
                        removeAlertClasses(efmfb_msg);
                        efmfb_msg.addClass('efmfb-alert-success');

                        self.fadeOut('fast', function(){
                            efmfb_msg.fadeIn();
                        });
                    }
                    
                }
                else
                {
                    if( error_type == '1')
                    {
                        error_msg = '';
                    }
                    else if( error_type == '2')
                    {
                        error_msg = '';
                    }
                    else if( error_type == '3')
                    {
                        error_msg = '';
                    }
                    else if( error_type == '4')
                    {
                        error_msg = '';
                    }
                    else if( error_type == '5')
                    {
                        error_msg = 'The address you have entered is already in our mailing list';
                    }
                    else if( error_type == '6')
                    {
                        error_msg = '';
                    }
                    else if( error_type == '7')
                    {
                        error_msg = '';
                    }
                    else if( error_type == '8')
                    {
                        error_msg = '';
                    }
                    else if( error_type == '9')
                    {
                        error_msg = '';
                    }    

                    efmfb_msg.html(response_msg);
                    removeAlertClasses(efmfb_msg);
                    efmfb_msg.addClass('efmfb-alert-danger');
                    efmfb_msg.fadeIn();
                    
                }


            }
         },
        error: function(error) { efmfb_msg.text('An unexpected error occured. Please try again later.'); },
        jsonpCallback:'callbackName' 
    });

callback = function( data ){
console.log(data);

}



}

});




function removeAlertClasses( element )
{
    element.removeClass('efmfb-alert-success');
    element.removeClass('efmfb-alert-danger');
    element.removeClass('efmfb-alert-warning');
    element.removeClass('efmfb-alert-info');
}



//============== POPUP FORM =============================


function efmfb_popup( options )
{
    efmfb_popup_form.dialog(options);
    efmfb_popup_form.dialog( "open" );
    var close_elem = '';


    jQuery('.efmfb_dialog_form').find('.ui-dialog-titlebar').prepend('<span class="dashicons dashicons-no-alt efmfb-close-ui-dialog" style="display:block; cursor:pointer; width:100%; text-align:right; font-size: 28px;"></span>');


    jQuery('.efmfb-close-ui-dialog').on('click', function(){

            efmfb_popup_form.dialog( "close" );    

    });
}

console.log('efmfb_popup_form_data : '+efmfb_popup_form_data.text());

//======== Show eFlyerMaker Form popup =============
if( efmfb_popup_form_data.length > 0 )
{
    var efmfb_popup_obj = new Object();

    efmfb_popup_obj.efmfb_popup_background_color = efmfb_popup_form_data.find('#efmfb_popup_bg_color').val();
    efmfb_popup_obj.efmfb_popup_overlay_color = efmfb_popup_form_data.find('#efmfb_popup_overlay_color').val();
    efmfb_popup_obj.efmfb_popup_overlay_opacity = efmfb_popup_form_data.find('#efmfb_popup_overlay_opacity').val();
    efmfb_popup_obj.efmfb_popup_animatecss_show = efmfb_popup_form_data.find('#efmfb_popup_animatecss_show').val();
    efmfb_popup_obj.efmfb_popup_animatecss_hide = efmfb_popup_form_data.find('#efmfb_popup_animatecss_hide').val();
    efmfb_popup_obj.efmfb_popup_delay = parseInt( efmfb_popup_form_data.find('#efmfb_popup_delay').val() );
    efmfb_popup_obj.efmfb_popup_rotate_in_success =  efmfb_popup_form_data.find('#efmfb_popup_rotate_in_success').val();
}


//======== /Show eFlyerMaker Form popup =============



$('.efmfb_form_action').each(function(){
    var self = $(this);
    var action = self.val();
    self.closest('form').attr('action', action);
});




});//ready


