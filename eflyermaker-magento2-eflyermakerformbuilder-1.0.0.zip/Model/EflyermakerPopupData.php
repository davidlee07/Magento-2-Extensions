<?php

namespace Eflyermaker\Eflyermakerformbuilder\Model;

use Eflyermaker\Eflyermakerformbuilder\Helper\ConfigHelper;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;


class EflyermakerPopupData extends \Magento\Framework\Model\AbstractModel 
{
   public function _construct()
    {
        $this->_init('Eflyermaker\Eflyermakerformbuilder\Model\Resource\EflyermakerPopupData');
    }


    public function getPopupData()
    {
        
        $popup_data =  $this->load( "1" );

            $efmfb_popup_db_options = array(
            "efmfb_id" => $popup_data->getData('efmfb_id'),
            "efmfb_form_id" => $popup_data->getData('efmfb_form_id'),
            "efmfb_popup_classes" => $popup_data->getData('efmfb_popup_classes'),
            "efmfb_popup_width" => $popup_data->getData('efmfb_popup_width'),
            "efmfb_popup_height" => $popup_data->getData('efmfb_popup_height'),
            "efmfb_popup_bg_img_url" => $popup_data->getData('efmfb_popup_bg_img_url'),
            "efmfb_popup_overlay_color" => $popup_data->getData('efmfb_popup_overlay_color'),
            "efmfb_popup_overlay_opacity" => $popup_data->getData('efmfb_popup_overlay_opacity'),
            "efmfb_popup_border_color" => $popup_data->getData('efmfb_popup_border_color'),
            "efmfb_popup_border_radius" => $popup_data->getData('efmfb_popup_border_radius'),
            "efmfb_popup_close_icon_color" => $popup_data->getData('efmfb_popup_close_icon_color'),
            "efmfb_popup_bg_color" => $popup_data->getData('efmfb_popup_bg_color'),
            "efmfb_popup_box_shadow" => $popup_data->getData('efmfb_popup_box_shadow'),
            "efmfb_popup_footer_text" => $popup_data->getData('efmfb_popup_footer_text'),
            "efmfb_popup_header_text" => $popup_data->getData('efmfb_popup_header_text'),
            "efmfb_popup_title" => $popup_data->getData('efmfb_popup_title'),
            "efmfb_popup_title_color" => $popup_data->getData('efmfb_popup_title_color'),
            "efmfb_popup_title_img_url" => $popup_data->getData('efmfb_popup_title_img_url'),
            "efmfb_popup_title_img_pos" => $popup_data->getData('efmfb_popup_title_img_pos'),
            "efmfb_popup_title_styles" => $popup_data->getData('efmfb_popup_title_styles'),
            "efmfb_popup_title_has_body_bgcolor" => $popup_data->getData('efmfb_popup_title_has_body_bgcolor'),
            "efmfb_popup_body_bg_color" => $popup_data->getData('efmfb_popup_body_bg_color'),
            "efmfb_popup_body_bg_opacity" => $popup_data->getData('efmfb_popup_body_bg_opacity'),
            "efmfb_popup_body_styles" => $popup_data->getData('efmfb_popup_body_styles'),
            "efmfb_popup_body_classes" => $popup_data->getData('efmfb_popup_body_classes'),
            "efmfb_popup_show_effect" => $popup_data->getData('efmfb_popup_show_effect'),
            "efmfb_popup_show_effect_duration" => $popup_data->getData('efmfb_popup_show_effect_duration'),
            "efmfb_popup_hide_effect" => $popup_data->getData('efmfb_popup_hide_effect'),
            "efmfb_popup_hide_effect_duration" => $popup_data->getData('efmfb_popup_hide_effect_duration'),
            "efmfb_popup_show_animation" => $popup_data->getData('efmfb_popup_show_animation'),
            "efmfb_popup_hide_animation" => $popup_data->getData('efmfb_popup_hide_animation'),
            "efmfb_popup_delay" => $popup_data->getData('efmfb_popup_delay'),
            "efmfb_popup_rotate_in_success" => $popup_data->getData('efmfb_popup_rotate_in_success')
                );


        return $efmfb_popup_db_options;
    }


}