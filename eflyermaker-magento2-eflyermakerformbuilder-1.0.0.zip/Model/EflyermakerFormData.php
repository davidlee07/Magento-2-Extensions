<?php

namespace Eflyermaker\Eflyermakerformbuilder\Model;

use Eflyermaker\Eflyermakerformbuilder\Helper\ConfigHelper;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;


class EflyermakerFormData extends \Magento\Framework\Model\AbstractModel 
{
   public function _construct()
    {
        $this->_init('Eflyermaker\Eflyermakerformbuilder\Model\Resource\EflyermakerFormData');
    }

     public function getFormById( $form_id )
     {
                $formModel = $this->load( $form_id );


        return array(
        "efmfb_id" =>  $formModel->getData('efmfb_id'),
        "efmfb_form_key" =>  $formModel->getData('efmfb_form_key'),
        "efmfb_form_name" =>  $formModel->getData('efmfb_form_name'),
        "efmfb_form_description" =>  $formModel->getData('efmfb_form_description'),
        "efmfb_form_structure" =>  $formModel->getData('efmfb_form_structure'),
        "efmfb_custom_classes" =>  $formModel->getData('efmfb_custom_classes'),
        "efmfb_custom_styles" =>  $formModel->getData('efmfb_custom_styles')
            );

         // retrun $formModel;
     }


     public function getformByName( $form_name )
     {
        return $this->getCollection()->addFieldToFilter('efmfb_form_name', $form_name);
        
     }


     public function getNbFormsWithName( $form_name )
     {
        $collection = $this->getformByName( $form_name );
        return $collection->count();
     }






     public function getDuplicatedName( $name )
     {
        $i = 0;

        while( $this->getNbFormsWithName( $name ) > 0)
        {
         // echo $i.'<br>';
         $name .= '_copy';
         ++$i;
        }
        return $name;

     }





    public function getFormsList()
    {
    
         $forms_list = array();
         
         try
         {
                 $collection = $this->getCollection();
                foreach($collection as $data)
                {
                             $form_obj = array(
                                    'efmfb_id' => $data->getData('efmfb_id'),
                                    'efmfb_list_id' => $data->getData('efmfb_list_id'),
                                    'efmfb_form_key' => $data->getData('efmfb_form_key'),
                                    'efmfb_form_name' => $data->getData('efmfb_form_name'), 
                                    'efmfb_form_description' => $data->getData('efmfb_form_description'),
                                    'efmfb_form_structure' => $data->getData('efmfb_form_structure'),
                                    'efmfb_custom_styles' => $data->getData('efmfb_custom_styles'),
                                    'efmfb_custom_classes' => $data->getData('efmfb_custom_classes'),
                                    'efmfb_creation_date' => $data->getData('efmfb_creation_date'),
                                    'efmfb_last_modification' => $data->getData('efmfb_last_modification')
                                     );
                             array_push($forms_list, $form_obj);
                 }
        
  
    
        }
        catch(\Exception $e)
        {
                 
        }


    
       return $forms_list;
    }
    








}