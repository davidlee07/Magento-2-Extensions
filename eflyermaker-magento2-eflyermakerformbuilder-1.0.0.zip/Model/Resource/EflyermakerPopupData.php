<?php

namespace Eflyermaker\Eflyermakerformbuilder\Model\Resource;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class EflyermakerPopupData extends AbstractDb
{
	 /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('eflyermakerformbuilder_popup', 'efmfb_id');
    }
}