<?php

namespace Eflyermaker\Eflyermakerformbuilder\Model\Resource;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class EflyermakerFormData extends AbstractDb
{
    public function _construct()
    {
        $this->_init('eflyermakerformbuilder_form', 'efmfb_id');
    }
}