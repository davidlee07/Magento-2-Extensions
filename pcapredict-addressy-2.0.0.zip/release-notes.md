# Release notes

## v2.0.0

- A fully automated setup.
- User can log in with their account code and password, which will generate a set 
  of keys to get Address lookup running in both Admin area and Customer facing site.