# Addressy - Magento 2 Integration

## _Manual Installation Steps_

### Step 1
- Download the .ZIP file from the [Addressy](URLHERE "Addressy") website.

### Step 2
- Locate **/app/code/** directory which should be under the magento root installation.
- If the **code** folder is not there, create it.
- Create a folder called **PCAPredict/** inside the located **/app/code/**. 
- Create a folder called **Addressy/** in the **PCAPredict/** folder
- Extract the contents of the .ZIP file to the **Addressy/** folder you just created.

### Step 3
- Refer to the Magento 2 documentation for full instructions on how to install an app, the commands should be similar to the following:
```
# This tells magento to install the app.
php bin/magento setup:upgrade
```
```
# You may need to run the following command to flush the Magento cache so the app works correctly:
php bin/magento cache:flush
```

## _App Configuration Options_
The configuration for the extension is located under *Stores* > *Other Settings* > **Addressy Settings**.
#### Main screen
- Email Address - Enter your email address you used to sign up to Addressy here.
- Password - The password you used when you setup the account.

#### Logged in screen
- Back-end custom javascript - This is for any custom javascript to be injected into the back-end of the website when the app loads.
- Front-end custom javascript - This is for any custom javascript to be injected into the front-end of the website when the app loads.