1) copy files

2) update your search form template app\design\frontend\default\default\template\catalogsearch\advanced\form.phtml
if you use a custom package or theme the path might starts from app\design\frontend\blank\modern for example

* add 
        <?php echo Mage::helper('amsearch')->drawCategories() ?> 
right after line
         <ul id="advanced-search-list">

* replase line
<?php switch($this->getAttributeInputType($_attribute)): 
with line
<?php switch(Mage::helper('amsearch')->getAttributeInputType($_attribute, $this)): 


3) update cache and cookies.
