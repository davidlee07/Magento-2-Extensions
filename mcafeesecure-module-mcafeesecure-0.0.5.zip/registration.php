<?php
\Magento\Framework\Component\ComponentRegistrar::register(
	\Magento\Framework\Component\ComponentRegistrar::MODULE,
	'McAfeeSecure_McAfeeSecure',
	__DIR__
);