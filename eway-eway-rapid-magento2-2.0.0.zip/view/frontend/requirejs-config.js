var config = {
    map: {
        '*': {
            ewayrapid: 'https://secure.ewaypayments.com/scripts/eWAY.min.js',
            ewayecrypt: 'https://secure.ewaypayments.com/scripts/eCrypt.min.js',
            ewaytransparent: 'https://api.ewaypayments.com/JSONP/v3/js'
        }
    }
};
