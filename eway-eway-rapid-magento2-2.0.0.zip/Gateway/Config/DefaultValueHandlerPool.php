<?php
namespace Eway\EwayRapid\Gateway\Config;
// @codingStandardsIgnoreFile
class DefaultValueHandlerPool extends \Magento\Payment\Gateway\Config\ValueHandlerPool
{
}
