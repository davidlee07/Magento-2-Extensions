<?php
/**
 * OxisLab_LogMailer
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 * @author      oxismagento@gmail.com
 */

namespace OxisLab\LogMailer\Console\Command;

use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use OxisLab\LogMailer\Cron\LogSender;

/**
 * OxisLab\LogMailer\Console\Command\LogmailerSendCommand
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 */
class LogmailerSendCommand extends AbstractCommand
{
    /**
     * Log sender handler
     *
     * @var LogSender
     */
    protected $_logSender;

    /**
     * Constructor
     *
     * @param LogSender $logSender
     */
    public function __construct(
        LogSender $logSender
    ) {
        $this->_logSender = $logSender;
        parent::__construct();
    }

    /**
     * Initial configuration
     */
    protected function configure()
    {
        $this->setName(self::COMMAND_NAMESPACE.':send')
             ->setDescription('Send all buffered logs');
        parent::configure();
    }

    /**
     * Execute
     *
     * @param InputInterface $input
     * @param OutputInterface $output
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->_logSender->execute();

        $output->writeln('Logs were sent!');
    }
}