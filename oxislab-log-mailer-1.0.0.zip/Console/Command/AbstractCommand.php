<?php
/**
 * OxisLab_LogMailer
 *
 * @category OxisLab
 * @package  OxisLab_LogMailer
 * @author   oxismagento@gmail.com
 */

namespace OxisLab\LogMailer\Console\Command;

use Symfony\Component\Console\Command\Command;

/**
 * OxisLab\LogMailer\Console\Command\AbstractCommand
 *
 * @category OxisLab
 * @package  OxisLab_LogMailer
 */
class AbstractCommand extends Command
{
    /**
     * Common command namespace
     *
     * @var string
     */
    const COMMAND_NAMESPACE = 'logmailer';
}