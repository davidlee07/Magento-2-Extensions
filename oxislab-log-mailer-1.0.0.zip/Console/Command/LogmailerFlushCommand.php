<?php
/**
 * OxisLab_LogMailer
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 * @author      oxismagento@gmail.com
 */

namespace OxisLab\LogMailer\Console\Command;

use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use OxisLab\LogMailer\Model\ResourceModel\Log\Collection;

/**
 * OxisLab\LogMailer\Console\Command\LogmailerFlushCommand
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 */
class LogmailerFlushCommand extends AbstractCommand
{
    /**
     * Collection for working with db
     *
     * @var Collection
     */
    protected $collection;

    /**
     * Constructor
     *
     * @param Collection $collection
     */
    public function __construct(
        Collection $collection
    ) {
        $this->collection = $collection;
        parent::__construct();
    }

    /**
     * Initial configuration
     */
    protected function configure()
    {
        $this->setName(self::COMMAND_NAMESPACE.':flush')
             ->setDescription('Flush all buffered logs');
        parent::configure();
    }

    /**
     * Execute
     *
     * @param InputInterface $input
     * @param OutputInterface $output
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->collection->flush();

        $output->writeln('Logs were removed!');
    }
}