<?php
/**
 * OxisLab_LogMailer
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 * @author      oxismagento@gmail.com
 */

namespace OxisLab\LogMailer\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use OxisLab\LogMailer\Helper\Data as Helper;

/**
 * OxisLab\LogMailer\Model\ResourceModel\Log
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 */
class Log extends AbstractDb
{
    /**
     * Define a db table
     */
    protected function _construct()
    {
        $this->_init(Helper::DB_TABLE, 'entity_id');
    }
}