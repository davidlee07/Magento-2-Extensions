<?php
/**
 * OxisLab_LogMailer
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 * @author      oxismagento@gmail.com
 */

namespace OxisLab\LogMailer\Model\ResourceModel\Log;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use OxisLab\LogMailer\Helper\Data as Helper;

/**
 * OxisLab\LogMailer\Model\ResourceModel\Log\Collection
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 */
class Collection extends AbstractCollection
{
    /**
     * Define a resource model
     */
    protected function _construct()
    {
        $this->_init('OxisLab\LogMailer\Model\Log', 'OxisLab\LogMailer\Model\ResourceModel\Log');
    }

    /**
     * Flush all available logs
     *
     * @return $this
     */
    public function flush()
    {
        $this->getConnection()->truncateTable(Helper::DB_TABLE);

        return $this;
    }
}