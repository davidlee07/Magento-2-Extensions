<?php
/**
 * OxisLab_LogMailer
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 * @author      oxismagento@gmail.com
 */

namespace OxisLab\LogMailer\Model\Config\Source;

use Monolog\Logger;
use Magento\Framework\Option\ArrayInterface;

/**
 * OxisLab\LogMailer\Model\Config\Source\Error
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 */
class Error implements ArrayInterface
{
    /**
     * Available levels
     *
     * @var array
     */
    protected $_levels = [];

    /**
     * Constructor
     */
    public function __construct()
    {
        $levels = Logger::getLevels();
        foreach ($levels as $key => $value) {
            $this->_levels[] = ['value' => $value, 'label' => $key];
        }
    }

    /**
     * Get available options
     * 
     * @return array
     */
    public function toOptionArray()
    {
        return $this->_levels;
    }
}