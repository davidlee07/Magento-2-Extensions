<?php
/**
 * OxisLab_LogMailer
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 * @author      oxismagento@gmail.com
 */

namespace OxisLab\LogMailer\Model;

use Magento\Framework\Model\AbstractModel;

/**
 * OxisLab\LogMailer\Model\Log
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 */
class Log extends AbstractModel
{
    /**
     * Define a resource model
     */
    protected function _construct()
    {
        $this->_init('OxisLab\LogMailer\Model\ResourceModel\Log');
    }
}