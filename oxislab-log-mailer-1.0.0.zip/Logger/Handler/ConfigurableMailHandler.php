<?php
/**
 * OxisLab_LogMailer
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 * @author      oxismagento@gmail.com
 */

namespace OxisLab\LogMailer\Logger\Handler;

use Monolog\Handler\NativeMailerHandler;
use Monolog\Formatter\FormatterInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use OxisLab\LogMailer\Helper\Data as Helper;

/**
 * OxisLab\LogMailer\Logger\Handler\ConfigurableMailHandler
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 */
class ConfigurableMailHandler extends NativeMailerHandler
{
    /**
     * Constructor
     *
     * @param ScopeConfigInterface $config
     * @param FormatterInterface $formatter
     */
    public function __construct(
        ScopeConfigInterface $config,
        FormatterInterface $formatter
    ) {
        $to = explode(Helper::TO_DELIMITER,$config->getValue(Helper::XML_PATH_TO));
        $from = $config->getValue(Helper::XML_PATH_FROM);
        $subject = $config->getValue(Helper::XML_PATH_SUBJECT);
        $level = $config->getValue(Helper::XML_PATH_LEVEL);

        parent::__construct($to, $subject, $from, $level, true, 120);

        $this->setFormatter($formatter);
    }
}