<?php
/**
 * OxisLab_LogMailer
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 * @author      oxismagento@gmail.com
 */

namespace OxisLab\LogMailer\Logger\Handler;

use Monolog\Handler\AbstractProcessingHandler;
use Monolog\Formatter\FormatterInterface;
use OxisLab\LogMailer\Model\LogFactory;
use Magento\Framework\App\Config\Proxy as Config;
use OxisLab\LogMailer\Helper\Data as Helper;

/**
 * OxisLab\LogMailer\Logger\Handler\LogMailerHandler
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 */
class LogMailerHandler extends AbstractProcessingHandler
{
    /**
     * Log Factory
     *
     * @var LogFactory
     */
    protected $_logFactory;

    /**
     * Scope Config Proxy
     *
     * @var Config
     */
    protected $_config;

    /**
     * Flag of processing level
     *
     * @var bool
     */
    protected $_setLevel = false;

    /**
     * Force flag
     *
     * @var bool
     */
    protected $_force = false;

    /**
     * Constructor
     *
     * @param LogFactory $logFactory
     * @param array $processors
     * @param FormatterInterface $formatter
     * @param Config $config
     */
    public function __construct(
        LogFactory $logFactory,
        array $processors = [],
        FormatterInterface $formatter,
        Config $config
    ) {
        parent::__construct();
        $this->_logFactory = $logFactory;
        $this->_config = $config;

        $this->setFormatter($formatter);
        foreach ($processors as $processor) {
            $this->pushProcessor($processor);
        }
    }

    /**
     * Checking possibility to apply the handler
     *
     * @param array $record
     * @return bool
     */
    public function isHandling(array $record)
    {
        $result = $this->_force;
        if ($result) {
            $this->_setLevel();
            $result = parent::isHandling($record);
        }

        return $result;
    }

    /**
     * Set level via Proxy object
     */
    protected function _setLevel()
    {
        if (!$this->_setLevel) {
            $this->level = $this->_config->getValue(Helper::XML_PATH_LEVEL);
            $this->_setLevel = true;
        }
    }

    /**
     * Set force flag
     *
     * @param bool $force
     * @return LogMailerHandler
     */
    public function setForce($force=false)
    {
        $this->_force = $force;

        return $this;
    }

    /**
     * Write a record to db
     *
     * @param array $record
     */
    protected function write(array $record)
    {
        $log = $this->_logFactory->create();
        $log->setMessage($record['formatted'])
            ->setLevel($record['level'])
            ->save();
    }
}