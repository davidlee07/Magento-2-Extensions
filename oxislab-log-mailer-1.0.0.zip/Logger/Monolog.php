<?php
/**
 * OxisLab_LogMailer
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 * @author      oxismagento@gmail.com
 */

namespace OxisLab\LogMailer\Logger;

use Magento\Framework\Logger\Monolog as Original;

/**
 * OxisLab\LogMailer\Logger\Monolog
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 */
class Monolog extends Original
{
    /**
     * Constructor
     *
     * @param string $name
     * @param array $handlers
     * @param array $processors
     */
    public function __construct(
        $name,
        array $handlers = [],
        array $processors = []
    ) {
        //stop overriding standard handlers by Magento_Support
        unset($handlers['report']);
        parent::__construct($name, $handlers, $processors);
    }

    /**
     * Add a record
     *
     * @param  integer $level
     * @param  string  $message
     * @param  array   $context
     * @return bool
     */
    public function addRecord($level, $message, array $context = [])
    {
        parent::addRecord($level, $message, $context);

        //repeat generating of a record for writing it into DB
        $levelName = static::getLevelName($level);
        $record = array(
            'message' => (string) $message,
            'context' => $context,
            'level' => $level,
            'level_name' => $levelName,
            'channel' => $this->name,
            'datetime' => \DateTime::createFromFormat('U.u', sprintf('%.6F', microtime(true)), static::$timezone)->setTimezone(static::$timezone),
            'extra' => array(),
        );

        foreach ($this->processors as $processor) {
            $record = call_user_func($processor, $record);
        }

        //skipping the handler when di.xml isn't loaded yet
        if (isset($this->handlers['logmailer'])) {
            $logMailer = $this->handlers['logmailer'];
            $logMailer->setForce(true);
            $logMailer->handle($record);
            $logMailer->setForce(false); 
        }

        return true;
    }
}