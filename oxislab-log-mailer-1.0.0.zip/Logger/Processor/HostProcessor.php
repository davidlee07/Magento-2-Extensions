<?php
/**
 * OxisLab_LogMailer
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 * @author      oxismagento@gmail.com
 */

namespace OxisLab\LogMailer\Logger\Processor;

/**
 * OxisLab\LogMailer\Logger\Processor\HostProcessor
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 */
class HostProcessor
{
    /**
     * Record host info
     * 
     * @param  array $record
     * @return array
     */
    public function __invoke(array $record)
    {
        $record['extra']['host'] = gethostname();

        return $record;
    }
}