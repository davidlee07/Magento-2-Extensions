<?php
/**
 * OxisLab_LogMailer
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 * @author      oxismagento@gmail.com
 */

namespace OxisLab\LogMailer\Cron;

use Psr\Log\LoggerInterface;
use OxisLab\LogMailer\Model\ResourceModel\Log\CollectionFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use OxisLab\LogMailer\Helper\Data as Helper;

/**
 * OxisLab\LogMailer\Cron\LogSender
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 */
class LogSender
{
    /**
     * Sender logger
     *
     * @var LoggerInterface
     */
    protected $_log;

    /**
     * LogMailer collection factory
     *
     * @var CollectionFactory
     */
    protected $_collectionFactory;

    /**
     * ScopeConfigInterface
     *
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * Constructor
     *
     * @param CollectionFactory    $collectionFactory
     * @param LoggerInterface      $log
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        CollectionFactory $collectionFactory,
        LoggerInterface $log,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->_log = $log;
        $this->_collectionFactory = $collectionFactory;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * Execute
     */
    public function execute()
    {
        if (!$this->scopeConfig->getValue(Helper::XML_PATH_SEND)) {
            return;
        }

        $collection = $this->_collectionFactory->create();
        foreach ($collection as $record) {
            $this->_log->log($record->getLevel(),$record->getMessage());
        }

        $bufferHandler = $this->_log->getHandlers()['default'];
        $bufferHandler->close();

        $collection->flush();
    }
}