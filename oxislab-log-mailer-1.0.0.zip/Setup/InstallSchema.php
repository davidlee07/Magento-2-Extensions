<?php
/**
 * OxisLab_LogMailer
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 * @author      oxismagento@gmail.com
 */

namespace OxisLab\LogMailer\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
use OxisLab\LogMailer\Helper\Data as Helper;

/**
 * OxisLab\LogMailer\Setup\InstallSchema
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 */
class InstallSchema  implements InstallSchemaInterface
{
    /**
     * Install
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();
        $table  = $installer->getConnection()
            ->newTable($installer->getTable(Helper::DB_TABLE))
            ->addColumn(
                'entity_id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Entity Id'
            )
            ->addColumn(
                'level',
                Table::TYPE_INTEGER,
                null,
                ['nullable' => true, 'default' => null],
                'Level'
            )
            ->addColumn(
                'message',
                Table::TYPE_TEXT,
                null,
                ['nullable' => false, 'default' => null],
                'Message'
            )
            ->addColumn(
                'date',
                Table::TYPE_TIMESTAMP,
                null,
                ['nullable' => false, 'default' => Table::TIMESTAMP_INIT],
                'Date'
            )
            ->setComment('Log Mailer');
        $installer->getConnection()->createTable($table);

        $installer->endSetup();
    }
}