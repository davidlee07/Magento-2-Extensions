<?php
/**
 * OxisLab_LogMailer
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 * @author      oxismagento@gmail.com
 */

namespace OxisLab\LogMailer\Helper;

use Magento\Framework\App\Helper\AbstractHelper;

/**
 * OxisLab\LogMailer\Helper\Data
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 */
class Data extends AbstractHelper
{
    /**
     * Path for "to" field
     *
     * @var string
     */
    const XML_PATH_TO = 'system/logmailer/to';

    /**
     * Delimiter of "to" field
     *
     * @var string
     */
    const TO_DELIMITER = ',';

    /**
     * Path for "from" field
     *
     * @var string
     */
    const XML_PATH_FROM = 'system/logmailer/from';

    /**
     * Path for email "subject" field
     *
     * @var string
     */
    const XML_PATH_SUBJECT = 'system/logmailer/subject';

    /**
     * Path for "level" field
     *
     * @var string
     */
    const XML_PATH_LEVEL = 'system/logmailer/level';

    /**
     * Path for "send" field
     *
     * @var string
     */
    const XML_PATH_SEND = 'system/logmailer/send';

    /**
     * Db table name
     *
     * @var string
     */
    const DB_TABLE = 'logmailer';
}