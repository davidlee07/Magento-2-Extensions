<?php
/**
 * OxisLab_LogMailer
 *
 * @category    OxisLab
 * @package     OxisLab_LogMailer
 * @author      oxismagento@gmail.com
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'OxisLab_LogMailer',
    __DIR__
);