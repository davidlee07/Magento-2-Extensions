LogMailer provides an ability to accumulate necessary system logs in db and later sending them to one or several support team members.

That's utterly helpful when it's required to check health of a multi instanced site (more than 1 server) or even just a common site via email notification instead of checking log files on server via an ssh/ftp client.

The problem of multi instanced sites is that errors can happen on different servers (e.g. import feed runs on 1st server, frontend runs on 2nd and admin on another one and so on), errors can be put into different files and find the correct file and server afterwards some times can be very painful. 

The solution resolves the issue by accumulating all logs from all instances into DB, adding to the logs information about host, requested url and sending auto email notifications about issues for a period of time.

### System Requirements:

1) Magento 2 CE/EE version.

2) For auto sending reports cron must be setup on your server otherwise please use "logmailer:send" shell command.

### How to use:
1) Go to Admin > Stores > Configuration > Advanced > System > Log Mailer.

2) Fill the following information : To, From, Subject. The information will be used for auto log reports.

3) Select a required minimum level of errors. Emails will have only selected and higher error level emails. DEBUG and INFO levels are recommended not to choose for avoiding unnecessary notifications.

4) Set necessary cron time. At selected time magento will be generating auto emails and send them to people, who listed in "To" field.

5) Click save.

6) Flush cache.

### List of available shell commands

1) Send all accumulated logs, which have been saved from last sending time up to the moment.
```sh
$ php bin/magento logmailer:send
```
2) Flush all accumulated logs.
```sh
$ php bin/magento logmailer:flush
```