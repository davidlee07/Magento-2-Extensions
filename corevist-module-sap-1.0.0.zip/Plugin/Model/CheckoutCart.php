<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Plugin\Model;

use Corevist\SAP\Helper\Data as SapHelper;

class CheckoutCart
{
    /**
     * SAP helper
     *
     * @var \Corevist\SAP\Helper\Data
     */
    private $sapHelper;

    /**
     * @param \Corevist\SAP\Helper\Data $sapHelper
     */
    public function __construct(SapHelper $sapHelper)
    {
        $this->sapHelper = $sapHelper;
    }

    /**
     * Get correct items number from sap
     *
     * @param \Magento\Checkout\Model\Cart $subject
     * @param \Closure $proceed
     *
     * @return int|float
     *
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function aroundGetSummaryQty(\Magento\Checkout\Model\Cart $subject, \Closure $proceed)
    {
        if ($this->sapHelper->isIntegrationEnabled()) {
            if ($corevistUser = $this->sapHelper->getCorevistUser()) {
                return (int)$corevistUser->getCartItems();
            } else {
                return 0;
            }
        } else {
            return $proceed();
        }
    }
}
