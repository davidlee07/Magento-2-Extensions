<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Plugin\Model;

use Corevist\SAP\Helper\Data as SapHelper;

class CustomerUrl
{
    /**
     * SAP helper
     *
     * @var \Corevist\SAP\Helper\Data
     */
    private $sapHelper;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    private $urlBuilder;

    /**
     * @param \Corevist\SAP\Helper\Data $sapHelper
     * @param \Magento\Framework\UrlInterface $urlBuilder
     */
    public function __construct(
        SapHelper $sapHelper,
        \Magento\Framework\UrlInterface $urlBuilder
    ) {
        $this->sapHelper = $sapHelper;
        $this->urlBuilder = $urlBuilder;
    }

    /**
     * Change a password recovery url with the Corevist one
     *
     * @param \Magento\Customer\Model\Url $subject
     * @param string $result
     *
     * @return string
     *
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterGetForgotPasswordUrl(\Magento\Customer\Model\Url $subject, $result)
    {
        if ($this->sapHelper->isIntegrationEnabled()) {
            return $this->urlBuilder->getUrl('sap/password/forgot');
        }
        return $result;
    }
}
