<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Plugin\Controller;

use Corevist\SAP\Helper\Data as SapHelper;

class FrontController
{
    /**
     * SAP helper
     *
     * @var \Corevist\SAP\Helper\Data
     */
    private $sapHelper;

    /**
     * @param \Corevist\SAP\Helper\Data $sapHelper
     */
    public function __construct(SapHelper $sapHelper)
    {
        $this->sapHelper = $sapHelper;
    }

    /**
     * Attempt to update cart items in session if necessary
     *
     * @param \Magento\Framework\App\FrontController $subject
     * @param \Magento\Framework\App\RequestInterface $request
     *
     * @return void
     *
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function beforeDispatch(
        \Magento\Framework\App\FrontController $subject,
        \Magento\Framework\App\RequestInterface $request
    ) {
        if ($this->sapHelper->isIntegrationEnabled() && $this->sapHelper->isCorevistUser()) {
            $cartItems = $request->getParam('b2b_cart_items');
            if ($cartItems !== null) {
                $this->sapHelper->getCorevistUser()->setCartItems($cartItems);
            }
        }
    }
}
