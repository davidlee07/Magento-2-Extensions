<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Plugin\Controller;

use Magento\Framework\App\Action\Context;
use Corevist\SAP\Helper\Data as SapHelper;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use \Magento\Framework\Controller\Result\JsonFactory as ResultJsonFactory;

/**
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class CheckoutCartAdd
{
    /**
     * @var Context
     */
    private $context;

    /**
     * SAP helper
     *
     * @var \Corevist\SAP\Helper\Data
     */
    private $sapHelper;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    private $messageManager;

    /**
     * @var \Magento\Framework\Data\Form\FormKey\Validator
     */
    private $formKeyValidator;

    /**
     * @var string
     */
    private $locale;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * @var \Corevist\SAP\Model\CartFactory
     */
    private $cartFactory;

    /**
     * @param \Magento\Framework\App\Action\Context $context ;
     * @param \Corevist\SAP\Helper\Data $sapHelper
     * @param \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator
     * @param \Magento\Framework\Locale\ResolverInterface $localeResolver
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param ProductRepositoryInterface $productRepository
     * @param \Corevist\SAP\Model\CartFactory $cartFactory
     * @param ResultJsonFactory $jsonFactory
     */
    public function __construct(
        Context $context,
        SapHelper $sapHelper,
        \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator,
        \Magento\Framework\Locale\ResolverInterface $localeResolver,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        ProductRepositoryInterface $productRepository,
        \Corevist\SAP\Model\CartFactory $cartFactory,
        ResultJsonFactory $jsonFactory
    ) {
        $this->context = $context;
        $this->sapHelper = $sapHelper;
        $this->resultJsonFactory = $jsonFactory;
        $this->messageManager = $context->getMessageManager();
        $this->formKeyValidator = $formKeyValidator;
        $this->locale = $localeResolver->getLocale();
        $this->storeManager = $storeManager;
        $this->productRepository = $productRepository;
        $this->cartFactory = $cartFactory;
    }

    /**
     * Attempt to add product to corevist cart
     *
     * @param \Magento\Checkout\Controller\Cart\Add $subject
     * @param \Closure $proceed
     *
     * @return string
     */
    public function aroundExecute(\Magento\Checkout\Controller\Cart\Add $subject, \Closure $proceed)
    {
        if (!$this->sapHelper->isIntegrationEnabled()) {
            return $proceed();
        }

        if (!$this->sapHelper->isCorevistUser()) {
            $this->messageManager->addErrorMessage(__("You must be logged in in order to add this item to the cart."));
            return $this->goBack($this->context->getUrl('customer/account/login'));
        }

        if (!($product = $this->initProduct()) || !$this->formKeyValidator->validate($subject->getRequest())) {
            return $this->goBack();
        }

        try {
            $qty = $this->getQty($subject->getRequest()->getParams());

            $material = [
                'material' => $product->getSku(),
                'description' => $product->getName(),
                'unit' => $this->getUom($product),
                'characteristics' => '',
                'quantity' => $qty,
                'data' => (string)$this->getExtraCartParams($product)
            ];

            $cart = $this->cartFactory->create();
            /** @var $cart \Corevist\SAP\Model\Cart */
            $response = $cart->addMaterialsToCart([$material]);
            /** @var $response \Corevist\SAP\Model\Webservice\Response */

            if ($response->getReturnCode() !== SapHelper::RESPONSE_CODE_SUCCESS) {
                $this->processFailure($response);
                return $this->goBack();
            }
            $this->context->getEventManager()->dispatch(
                'sap_cart_add_product_complete',
                ['product' => $product]
            );

            $user = $this->sapHelper->getCorevistUser();
            $user->setCartItems((int)$response->getReturnValue()); // return value = cart items

            $message = __(
                'You added %1 to the cart.',
                $product->getName()
            );
            $this->messageManager->addSuccessMessage($message);
            // implement related products here
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $messages = array_unique(explode("\n", $e->getMessage()));
            foreach ($messages as $message) {
                $this->messageManager->addErrorMessage(__($message));
            }
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__("We can't add this item to the cart right now."));
        }
        return $this->goBack();
    }

    /**
     * @param \Corevist\SAP\Model\Webservice\Response $response
     *
     * @return void
     */
    private function processFailure(\Corevist\SAP\Model\Webservice\Response $response)
    {
        $message = $this->sapHelper->getSAPError(
            $response,
            __("We can't add this item to the cart right now.")
        );
        $this->messageManager->addErrorMessage($message);
    }

    /**
     * Initialize product instance from request data
     *
     * @return \Magento\Catalog\Model\Product|false
     */
    private function initProduct()
    {
        $productId = (int)$this->context->getRequest()->getParam('product');
        if ($productId) {
            $storeId = $this->storeManager->getStore()->getId();
            try {
                return $this->productRepository->getById($productId, false, $storeId);
            } catch (NoSuchEntityException $e) {
                return false;
            }
        }
        return false;
    }

    /**
     * Resolve response
     *
     * @param string $backUrl
     *
     * @return $this|\Magento\Framework\Controller\Result\Redirect
     */
    private function goBack($backUrl = null)
    {
        $result = [];
        if ($backUrl) {
            $result['backUrl'] = $backUrl;
        }

        $resultJson = $this->resultJsonFactory->create();
        $resultJson->setData($result);
        return $resultJson;
    }

    /**
     * Format data param
     *
     * @param \Magento\Catalog\Model\Product $product
     *
     * @return string
     */
    private function getExtraCartParams(\Magento\Catalog\Model\Product $product)
    {
        $data = $this->sapHelper->getExtraAddToCartParams();
        if (!$this->sapHelper->isCorevistPricing()) {
            if (!empty($data)) {
                $data .= ';';
            }
            $data .= 'PRICE=' . $product->getPrice();
        }
        return $data;
    }

    /**
     * @param array $params
     *
     * @return int
     */
    private function getQty(array $params)
    {
        $qty = 1;
        if (isset($params['qty'])) {
            $filter = new \Zend_Filter_LocalizedToNormalized(
                ['locale' => $this->locale]
            );
            $qty = (int)$filter->filter($params['qty']);
        }
        return $qty;
    }

    /**
     * @param \Magento\Catalog\Model\Product $product
     *
     * @return string
     */
    private function getUom(\Magento\Catalog\Model\Product $product)
    {
        return $product->getUom() ? $product->getUom() : 'EA';
    }
}
