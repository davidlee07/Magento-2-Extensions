<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Plugin\Controller;

use Magento\Framework\App\Action\Context;
use Corevist\SAP\Helper\Data as SapHelper;
use Magento\Customer\Model\Session as CustomerSession;
use \Magento\Store\Model\StoreManagerInterface;

class CustomerAccountLoginPost
{
    /**
     * SAP helper
     *
     * @var \Corevist\SAP\Helper\Data
     */
    private $sapHelper;

    /**
     * @var \Magento\Framework\Controller\Result\RedirectFactory
     */
    private $resultRedirectFactory;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    private $messageManager;

    /**
     * @var \Corevist\SAP\Model\UserFactory
     */
    private $corevistUserFactory;

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    private $customerFactory;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @param \Magento\Framework\App\Action\Context $context ;
     * @param \Corevist\SAP\Helper\Data $sapHelper
     * @param \Corevist\SAP\Model\UserFactory $userFactory
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        Context $context,
        SapHelper $sapHelper,
        \Corevist\SAP\Model\UserFactory $userFactory,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        StoreManagerInterface $storeManager
    ) {
        $this->sapHelper = $sapHelper;
        $this->resultRedirectFactory = $context->getResultRedirectFactory();
        $this->messageManager = $context->getMessageManager();
        $this->corevistUserFactory = $userFactory;
        $this->customerFactory = $customerFactory;
        $this->storeManager = $storeManager;
    }

    /**
     * Attempt to login customer into Corevist App
     *
     * @param \Magento\Customer\Controller\Account\LoginPost $subject
     * @param \Closure $proceed
     *
     * @return string
     */
    public function aroundExecute(\Magento\Customer\Controller\Account\LoginPost $subject, \Closure $proceed)
    {
        if (!$this->sapHelper->isIntegrationEnabled()) {
            return $proceed();
        }

        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($this->sapHelper->isCorevistUser()) {
            return $resultRedirect->setPath('/');
        }

        if ($subject->getRequest()->isPost()) {
            $login = $subject->getRequest()->getPost('login');
            if (!empty($login['username']) && !empty($login['password'])) {
                $username = $login['username'];
                $password = $login['password'];
                // sap login process
                $customerSession = $this->sapHelper->getSession();
                try {
                    /** @var \Corevist\SAP\Model\User $corevistUser */
                    $corevistUser = $this->corevistUserFactory->create();
                    if (!$corevistUser->authenticate($username, $password)) {
                        $this->processLoginFailure($corevistUser, $username);
                        return $resultRedirect->setPath('*/*/login');
                    }

                    if ($message = $this->sapHelper->trimResultMessage($corevistUser->getMessage())) {
                        $this->messageManager->addSuccessMessage($message);
                    }

                    $customer = $this->getCustomer($corevistUser);
                    $customerSession->setCorevistUser($corevistUser);
                    $customerSession->setCustomerAsLoggedIn($customer);

                    $redirectPath = $this->getRedirectPath($corevistUser->getReturnValue());
                    return $resultRedirect->setPath($redirectPath);
                } catch (\Exception $e) {
                    $customerSession->setUsername($login['username']);
                    $this->messageManager->addErrorMessage(__('Invalid login or password.'));
                    return $resultRedirect->setPath("*/*/login");
                }
            }
        }
        $this->messageManager->addErrorMessage(__('A login and a password are required.'));
        return $resultRedirect->setPath("*/*/login");
    }

    /**
     * @param \Corevist\SAP\Model\User $corevistUser
     * @param string $username
     *
     * @return void
     */
    private function processLoginFailure(\Corevist\SAP\Model\User $corevistUser, $username)
    {
        $this->sapHelper->getSession()->setUsername($username);
        $message = $this->sapHelper->getSAPError(
            $corevistUser,
            __("Invalid login or password.")
        );
        $this->messageManager->addErrorMessage($message);
    }

    /**
     * Get final redirect path after successful login action
     *
     * @param string $returnValue
     *
     * @return string
     */
    private function getRedirectPath($returnValue)
    {
        $path = '/';
        if (strpos($returnValue, "next_steps") !== false) {
            if (strpos($returnValue, "PQ") !== false) {
                $path = 'sap/password/setup';
            } elseif (strpos($returnValue, "P") !== false) {
                $path = 'sap/password/change';
            }
        }
        if (!$path && $this->sapHelper->isHomeRedirectOnLogin()) {
            $path = 'sap/redirect/home';
        }
        return $path;
    }

    /**
     * Sets the properties from the Corevist user that can be set on the customer
     *
     * @param \Corevist\SAP\Model\User $corevistUser
     *
     * @return \Magento\Customer\Model\Customer
     */
    private function getCustomer(\Corevist\SAP\Model\User $corevistUser)
    {
        $email = $corevistUser->getEmailAddress();
        if ($this->sapHelper->isCustomersWithNonUniqueEmailsAllowed()) {
            $email = $corevistUser->getUsername() . '-' . $email;
        }

        $customer = $this->customerFactory->create();
        $customer->setWebsiteId($this->storeManager->getStore()->getWebsiteId());
        /** @var $customer \Magento\Customer\Model\Customer */
        try {
            $customer->loadByEmail($email);
            // do nothing - will update existing customer
        } catch (\Exception $e) {
            // do nothing - will create new customer
        }

        // update customer's params
        $customer->setEmail($email);
        $customer->setGroupId(1);
        $customer->setFirstname($corevistUser->getFirstName());
        $customer->setLastname($corevistUser->getLastName());
        try {
            $customer->save();
        } catch (\Exception $e) {
            $this->sapHelper->getSession()->setUsername($corevistUser->getUsername());
            $this->messageManager->addErrorMessage(
                __('Cannot load the account data. Please contact our support team.')
            );
        }

        return $customer;
    }
}
