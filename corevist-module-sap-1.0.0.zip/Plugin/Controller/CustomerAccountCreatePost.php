<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Plugin\Controller;

use Magento\Framework\App\Action\Context;
use Corevist\SAP\Helper\Data as SapHelper;
use \Magento\Framework\Mail\Template\TransportBuilder;

class CustomerAccountCreatePost
{
    const EMAIL_TEMPLATE = 'corevist_sap_account_request_template';

    /**
     * SAP helper
     *
     * @var \Corevist\SAP\Helper\Data
     */
    private $sapHelper;

    /**
     * @var \Magento\Framework\Controller\Result\RedirectFactory
     */
    private $resultRedirectFactory;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    private $messageManager;

    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    private $emailTransportBuilder;

    /**
     * @var \Magento\Directory\Model\CountryFactory
     */
    private $countryFactory;

    /**
     * @var \Magento\Directory\Model\RegionFactory
     */
    private $regionFactory;

    /**
     * @param \Magento\Framework\App\Action\Context $context ;
     * @param \Corevist\SAP\Helper\Data $sapHelper
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param \Magento\Directory\Model\CountryFactory $countryFactory
     * @param \Magento\Directory\Model\RegionFactory $regionFactory
     */
    public function __construct(
        Context $context,
        SapHelper $sapHelper,
        TransportBuilder $transportBuilder,
        \Magento\Directory\Model\CountryFactory $countryFactory,
        \Magento\Directory\Model\RegionFactory $regionFactory
    ) {
        $this->sapHelper = $sapHelper;
        $this->resultRedirectFactory = $context->getResultRedirectFactory();
        $this->messageManager = $context->getMessageManager();
        $this->emailTransportBuilder = $transportBuilder;
        $this->countryFactory = $countryFactory;
        $this->regionFactory = $regionFactory;
    }

    /**
     * Attempt to send registration form
     *
     * @param \Magento\Customer\Controller\Account\CreatePost $subject
     * @param \Closure $proceed
     *
     * @return string
     */
    public function aroundExecute(\Magento\Customer\Controller\Account\CreatePost $subject, \Closure $proceed)
    {
        if (!$this->sapHelper->isIntegrationEnabled()) {
            return $proceed();
        }

        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($this->sapHelper->isCorevistUser()) {
            return $resultRedirect->setPath('/');
        }

        /** @var $request \Magento\Framework\App\RequestInterface */
        $request = $subject->getRequest();
        if ($request->isPost()) {
            try {
                $country = $this->countryFactory->create()->loadByCode($request->getParam('country_id'));
                if ($regionId = $request->getParam('region_id')) {
                    $region = $this->regionFactory->create()->load($regionId)->getName();
                }
                if (!$region) {
                    $region = $request->getParam('region');
                }

                $transport = $this->emailTransportBuilder->setTemplateIdentifier(
                    self::EMAIL_TEMPLATE
                )->setTemplateOptions(
                    [
                        'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                        'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                    ]
                )->setTemplateVars(
                    [
                        'firstname' => $request->getParam('firstname'),
                        'lastname' => $request->getParam('lastname'),
                        'email' => $request->getParam('email'),
                        'company' => $request->getParam('company'),
                        'telephone' => $request->getParam('telephone'),
                        'address' => trim(join(' ', $request->getParam('street'))),
                        'city' => $request->getParam('city'),
                        'region' => $region,
                        'postcode' => $request->getParam('postcode'),
                        'country' => $country->getName()
                    ]
                )->addTo(
                    $this->sapHelper->getRegistrationEmail()
                )->setFrom(
                    'general'
                )->getTransport();

                $transport->sendMessage();

                return $resultRedirect->setPath('*/*/requestSent');
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage(__('We are sorry but some error occurred! Please retry.'));
                $this->messageManager->addErrorMessage(
                    __('Please contact our tech support team if this error will appear again.')
                );
                return $resultRedirect->setPath("*/*/create");
            }
        } else {
            $this->messageManager->addErrorMessage(__('Invalid data sent! Please retry.'));
            return $resultRedirect->setPath("*/*/create");
        }
    }
}
