<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Plugin\Block;

use Corevist\SAP\Helper\Data as SapHelper;

class CatalogProductList
{
    /**
     * SAP helper
     *
     * @var \Corevist\SAP\Helper\Data
     */
    private $sapHelper;

    /**
     * @param \Corevist\SAP\Helper\Data $sapHelper
     */
    public function __construct(SapHelper $sapHelper)
    {
        $this->sapHelper = $sapHelper;
    }

    /**
     * Change product list price with placeholder
     *
     * @param \Magento\Catalog\Block\Product\ListProduct $subject
     * @param \Closure $proceed
     * @param \Magento\Catalog\Model\Product $product
     *
     * @return string
     *
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function aroundGetProductPrice(
        \Magento\Catalog\Block\Product\ListProduct $subject,
        \Closure $proceed,
        \Magento\Catalog\Model\Product $product
    ) {
        // display usual magento prices if corevist pricing is not enabled
        if (!$this->sapHelper->isIntegrationEnabled()
            || !$this->sapHelper->isCorevistPricing()
        ) {
            return $proceed($product);
        }
        return $this->wrapResult('price is loading...', $product);
    }

    /**
     * Wrap with standard required container
     *
     * @param string $html
     * @param \Magento\Catalog\Model\Product $product
     *
     * @return string
     */
    private function wrapResult($html, \Magento\Catalog\Model\Product $product)
    {
        return '<div class="price-box price-loading" ' .
        'data-role="priceBox" ' .
        'data-product-id="' . $product->getId() . '"' .
        'data-product-sku="' . $product->getSku() . '"' .
        '>' . $html . '</div>';
    }
}
