<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Block\Price\Render;

use \Magento\Catalog\Pricing\Render;
use \Magento\Framework\View\Element\Template\Context;
use Magento\Framework\Registry;
use Corevist\SAP\Helper\Data as SapHelper;

class Loading extends Render
{
    /**
     * @var SapHelper
     */
    private $sapHelper;

    /**
     * Construct
     *
     * @param Context $context
     * @param Registry $registry
     * @param SapHelper $sapHelper
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        SapHelper $sapHelper,
        array $data = []
    ) {
        $this->sapHelper = $sapHelper;
        parent::__construct($context, $registry, $data);
    }

    /**
     * @return string
     */
    protected function _toHtml()
    {
        if (!$this->sapHelper->isIntegrationEnabled() || !$this->sapHelper->isCorevistPricing()) {
            return parent::_toHtml();
        }
        return '<div class="price-box price-loading" '
        . 'data-role="priceBox" data-product-id="'
        . $this->getProduct()->getId()
        . '" data-product-sku="'
        . $this->getProduct()->getSku()
        . '"><span class="price">'
        . __('Price is loading...')
        . '</span></div>';
    }
}
