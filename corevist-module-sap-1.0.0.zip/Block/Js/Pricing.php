<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Block\Js;

use \Magento\Framework\View\Element\Template;
use \Corevist\SAP\Helper\Data as SapHelper;

class Pricing extends Template
{
    /**
     * @var SapHelper
     */
    private $sapHelper;

    /**
     * @param Template\Context $context
     * @param SapHelper $sapHelper
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        SapHelper $sapHelper,
        array $data = []
    ) {
        $this->sapHelper = $sapHelper;
        parent::__construct($context, $data);
    }

    /**
     * @return string
     */
    public function getPricingUrl()
    {
        return $this->sapHelper->getUrlModel()->getPricesUrl();
    }

    /**
     * @return bool
     */
    public function isCorevistPricing()
    {
        return $this->sapHelper->isIntegrationEnabled() && $this->sapHelper->isCorevistPricing();
    }
}
