<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Observer\Frontend;

use \Corevist\SAP\Helper\Data as SapHelper;
use \Magento\Framework\Event\Observer as EventObserver;
use \Magento\Framework\Event\ObserverInterface;
use \Magento\Framework\App\ActionFlag;
use \Magento\Framework\App\Response\RedirectInterface;
use \Magento\Customer\Model\Session as CustomerSession;

class OnPredispatchObserver implements ObserverInterface
{
    /**
     * SAP helper
     *
     * @var \Corevist\SAP\Helper\Data
     */
    private $sapHelper;

    /**
     * Action flag
     *
     * @var \Magento\Framework\App\ActionFlag
     */
    private $actionFlag;

    /**
     * Redirect
     *
     * @var \Magento\Framework\App\Response\RedirectInterface
     */
    private $redirect;

    /**
     * Customer session
     *
     * @var \Magento\Customer\Model\Session
     */
    private $customerSession;

    /**
     * Current controller
     *
     * @var \Magento\Framework\App\Action\Action
     */
    private $controller;

    /**
     * Current request path
     *
     * @var string
     */
    private $path;

    /**
     * @var string
     */
    private $redirectPath;

    /**
     * @param \Corevist\SAP\Helper\Data $sapHelper
     * @param \Magento\Framework\App\ActionFlag $actionFlag
     * @param \Magento\Framework\App\Response\RedirectInterface $stopProcessing
     * @param \Magento\Customer\Model\Session $customerSession
     */
    public function __construct(
        SapHelper $sapHelper,
        ActionFlag $actionFlag,
        RedirectInterface $stopProcessing,
        CustomerSession $customerSession
    ) {
        $this->sapHelper = $sapHelper;
        $this->actionFlag = $actionFlag;
        $this->redirect = $stopProcessing;
        $this->customerSession = $customerSession;
    }

    /**
     * Force user to login if necessary
     *
     * @param \Magento\Framework\Event\Observer $observer
     *
     * @return void
     */
    public function execute(EventObserver $observer)
    {
        if ($this->sapHelper->isIntegrationEnabled()) {
            $this->controller = $observer->getEvent()->getControllerAction();
            $this->path = $this->controller->getRequest()->getFullActionName('/');

            $checks = [
                '_checkForcedLogin',
                '_checkLoginStep',
                '_checkSapRedirects'
            ];

            foreach ($checks as $check) {
                if ($this->$check()) {
                    break;
                }
            }

            if ($this->redirectPath) {
                $this->actionFlag->set('', \Magento\Framework\App\Action\Action::FLAG_NO_DISPATCH, true);
                $this->actionFlag->set('', \Magento\Framework\App\Action\Action::FLAG_NO_POST_DISPATCH, true);
                $this->redirect->redirect($this->controller->getResponse(), $this->redirectPath);
            }
        }
    }

    /**
     * @return bool
     */
    private function _checkForcedLogin()
    {
        $stopProcessing = false;
        $whiteListedRouters = ['api', 'sap'];
        $whiteListedPaths = [
            'customer/account/login',
            'customer/account/loginPost',
            'customer/account/logout',
            'customer/account/logoutSuccess',
            'customer/section/load',
            'page_cache/block/render'
        ];

        if ($this->sapHelper->isRegistrationEnabled()) {
            $whiteListedPaths[] = 'customer/account/create';
            $whiteListedPaths[] = 'customer/account/createpost';
            $whiteListedPaths[] = 'customer/account/requestSent';
        }

        if ($this->sapHelper->isForcedLogin() && !$this->sapHelper->isCorevistUser()) {
            $stopProcessing = true;
            $router = $this->controller->getRequest()->getRouteName();
            if (!in_array($router, $whiteListedRouters) && !in_array($this->path, $whiteListedPaths)) {
                $this->redirectPath = 'customer/account/login';
            }
        }
        return $stopProcessing;
    }

    /**
     * @return bool
     */
    private function _checkLoginStep()
    {
        $stopProcessing = false;

        if ($corevistUser = $this->sapHelper->getCorevistUser()) {

            $returnValue = $corevistUser->getReturnValue();
            switch ($returnValue) {
                case 'next_steps=PQ':
                    $stopProcessing = true;
                    $whiteList = [
                        'customer/account/logout',
                        'sap/password/setup',
                        'sap/password/setuppost'
                    ];
                    if (!in_array($this->path, $whiteList)) {
                        $this->redirectPath = 'sap/password/setup';
                    }
                    break;

                case 'next_steps=P':
                    $stopProcessing = true;
                    $whiteList = [
                        'customer/account/logout',
                        'sap/password/change',
                        'sap/password/changepost'
                    ];
                    if (!in_array($this->path, $whiteList)) {
                        $this->redirectPath = 'sap/password/change';
                    }
                    break;
                // implement redirect to referer here
            }
        }
        return $stopProcessing;
    }

    /**
     * @return string
     */
    private function _checkSapRedirects()
    {
        $stopProcessing = false;
        $whiteList = [
            'checkout/cart/add',
            'customer/account/login',
            'customer/account/loginPost',
            'customer/account/logout',
            'customer/account/logoutSuccess',
            'customer/section/load'
        ];

        if (!in_array($this->path, $whiteList)) {
            $map = [
                'checkout' => 'sap/redirect/cart',
                'customer' => 'sap/redirect/account',
                'newsletter' => '404',
                'sales' => '404',
                'paypal' => '404',
                'review' => '404',
                'vault' => '404',
            ];
            $router = $this->controller->getRequest()->getRouteName();
            if (isset($map[$router])) {
                $this->redirectPath = $map[$router];
                $stopProcessing = true;
            }
        }
        return $stopProcessing;
    }
}
