<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Observer\Frontend;

use Corevist\SAP\Helper\Data as SapHelper;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

class ForceUserLoginLayoutObserver implements ObserverInterface
{
    /**
     * @var array
     */
    private $affectedActions = [
        'customer_account_login',
        'customer_account_create',
        'customer_account_logoutSuccess',
        'customer_account_requestSent',
        'sap_password_forgot',
        'sap_password_question',
        'sap_password_sent',
        'sap_password_setup',
        'sap_password_change'
    ];

    /**
     * @var array
     */
    private $blocksToUnset = [
        'catalog.topnav',
        'top.search',
        'minicart',
        'footer-container',
        'header.panel'
    ];

    /**
     * SAP helper
     *
     * @var \Corevist\SAP\Helper\Data
     */
    private $sapHelper;

    /**
     * @param \Corevist\SAP\Helper\Data $sapHelper
     */
    public function __construct(SapHelper $sapHelper)
    {
        $this->sapHelper = $sapHelper;
    }

    /**
     * Hide unnecessary layout blocks from unauthorized users
     *
     * @param \Magento\Framework\Event\Observer $observer
     *
     * @return void
     */
    public function execute(EventObserver $observer)
    {
        if ($this->sapHelper->isIntegrationEnabled()
            && $this->sapHelper->isForcedLogin()
            && $this->checkAction($observer->getEvent())
        ) {
            /** @var \Magento\Framework\View\Layout $layout */
            $layout = $observer->getLayout();
            foreach ($this->blocksToUnset as $blockName) {
                $layout->unsetElement($blockName);
            }
        }
    }

    /**
     * Check if current action is in list of affected actions
     *
     * @param \Magento\Framework\Event $event
     *
     * @return bool
     */
    private function checkAction(\Magento\Framework\Event $event)
    {
        $action = $event->getFullActionName();
        return in_array($action, $this->affectedActions);
    }
}
