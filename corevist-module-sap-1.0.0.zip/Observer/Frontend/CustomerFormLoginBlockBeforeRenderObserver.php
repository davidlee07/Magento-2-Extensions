<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Observer\Frontend;

use Corevist\SAP\Helper\Data as SapHelper;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

class CustomerFormLoginBlockBeforeRenderObserver implements ObserverInterface
{
    /**
     * SAP helper
     *
     * @var \Corevist\SAP\Helper\Data
     */
    private $sapHelper;

    /**
     * @var \Magento\Customer\Model\Url
     */
    private $customerUrl;

    /**
     * @param \Corevist\SAP\Helper\Data $sapHelper
     * @param \Magento\Customer\Model\Url $customerUrl
     */
    public function __construct(
        SapHelper $sapHelper,
        \Magento\Customer\Model\Url $customerUrl
    ) {
        $this->sapHelper = $sapHelper;
        $this->customerUrl = $customerUrl;
    }

    /**
     * Hide unnecessary layout blocks from unauthorized users
     *
     * @param \Magento\Framework\Event\Observer $observer
     *
     * @return void
     */
    public function execute(EventObserver $observer)
    {
        if ($this->sapHelper->isIntegrationEnabled()) {
            $block = $observer->getBlock();
            if ($block instanceof \Magento\Customer\Block\Form\Login) {
                $block->setRegisterUrl($this->customerUrl->getRegisterUrl());
                $block->setRegistrationEnabled($this->sapHelper->isRegistrationEnabled());
            }
        }
    }
}
