<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Observer\Frontend;

use Corevist\SAP\Helper\Data as SapHelper;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\ActionFlag;
use Magento\Framework\App\Response\RedirectInterface;

class LoggedRedirectObserver implements ObserverInterface
{
    /**
     * SAP helper
     *
     * @var \Corevist\SAP\Helper\Data
     */
    private $sapHelper;

    /**
     * Action flag
     *
     * @var \Magento\Framework\App\ActionFlag
     */
    private $actionFlag;

    /**
     * Redirect
     *
     * @var \Magento\Framework\App\Response\RedirectInterface
     */
    private $redirect;

    /**
     * @param \Corevist\SAP\Helper\Data $sapHelper
     * @param \Magento\Framework\App\ActionFlag $actionFlag
     * @param \Magento\Framework\App\Response\RedirectInterface $redirect
     */
    public function __construct(SapHelper $sapHelper, ActionFlag $actionFlag, RedirectInterface $redirect)
    {
        $this->sapHelper = $sapHelper;
        $this->actionFlag = $actionFlag;
        $this->redirect = $redirect;
    }

    /**
     * Redirect user to homepage if he is already logged in
     *
     * @param \Magento\Framework\Event\Observer $observer
     *
     * @return void
     */
    public function execute(EventObserver $observer)
    {
        if ($this->sapHelper->isCorevistUser()) {
            /** @var \Magento\Framework\App\Action\Action $controller */
            $controller = $observer->getEvent()->getControllerAction();
            $this->actionFlag->set('', \Magento\Framework\App\Action\Action::FLAG_NO_DISPATCH, true);
            $this->actionFlag->set('', \Magento\Framework\App\Action\Action::FLAG_NO_POST_DISPATCH, true);
            $this->redirect->redirect($controller->getResponse(), '/');
        }
    }
}
