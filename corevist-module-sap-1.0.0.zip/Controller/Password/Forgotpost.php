<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Controller\Password;

use \Magento\Framework\App\Action\Context;
use \Corevist\SAP\Helper\Data as SapHelper;

class Forgotpost extends \Corevist\SAP\Controller\Action
{
    /**
     * @var \Corevist\SAP\Model\UserFactory
     */
    private $userFactory;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param SapHelper $sapHelper
     * @param \Corevist\SAP\Model\UserFactory $userFactory
     */
    public function __construct(
        Context $context,
        SapHelper $sapHelper,
        \Corevist\SAP\Model\UserFactory $userFactory
    ) {
        $this->userFactory = $userFactory;
        parent::__construct($context, $sapHelper);
    }

    /**
     * Dispatch
     * 
     * @return \Magento\Framework\App\ResponseInterface
     */
    public function execute()
    {
        if ($this->sapHelper->isCorevistUser()) {
            return $this->_redirect('/');
        }

        $username = (string)$this->getRequest()->getPost('username');
        if ($username) {
            try {
                $user = $this->userFactory->create();

                $response = $user->getUserResetPasswordQuestion($username);
                if ($response->getReturnCode() !== 0) {
                    if ($message = $this->sapHelper->trimResultMessage($response->getMessage())) {
                        $this->messageManager->addErrorMessage(__($message));
                    } else {
                        $this->messageManager->addErrorMessage(__('Unknown webservice error'));
                    }
                    return $this->_redirect('*/*/forgot');
                }

                $this->sapHelper->getSession()->setTmpCorevistUser(
                    [
                        'username' => $username,
                        'token' => $response->getToken(),
                        'reset_question' => $response->getResetQuestion()
                    ]
                );

                return $this->_redirect('*/*/question');
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage(__('We are sorry but some error occurred! Please retry.'));
                $this->messageManager->addErrorMessage(
                    __('Please contact our tech support team if this error will appear again.')
                );
                return $this->_redirect("*/*/forgot");
            }
        } else {
            $this->messageManager->addErrorMessage(__('Please enter your username.'));
            return $this->_redirect('*/*/forgot');
        }
    }
}
