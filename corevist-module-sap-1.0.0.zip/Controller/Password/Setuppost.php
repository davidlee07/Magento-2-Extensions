<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Controller\Password;

class Setuppost extends \Corevist\SAP\Controller\Action
{
    /**
     * Dispatch
     *
     * @return \Magento\Framework\App\ResponseInterface
     */
    public function execute()
    {
        if (!$this->sapHelper->isCorevistUser()) {
            return $this->_redirect('customer/account/login');
        }

        $password = $this->_request->getParam('password');
        $confirm = $this->_request->getParam('password_confirmation');
        $question = $this->_request->getParam('security_question', '');
        $answer = $this->_request->getParam('security_answer');

        if (!$this->validateData($password, $confirm, $question, $answer)) {
            $this->_redirect('sap/password/setup');
        }

        try {
            $corevistUser = $this->sapHelper->getCorevistUser();
            $response = $corevistUser->changePasswordAndResetQuestion($password, $confirm, $question, $answer);

            if ($response->getReturnCode() !== 0) {
                if ($message = $response->getMessage()) {
                    $this->messageManager->addErrorMessage(__($message));
                } else {
                    $this->messageManager->addErrorMessage(
                        __('There was an error processing your request. Please try again later.')
                    );
                }
                return $this->_redirect('sap/password/setup');
            }

            if ($message = $response->getMessage()) {
                $this->messageManager->addSuccessMessage(__($message));
            }

            $corevistUser->unsReturnValue();

            if ($this->sapHelper->isHomeRedirectOnLogin()) {
                return $this->_redirect('sap/redirect/home');
            }
            $this->_redirect('/');
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__($e));
            $this->_redirect('sap/password/setup');
        }
    }

    /**
     * @param string $password
     * @param string $confirm
     * @param string $question
     * @param string $answer
     *
     * @return bool
     */
    private function validateData($password, $confirm, $question, $answer)
    {
        $validSubmission = true;
        if (empty($password)) {
            $this->messageManager->addErrorMessage(__("You must provide a password."));
            $validSubmission = false;
        } elseif ($password != $confirm) {
            $this->messageManager->addErrorMessage(__("Passwords do not match."));
            $validSubmission = false;
        }

        if ($question == '') {
            $this->messageManager->addErrorMessage(__("You must select a security question."));
            $validSubmission = false;
        }

        if (empty($answer)) {
            $this->messageManager->addErrorMessage(__("You must provide a security answer."));
            $validSubmission = false;
        }
        return $validSubmission;
    }
}
