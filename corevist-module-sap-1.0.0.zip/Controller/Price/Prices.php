<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Controller\Price;

use \Magento\Framework\App\Action\Context;
use \Corevist\SAP\Helper\Data as SapHelper;
use \Magento\Framework\Controller\Result\JsonFactory;
use \Corevist\SAP\Model\Material as MaterialModel;
use \Magento\Framework\Pricing\PriceCurrencyInterface;
use \Magento\Framework\View\LayoutInterface;
use \Magento\Catalog\Model\ProductRepository;
use \Magento\Framework\Exception\LocalizedException;

class Prices extends \Corevist\SAP\Controller\Action
{
    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var \Corevist\SAP\Model\Material
     */
    private $materialModel;

    /**
     * @var PriceCurrencyInterface
     */
    private $priceCurrency;

    /**
     * @var LayoutInterface
     */
    private $layout;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * Prices controller constructor.
     *
     * @param Context $context
     * @param SapHelper $sapHelper
     * @param JsonFactory $resultJsonFactory
     * @param MaterialModel $material
     * @param PriceCurrencyInterface $priceCurrency
     * @param LayoutInterface $layout
     * @param ProductRepository $productRepository
     */
    public function __construct(
        Context $context,
        SapHelper $sapHelper,
        JsonFactory $resultJsonFactory,
        MaterialModel $material,
        PriceCurrencyInterface $priceCurrency,
        LayoutInterface $layout,
        ProductRepository $productRepository
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->materialModel = $material;
        $this->priceCurrency = $priceCurrency;
        $this->layout = $layout;
        $this->productRepository = $productRepository;
        parent::__construct($context, $sapHelper);
    }

    public function execute()
    {
        $request = $this->getRequest();
        if ($request->isPost() && $skus = $request->getParam('skus')) {
            $skus = explode(',', $skus);
            try {
                if ($this->sapHelper->isCorevistUser()) {
                    $prices = $this->getPricesFromSAP($skus);
                } elseif ($this->sapHelper->isHidePricesWoLogin()) {
                    $prices = $this->getPricesPlaceholders($skus);
                } else {
                    $prices = $this->getPricesFromMagento($skus);
                }
                $response = ['status' => true, 'prices' => $prices];
            } catch (\Exception $e) {
                $response = ['status' => false];
            }
        } else {
            $response = ['status' => false];
        }
        $resultJson = $this->resultJsonFactory->create();
        $resultJson->setData($response);
        return $resultJson;
    }

    /**
     * @param array $skus
     *
     * @return array
     */
    private function getPricesFromSap(array $skus)
    {
        $prices = [];
        $info = $this->materialModel->getMaterialsInfo($skus);
        foreach ($info as $sku => $data) {
            if (!empty($data['price_infos']) && isset($data['price_infos'][0]['rate'])) {
                $price = $data['price_infos'][0]['rate'];
                $prices[$sku] =
                    '<span class="price-container"><span class="price-wrapper">' .
                    $this->priceCurrency->format(
                        $price,
                        true,
                        PriceCurrencyInterface::DEFAULT_PRECISION,
                        null,
                        $data['price_infos'][0]['rate_unit']
                    ) .
                    '</span></span>';
            } else {
                $prices[$sku] =
                    '<span class="price-container"><span class="price-wrapper">' .
                    '<span class="price">' . __('N/A') . '</span>' .
                    '</span></span>';
            }
        }
        return $prices;
    }

    /**
     * @param array $skus
     *
     * @return array
     *
     * @throws LocalizedException
     */
    private function getPricesFromMagento(array $skus)
    {
        $prices = [];

        $this->layout->getUpdate()
            ->addHandle('default')
            ->addHandle('catalog_category_view');
        $priceRender = $this->layout->getBlock('product.price.render.default');
        /** @var $priceRender \Magento\Framework\Pricing\Render */
        if ($priceRender) {
            foreach ($skus as $sku) {
                $product = $this->productRepository->get($sku);
                $prices[$sku] = $priceRender->render(
                    \Magento\Catalog\Pricing\Price\FinalPrice::PRICE_CODE,
                    $product,
                    [
                        'include_container' => true,
                        'display_minimal_price' => true,
                        'zone' => \Magento\Framework\Pricing\Render::ZONE_ITEM_LIST,
                        'list_category_page' => true
                    ]
                );
            }
        } else {
            throw new LocalizedException(__('Price renderer not defined'));
        }

        return $prices;
    }

    /**
     * @param array $skus
     *
     * @return array
     */
    private function getPricesPlaceholders(array $skus)
    {
        $prices = [];

        foreach ($skus as $sku) {
            $prices[$sku] = '<span class="price-box">' .
                '<span class="price">' . __('Please sign in to view prices') . '</span>' .
                '</span>';
        }

        return $prices;
    }
}
