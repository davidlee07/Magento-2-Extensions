<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Model;

use Corevist\SAP\Model\Webservice\ResponseInterface;

class User extends AbstractModel implements ResponseInterface
{
    /**
     * Initialize customer model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Corevist\SAP\Model\ResourceModel\User');
    }

    /**
     * Authenticate customer
     *
     * @param  string $username
     * @param  string $password
     *
     * @return bool
     */
    public function authenticate($username, $password)
    {
        $params = [
            'username' => $username,
            'password' => $password,
            'wsId' => $this->sapHelper->getWsId(),
            'defaultLanguage' => $this->sapHelper->getDefaultLanguage()
        ];

        $this->getResource()->remoteLogin($this, $params);

        if ($this->getReturnCode() !== 0) {
            return false;
        }

        $this->_eventManager->dispatch(
            'corevist_user_authenticated',
            ['model' => $this, 'password' => $password]
        );

        return true;
    }

    /**
     * @param string $newPassword
     * @param string $newPasswordConfirmation
     *
     * @return \Corevist\SAP\Model\Webservice\Response
     */
    public function changePassword($newPassword, $newPasswordConfirmation)
    {
        $params = [
            'wsId' => $this->sapHelper->getWsId(),
            'token' => $this->getToken(),
            'username' => $this->getUsername(),
            'password' => $newPassword,
            'confirmPassword' => $newPasswordConfirmation,
            'defaultLanguage' => $this->sapHelper->getDefaultLanguage()
        ];

        $response = $this->responseFactory->create();
        $this->getResource()->changeUserPassword($response, $params);

        return $response;
    }

    /**
     * @param string $newPassword
     * @param string $newPasswordConfirmation
     * @param string $questionId
     * @param string $questionAnswer
     *
     * @return \Corevist\SAP\Model\Webservice\Response
     */
    public function changePasswordAndResetQuestion($newPassword, $newPasswordConfirmation, $questionId, $questionAnswer)
    {
        $params = [
            'wsId' => $this->sapHelper->getWsId(),
            'token' => $this->getToken(),
            'username' => $this->getUsername(),
            'password' => $newPassword,
            'confirmPassword' => $newPasswordConfirmation,
            'questionId' => $questionId,
            'questionAnswer' => $questionAnswer,
            'defaultLanguage' => $this->sapHelper->getDefaultLanguage()
        ];

        $response = $this->responseFactory->create();
        $this->getResource()->changeUserPasswordAndResetQuestion($response, $params);

        return $response;
    }

    /**
     * @param string $username
     *
     * @return \Corevist\SAP\Model\Webservice\Response
     */
    public function getUserResetPasswordQuestion($username)
    {
        $params = [
            'wsId' => $this->sapHelper->getWsId(),
            'username' => $username,
            'defaultLanguage' => $this->sapHelper->getDefaultLanguage()
        ];
        $response = $this->responseFactory->create();
        $this->getResource()->getUserResetPasswordQuestion($response, $params);

        return $response;
    }

    /**
     * @param string $tmpToken
     * @param string $username
     * @param string $answer
     *
     * @return \Corevist\SAP\Model\Webservice\Response
     */
    public function resetPassword($tmpToken, $username, $answer)
    {
        $params = [
            'wsId' => $this->sapHelper->getWsId(),
            'token' => $tmpToken,
            'username' => $username,
            'answer' => $answer,
            'defaultLanguage' => $this->sapHelper->getDefaultLanguage()
        ];

        $response = $this->responseFactory->create();
        $this->getResource()->ResetUserPassword($response, $params);

        return $response;
    }

    /**
     * @return int
     */
    public function getReturnCode()
    {
        return (int)$this->getData('return_code');
    }

    /**
     * @return mixed
     */
    public function getReturnValue()
    {
        return $this->getData('return_value');
    }

    /**
     * @return string
     */
    public function getMessage()
    {
        return $this->getData('message');
    }
}
