<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Model;

use Corevist\SAP\Helper\Data as SapHelper;

abstract class AbstractModel extends \Magento\Framework\Model\AbstractModel
{
    /**
     * @var SapHelper
     */
    protected $sapHelper;

    /**
     * @var Webservice\ResponseFactory
     */
    protected $responseFactory;

    /**
     * AbstractModel constructor.
     *
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param SapHelper $sapHelper
     * @param \Corevist\SAP\Model\Webservice\ResponseFactory $responseFactory
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        SapHelper $sapHelper,
        \Corevist\SAP\Model\Webservice\ResponseFactory $responseFactory
    ) {
        $this->sapHelper = $sapHelper;
        $this->responseFactory = $responseFactory;
        parent::__construct($context, $registry);
    }
}
