<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Model\ResourceModel;

use Corevist\SAP\Model\Webservice\Response as WebserviceResponse;

class Material extends Webservice
{
    /**
     * $materials is a multidimensional array that must follow this format:
     * $materials = array(
     *  array(
     *      'material' => string
     *      'quantity' => integer
     *  )
     * );
     *
     * @param WebserviceResponse $response
     * @param array|string $wsId
     * @param string $token
     * @param array $materials
     * @param string $defaultLanguage
     *
     * @return WebserviceResponse
     */
    public function getMaterialsInfo(
        WebserviceResponse $response,
        $wsId,
        $token = '',
        array $materials = [],
        $defaultLanguage = ''
    ) {
        if (is_array($wsId)) {
            extract($wsId);
        }

        $arguments = [
            $wsId,
            $token,
            $materials,
            $defaultLanguage
        ];

        return $this->loadObject($response, __FUNCTION__, $arguments);
    }
}
