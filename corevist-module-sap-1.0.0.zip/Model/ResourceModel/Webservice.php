<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Model\ResourceModel;

use Corevist\SAP\Helper\Data as SapHelper;

class Webservice
{
    /**
     * @var \Zend_Soap_Client
     */
    private $client;

    /**
     * @var SapHelper
     */
    private $sapHelper;

    /**
     * Webservice constructor.
     *
     * @param SapHelper $sapHelper
     */
    public function __construct(SapHelper $sapHelper)
    {
        $this->sapHelper = $sapHelper;
        $this->client = $sapHelper->getSoapClient();
    }

    /**
     * @param \Magento\Framework\DataObject $object
     * @param string $serviceCall
     * @param array $arguments
     *
     * @return \Magento\Framework\DataObject
     */
    public function loadObject(\Magento\Framework\DataObject $object, $serviceCall, array $arguments)
    {
        $response = call_user_func_array([$this->client, $serviceCall], $arguments);
        return $object->setData($this->_objectToArray($response));
    }

    /**
     * Converts a stdClass to an associative array
     *
     * @param $data
     *
     * @return array
     */
    private function _objectToArray($data)
    {
        if (is_object($data)) {
            $data = get_object_vars($data);
        }

        if (is_array($data)) {
            return array_map([$this, __FUNCTION__], $data);
        }

        return $data;
    }

    /**
     * Fake method to force Magento Factory method working
     *
     * @return string
     */
    public function getIdFieldName()
    {
        return 'id';
    }
}
