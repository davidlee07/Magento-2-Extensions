<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Model\ResourceModel;

use Corevist\SAP\Model\User as UserModel;
use Corevist\SAP\Model\Webservice\Response as WebserviceResponse;
use Corevist\SAP\Model\Webservice\ResponseInterface;

class User extends Webservice
{
    /**
     * Login user into Corevist App
     *
     * @param UserModel $user
     * @param array|string $wsId
     * @param string $token
     * @param string $username
     * @param string $password
     * @param string $defaultLanguage
     *
     * @return UserModel
     */
    public function remoteLogin(
        UserModel $user,
        $wsId,
        $token = 'TBD',
        $username = '',
        $password = '',
        $defaultLanguage = ''
    ) {
        if (is_array($wsId)) {
            extract($wsId);
        }

        $arguments = [$wsId, $token, $username, $password, $defaultLanguage];
        return $this->loadObject($user, __FUNCTION__, $arguments)
            ->setUsername($username); // add the username to the response
    }

    /**
     * Changes the user's password
     *
     * @param WebserviceResponse $result
     * @param array|string $wsId
     * @param string $token
     * @param string $username
     * @param string $password
     * @param string $confirmPassword
     * @param string $defaultLanguage
     *
     * @return WebserviceResponse
     */
    public function changeUserPassword(
        WebserviceResponse $result,
        $wsId,
        $token = '',
        $username = '',
        $password = '',
        $confirmPassword = '',
        $defaultLanguage = ''
    ) {
        if (is_array($wsId)) {
            extract($wsId);
        }

        $arguments = [$wsId, $token, $username, $password, $confirmPassword, $defaultLanguage];
        return $this->loadObject($result, __FUNCTION__, $arguments);
    }

    /**
     * Changes a user's password and security question
     *
     * @param WebserviceResponse $result
     * @param array|string $wsId
     * @param string $token
     * @param string $username
     * @param string $password
     * @param string $confirmPassword
     * @param string|integer $questionId
     * @param string $questionAnswer
     * @param string $defaultLanguage
     *
     * @return WebserviceResponse
     */
    public function changeUserPasswordAndResetQuestion(
        WebserviceResponse $result,
        $wsId,
        $token = '',
        $username = '',
        $password = '',
        $confirmPassword = '',
        $questionId = '',
        $questionAnswer = '',
        $defaultLanguage = ''
    ) {
        if (is_array($wsId)) {
            extract($wsId);
        }

        $arguments = [
            $wsId,
            $token,
            $username,
            $password,
            $confirmPassword,
            $questionId,
            $questionAnswer,
            $defaultLanguage
        ];
        return $this->loadObject($result, __FUNCTION__, $arguments);
    }

    /**
     * Changes a user's password and security question
     *
     * @param WebserviceResponse $result
     * @param array|string $wsId
     * @param string $token
     * @param string $username
     * @param string $defaultLanguage
     *
     * @return WebserviceResponse
     */
    public function getUserResetPasswordQuestion(
        WebserviceResponse $result,
        $wsId,
        $token = 'TBD',
        $username = '',
        $defaultLanguage = ''
    ) {
        if (is_array($wsId)) {
            extract($wsId);
        }

        $arguments = [
            $wsId,
            $token,
            $username,
            $defaultLanguage
        ];
        return $this->loadObject($result, __FUNCTION__, $arguments);
    }

    /**
     * Changes a user's password and security question
     *
     * @param WebserviceResponse $result
     * @param array|string $wsId
     * @param string $token
     * @param string $username
     * @param string $answer
     * @param string $defaultLanguage
     *
     * @return WebserviceResponse
     */
    public function ResetUserPassword(
        WebserviceResponse $result,
        $wsId,
        $token = '',
        $username = '',
        $answer = '',
        $defaultLanguage = ''
    ) {
        if (is_array($wsId)) {
            extract($wsId);
        }

        $arguments = [
            $wsId,
            $token,
            $username,
            $answer,
            $defaultLanguage
        ];
        return $this->loadObject($result, __FUNCTION__, $arguments);
    }
}
