<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Model;

use \Magento\Customer\Model\Session;
use \Magento\Store\Model\StoreManagerInterface;

class Url
{
    // config constants
    const CONFIG_WS_URL_PATH = 'sap/ws/url';
    // sap urls
    const LOGIN_HOME_URL = '/login/home';
    const LOGIN_FORGOT_PASS_URL = '/login/forgot_password';
    const WSDL_URL = '/b2b_ws/wsdl';
    // magento urls
    const PRICE_URL = '/price';
    const PRICES_URL = 'sap/price/prices';

    /**
     * @var \Magento\Customer\Model\Session
     */
    private $session;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    private $urlBuilder;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Framework\UrlInterface $urlBuilder
     * @param \Magento\Customer\Model\Session $session
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\UrlInterface $urlBuilder,
        Session $session,
        StoreManagerInterface $storeManager
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->urlBuilder = $urlBuilder;
        $this->session = $session;
        $this->storeManager = $storeManager;
    }

    /**
     * @return string
     */
    public function getCartURL()
    {
        return $this->scopeConfig->getValue(self::CONFIG_WS_URL_PATH);
    }

    /**
     * @return string
     */
    public function getOrderURL()
    {
        return $this->getTokenizedCartUrl('cart');
    }

    /**
     * @return string
     */
    public function getWsUrl()
    {
        return $this->getCartURL() . self::WSDL_URL;
    }

    /**
     * @param string $target
     *
     * @return string
     */
    private function getTokenizedCartUrl($target)
    {
        $token = '';
        if ($corevistUser = $this->session->getCorevistUser()) {
            $token = $corevistUser->getToken();
        }

        $sapUrl = $this->getCartURL();
        $returnUrl = $this->storeManager->getStore()->getUrl();
        return sprintf(
            '%s/login/return_from_catalog?target=%s&token=%s&return_to_catalog_url=%s',
            $sapUrl,
            $target,
            $token,
            $returnUrl
        );
    }

    /**
     * @return string
     */
    public function getForgotPasswordUrl()
    {
        return $this->getCartURL() . self::LOGIN_FORGOT_PASS_URL;
    }

    /**
     * @return string
     */
    public function getHomeUrl()
    {
        return $this->getTokenizedCartUrl('home');
    }

    /**
     * @return string
     */
    public function getAccountUrl()
    {
        return $this->getTokenizedCartUrl('profile');
    }

    /**
     * @param Mage_Catalog_Model_Product $item Product
     * @param string $id Id of a product price HTML element
     *
     * @return string
     */
    public function getPriceUrl($item, $id)
    {
        $params = [];
        $params['sku'] = $item->getSku();
        $params['id'] = $id;
        return $this->urlBuilder->getUrl(self::PRICE_URL, $params);
    }

    /**
     * @return string
     */
    public function getPricesUrl()
    {
        $params = [];
        return $this->urlBuilder->getUrl(self::PRICES_URL, $params);
    }
}
