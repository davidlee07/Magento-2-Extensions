<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Model;

class Material extends AbstractModel
{
    /**
     * Initialize material model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Corevist\SAP\Model\ResourceModel\Material');
    }

    /**
     * Get materials info by skus
     *
     * @param array $skus
     *
     * @return \Corevist\SAP\Model\Webservice\Response
     */
    public function getMaterialsInfo(array $skus)
    {
        $cachedSkus = $this->getMaterialsFromSessionCache($skus);
        $absentSkus = array_values(array_diff($skus, array_keys($cachedSkus)));
        if (!empty($absentSkus)) {
            $newSkusData = $this->getMaterialsInfoFromSAP($absentSkus);
            foreach ($newSkusData as $index => $skuData) {
                try {
                    $sku = $skuData['material'] !== null ? $skuData['material'] : $skuData['error']['msg_v1'];
                } catch (\Exception $e) {
                    // skip item if it does not contain material number info even in error
                    continue;
                }
                $this->addMaterialInfoToSessionCache($sku, $skuData);
                // check to prevent unnecessary items to return
                // in case when they returned from corevist
                // like related items and so on
                if (in_array($sku, $absentSkus)) {
                    $cachedSkus[$sku] = $skuData;
                }
            }
        }
        return $cachedSkus;
    }

    /**
     * Get materials info from SAP by skus
     *
     * @param array $skus
     *
     * @return \Corevist\SAP\Model\Webservice\Response
     */
    private function getMaterialsInfoFromSAP(array $skus)
    {
        $materials = [];
        foreach ($skus as $sku) {
            $materials[] = ['material' => $sku, 'quantity' => 1];
        }

        $params = [
            'wsId' => $this->sapHelper->getWsId(),
            'token' => $this->sapHelper->getToken(),
            'materials' => $materials,
            'defaultLanguage' => $this->sapHelper->getDefaultLanguage()
        ];

        $response = $this->responseFactory->create();
        $this->getResource()->getMaterialsInfo($response, $params);
        return $response->getMaterialsInfo();
    }

    /**
     * Get materials info from session cache by skus
     *
     * @param array $skus
     *
     * @return array
     */
    private function getMaterialsFromSessionCache(array $skus)
    {
        $session = $this->sapHelper->getSession();
        $found = [];
        if ($cachedMaterials = $session->getCachedMaterials()) {
            foreach ($skus as $sku) {
                if (isset($cachedMaterials[$sku])) {
                    $found[$sku] = $cachedMaterials[$sku];
                }
            }
        }
        return $found;
    }

    /**
     * Add material info to session cache
     *
     * @param string $sku
     * @param array $data
     *
     * @return \Corevist\SAP\Model\Material;
     */
    private function addMaterialInfoToSessionCache($sku, $data)
    {
        $session = $this->sapHelper->getSession();
        if (!$cachedMaterials = $session->getCachedMaterials()) {
            $cachedMaterials = [];
        }
        $cachedMaterials[$sku] = $data;
        $session->setCachedMaterials($cachedMaterials);
        return $this;
    }
}
