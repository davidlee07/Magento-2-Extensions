<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the GNU General Public License v3 (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * @category Corevist
 * @package Corevist_SAP
 * @copyright  Copyright (c) 2016-2017 Corevist, Inc. (http://www.corevist.com)
 * @license    https://www.gnu.org/licenses/gpl-3.0.en.html GNU General Public License v3 (GPL 3.0)
 */

namespace Corevist\SAP\Helper;

use Corevist\SAP\Model\Webservice\ResponseInterface;
use \Magento\Framework\App\Helper\Context;
use \Magento\Customer\Model\Session;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    const CONFIG_ENABLED = 'sap/general/enabled';
    const CONFIG_SALES_AREA_PATH = 'sap/ws/sales_area';
    const CONFIG_LOGIN_HOME_PATH = 'sap/ws/login_home_redirect';
    const CONFIG_FORCED_LOGIN_PATH = 'sap/ws/forcelogin';
    const CONFIG_REGISTRATION_ENABLED = 'sap/ws/registration_enabled';
    const CONFIG_REGISTRATION_EMAIL = 'sap/ws/registration_email';
    const CONFIG_PRICING_ENABLED = 'sap/ws/pricing_enabled';
    const CONFIG_CART_PARAMS = 'sap/ws/cart_params';
    const CONFIG_HIDE_PRICES_WO_LOGIN = 'sap/ws/hide_prices_wo_login';
    const CONFIG_DUMMY_EMAILS = 'sap/ws/dummy_emails';

    const RESPONSE_CODE_SUCCESS = 0;

    const LOG_FILE = 'corevist_sap.log';

    const DEFAULT_LANGUAGE = 'en_US';
    const DEFAULT_DATE_FORMAT = 'mm/dd/yyyy';
    const DEFAULT_NUMBER_FORMAT = '#,###.###';

    /**
     * @var \Magento\Customer\Model\Session
     */
    private $session;

    /**
     * @var \Zend_Soap_Client
     */
    private $client;

    /**
     * @var \Corevist\SAP\Model\UserFactory
     */
    private $userFactory;

    /**
     * @var \Corevist\SAP\Model\Url
     */
    private $urlModel;

    /**
     * Data helper constructor.
     *
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Customer\Model\Session $session
     */
    public function __construct(
        Context $context,
        Session $session,
        \Corevist\SAP\Model\Url $urlModel
    ) {
        $this->session = $session;
        $this->urlModel = $urlModel;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Customer\Model\Session
     */
    public function getSession()
    {
        return $this->session;
    }

    /**
     * @return \Corevist\SAP\Model\Url
     */
    public function getUrlModel()
    {
        return $this->urlModel;
    }

    /**
     * @return bool
     */
    public function isIntegrationEnabled()
    {
        return $this->scopeConfig->getValue(self::CONFIG_ENABLED);
    }

    /**
     * @return bool
     */
    public function isRegistrationEnabled()
    {
        return (
            $this->scopeConfig->getValue(self::CONFIG_REGISTRATION_ENABLED)
            && $this->getRegistrationEmail()
        );
    }

    /**
     * @return string
     */
    public function getRegistrationEmail()
    {
        return $this->scopeConfig->getValue(self::CONFIG_REGISTRATION_EMAIL);
    }

    /**
     * @return bool
     */
    public function isHomeRedirectOnLogin()
    {
        return $this->scopeConfig->getValue(self::CONFIG_LOGIN_HOME_PATH);
    }

    /**
     * @return bool
     */
    public function isForcedLogin()
    {
        return $this->scopeConfig->getValue(self::CONFIG_FORCED_LOGIN_PATH);
    }

    /**
     * @return \Zend_Soap_Client
     */
    public function getSoapClient()
    {
        if (!$this->client) {
            $url = $this->getUrlModel()->getWsUrl();
            $this->client = new \Zend_Soap_Client($url, ['soapVersion' => SOAP_1_1]);
        }
        return $this->client;
    }

    /**
     * @return string
     */
    public function getWsId()
    {
        return "W" . mt_rand(100000000, 999999999);
    }

    /**
     * @return string
     */
    public function getSalesArea()
    {
        return $this->scopeConfig->getValue(self::CONFIG_SALES_AREA_PATH);
    }

    /**
     * @return string
     */
    public function getExtraAddToCartParams()
    {
        return $this->scopeConfig->getValue(self::CONFIG_CART_PARAMS);
    }

    /**
     * @return string
     */
    public function getDefaultLanguage()
    {
        return self::DEFAULT_LANGUAGE;
    }

    /**
     * @return string
     */
    public function getDateFormat()
    {
        return self::DEFAULT_DATE_FORMAT;
    }

    /**
     * @return string
     */
    public function getNumberFormat()
    {
        return self::DEFAULT_NUMBER_FORMAT;
    }

    /**
     * @return bool
     */
    public function isCorevistUser()
    {
        return $this->getCorevistUser() != null;
    }

    /**
     * @return \Corevist\SAP\Model\User|null
     */
    public function getCorevistUser()
    {
        return $this->session->getCorevistUser();
    }

    /**
     * Returns SAP token from session if it exists
     *
     * @return string
     */
    public function getToken()
    {
        if ($corevistUser = $this->getCorevistUser()) {
            return $corevistUser->getToken();
        }
        return '';
    }

    /**
     * Check if corevist pricing is enabled
     *
     * @return bool
     */
    public function isCorevistPricing()
    {
        return $this->scopeConfig->getValue(self::CONFIG_PRICING_ENABLED);
    }

    /**
     * Check if prices should be hidden for non logged users
     *
     * @return bool
     */
    public function isHidePricesWoLogin()
    {
        return $this->scopeConfig->getValue(self::CONFIG_HIDE_PRICES_WO_LOGIN);
    }

    /**
     * Check if it is necessary to use dummy emails for customer creation in Magento
     *
     * @return bool
     */
    public function isCustomersWithNonUniqueEmailsAllowed()
    {
        return $this->scopeConfig->getValue(self::CONFIG_DUMMY_EMAILS);
    }

    /**
     * Trim message starting from html tag
     *
     * @param string $message
     *
     * @return string
     */
    public function trimResultMessage($message = '')
    {
        if (strpos($message, 'msg|') !== false) {
            return '';
        }
        $trunk = strpos($message, "<");
        if ($trunk !== false) {
            $message = substr($message, 0, $trunk);
        }

        return $message;
    }

    /**
     * Returns SAP request error if there is one
     *
     * @param ResponseInterface $response
     * @param string $default
     *
     * @return string
     */
    public function getSAPError($response, $default = '')
    {
        $returnCode = $response->getReturnCode();
        if ($returnCode !== self::RESPONSE_CODE_SUCCESS) {
            if ($returnCode == 7 || $returnCode == 9) {
                return __(
                    'Sorry, there was a problem processing your request. Please try again.' .
                    ' If the problem persists, please contact Customer Support.'
                );
            } elseif ($returnCode == 8) {
                return __(
                    'Sorry, our ordering system is currently not available. We expect it to be back up in %1 hour(s).',
                    $response->getReturnValue() / 2.0
                );
            } else {
                return __($this->trimResultMessage($response->getMessage()));
            }
        }

        return $default;
    }
}
