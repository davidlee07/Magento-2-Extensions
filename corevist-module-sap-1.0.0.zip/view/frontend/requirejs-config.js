/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            catalogAddToCart: 'Magento_Catalog/js/catalog-add-to-cart'
        }
    }
};
