define([
    "jquery",
    "Magento_Customer/js/customer-data"
], function ($, customerData) {
    'use strict';

    /**
     * @returns {boolean}
     */
    var checkParam = function () {
        return (document.location.search.indexOf('b2b_cart_items') !== -1);
    };

    return function () {
        if (checkParam()) {
            $('[data-block="minicart"]').trigger('contentLoading');
            customerData.reload(['cart'], true);
        }
    }
});
