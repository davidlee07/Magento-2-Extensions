define([
    "jquery",
    "Magento_Customer/js/customer-data",
    "mage/translate"
], function ($, customerData, $t) {
    'use strict';

    function Sap_Pricing_Loader(config) {
        this._requestUrl = config.requestUrl;
        this._productsSkus = [];
        this._pricesElements = [];
        this._init();
        this._loadPrices();
    }

    Sap_Pricing_Loader.prototype = {

        constructor: Sap_Pricing_Loader,

        /**
         * @var Array
         */
        _productsSkus: null,

        /**
         * @var Array
         */
        _pricesElements: null,

        /**
         * @var Object
         */
        _sessionStorage: null,

        /**
         * @var string
         */
        _requestUrl: '',

        _init: function () {
            this._pricesElements = $('div.price-loading');
            this._pricesElements.each(function (index, element) {
                this._productsSkus.push($(element).data('product-sku'))
            }.bind(this));
        },

        /**
         * Make request to server and then to SAP to get actual prices
         *
         * @private
         */
        _loadPrices: function () {
            if (!this._productsSkus.length) {
                // nothing to load
                return;
            }
            try {
                $.ajax({
                    type: "POST",
                    url: this._requestUrl,
                    data: {skus: this._productsSkus.join()},
                    success: this._onRequestSuccess.bind(this),
                    error: this._onRequestFailure.bind(this)
                })
            } catch (Error) {
                this._onRequestFailure({});
            }
        },

        /**
         * Process request result
         *
         * @param response
         * @private
         */
        _onRequestSuccess: function (response) {
            if (response.status == true) {
                this._updatePrices(response.prices)
            } else {
                this._onRequestFailure(response);
            }
        },

        /**
         * Display error message if ajax call fails or returned an error
         *
         * @param response
         * @private
         */
        _onRequestFailure: function (response) {
            this._pricesElements.html('N/A');
            customerData.set('messages', {
                data_id: Math.round(Date.now() / 1000),
                messages: [
                    {type: 'error', text: $.mage.__('Sorry, prices are temporary unavailable.')}
                ]
            });
            this._updatePrices({});
        },

        /**
         * Update products' prices with data received
         *
         * @param prices
         * @private
         */
        _updatePrices: function (prices) {
            this._pricesElements.each(function (index, element) {
                var sku = $(element).data('product-sku');
                if (prices[sku] != undefined) {
                    $(element).html(prices[sku]);
                } else {
                    $(element).html('N/A');
                }
                $(element).removeClass('price-loading');
            }.bind(this));
        }
    };

    return function (config, node) {
        return new Sap_Pricing_Loader(config, node);
    };
});
