<?php
/**
 * @package 
 * @author Stefan richter (richter@aromicon.com)
 * @license aromicon gmbh 2013
 */ 
namespace Universal\Chat\Helper;

use Magento\Store\Model\Store;

class Data extends \Magento\Framework\App\Helper\AbstractHelper {
        
	/**
     * System config XML paths
     */

    const XML_HTML_WIDGET_CODE = 'comelite/universal_chat/html_widget_code';
	
	/**
     * Retrieve Html Widget Code
     *
     * @param null|string|bool|int|Store $store
     * @return int
     */
    public function getHtmlWidgetCode($store = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_HTML_WIDGET_CODE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $store
        );			
    }	
}