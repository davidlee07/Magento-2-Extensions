<?php
namespace Universal\Chat\Block;

class Chat extends \Magento\Framework\View\Element\Template
{

    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\CollectionFactory
     */
    protected $salesResourceModelOrderCollectionFactory;

    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $catalogProductFactory;

    /**
     * @var \Magento\Catalog\Model\CategoryFactory
     */
    protected $catalogCategoryFactory;

    /**
     * @var \Magento\Checkout\Model\CartFactory
     */
    protected $checkoutCartFactory;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $registry;    
	
	/**
     * Universal data helper
     *
     * @var \Universal\Chat\Helper\Data
     */
    protected $_dataHelper = null;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $salesResourceModelOrderCollectionFactory,
        \Magento\Catalog\Model\ProductFactory $catalogProductFactory,
        \Magento\Catalog\Model\CategoryFactory $catalogCategoryFactory,
        \Magento\Checkout\Model\CartFactory $checkoutCartFactory,
        \Magento\Framework\Registry $registry,        
		\Universal\Chat\Helper\Data $dataHelper,
        array $data = []
    ) {
        $this->salesResourceModelOrderCollectionFactory = $salesResourceModelOrderCollectionFactory;
        $this->catalogProductFactory = $catalogProductFactory;
        $this->catalogCategoryFactory = $catalogCategoryFactory;
        $this->checkoutCartFactory = $checkoutCartFactory;
        $this->registry = $registry;        
		$this->_dataHelper = $dataHelper;
        parent::__construct(
            $context,
            $data
        );
    }
    
	protected function _getOrdersTrackingCode()
    {
        $orderIds = $this->getOrderIds();
        if (empty($orderIds) || !is_array($orderIds)) {
            return "";
        }	
		
        $collection = $this->salesResourceModelOrderCollectionFactory->create()
            ->addFieldToFilter('entity_id', array('in' => $orderIds));
        $result = array();

        foreach ($collection as $order) {
            foreach ($order->getAllVisibleItems() as $item) {

                //get category name
                $productId = $item->product_id;
                $product = $this->catalogProductFactory->create()->load($productId);
                $categoryName = '';
                $categoryIds = $product->getCategoryIds();
                if (!empty($categoryIds)) {
                    $categoryId = $categoryIds[0];
                    $category = $this->catalogCategoryFactory->create()->load($categoryId);
                    $categoryName = $category->getName();
                }

                if ($item->getQtyOrdered()) {
                    $qty = number_format($item->getQtyOrdered(), 0, '.', '');
                } else {
                    $qty = '0';
                }
                $result[] = sprintf("_paq.push(['addEcommerceItem', '%s', '%s', '%s', %s, %s]);",
                    $this->jsQuoteEscape($item->getSku()),
                    $this->jsQuoteEscape($item->getName()),
                    $categoryName,
                    $item->getBasePrice(),
                    $qty
                );

            }
             
			if ($order->getGrandTotal()) {
				$subtotal = $order->getGrandTotal() - $order->getShippingAmount() - $order->getShippingTaxAmount();
			} else {
				$subtotal = '0.00';
			}
			$result[] = sprintf("_paq.push(['trackEcommerceOrder' , '%s', %s, %s, %s, %s]);",
				$order->getIncrementId(),
				$order->getBaseGrandTotal(),
				$subtotal,
				$order->getBaseTaxAmount(),
				$order->getBaseShippingAmount()
			);
           
        }
        return implode("\n", $result);
    }

    /**
     * Render information when cart updated
     * http://piwik.org/docs/ecommerce-analytics/
     */
    protected function _getEcommerceCartUpdate()
    {
		$ecommerceCartUpdate = "";
		
        $cart = $this->checkoutCartFactory->create()->getQuote()->getAllVisibleItems();

        foreach ($cart as $cartItem) {

            //get category name
            $productId = $cartItem->product_id;
            $product = $this->catalogProductFactory->create()->load($productId);
            $categoryName = '';
            $categoryIds = $product->getCategoryIds();
            if (!empty($categoryIds)) {
                $categoryId = $categoryIds[0];
                $category = $this->catalogCategoryFactory->create()->load($categoryId);
                $categoryName = $category->getName();
            }
            $productName = $cartItem->getName();
            $productName = str_replace('"', "", $productName);

            if ($cartItem->getPrice() == 0 || $cartItem->getPrice() < 0.00001):
                continue;
            endif;

            $ecommerceCartUpdate .= "_paq.push(['addEcommerceItem', " . json_encode($cartItem->getSku()) . ", " . json_encode($productName) . ", " . json_encode($categoryName) . ", " . $cartItem->getPrice() . ", " . $cartItem->getQty() . "]);";
            $ecommerceCartUpdate .=  "\n";
        }

        //total in cart
        $grandTotal = $this->checkoutCartFactory->create()->getQuote()->getGrandTotal();
        if ($grandTotal != 0) {
            $ecommerceCartUpdate .= "_paq.push(['trackEcommerceCartUpdate', " . $grandTotal . "]);";
            $ecommerceCartUpdate .= "\n";
        }
		
		return $ecommerceCartUpdate;
    }

    /**
     * Render information when product page view
     * http://piwik.org/docs/ecommerce-analytics/
     */
    protected function _getProductPageview()
    {
		$ecommerceProductPageview = "";
	
        $currentProduct = $this->registry->registry('current_product');

        if (!($currentProduct instanceof \Magento\Catalog\Model\Product)) {
            return "";
        }

        $productId = $currentProduct->getId();
        $product = $this->catalogProductFactory->create()->load($productId);
        $categoryName = '';
        $categoryIds = $product->getCategoryIds();
        if (!empty($categoryIds)) {
            $categoryId = $categoryIds[0];
            $category = $this->catalogCategoryFactory->create()->load($categoryId);
            $categoryName = $category->getName();
        }
        $productName = $currentProduct->getName();

        $ecommerceProductPageview = "_paq.push(['setEcommerceView', " . json_encode($currentProduct->getSku()) . ", " . json_encode($productName) . ", " . json_encode($categoryName) . ", " . $currentProduct->getPrice() . " ]);";
        $this->registry->unregister('current_category');
		
		return $ecommerceProductPageview;
    }

    /**
     * Render information of category view
     * http://piwik.org/docs/ecommerce-analytics/
     */
    protected function _getCategoryPageview()
    {
		$ecommerceCategoryPageview = "";
		
        $currentCategory = $this->registry->registry('current_category');

        if (!($currentCategory instanceof \Magento\Catalog\Model\Category)) {
            return;
        }
        $ecommerceCategoryPageview = "_paq.push(['setEcommerceView', false, false, " . json_encode($currentCategory->getName()) . "]);";
        $this->registry->unregister('current_product');
		
		return $ecommerceCategoryPageview;
    }

	public function getCode()
    {
		$ecommerceText = "var _paq = _paq || [];" . $this->_getOrdersTrackingCode() . $this->_getEcommerceCartUpdate() . $this->_getProductPageview() . $this->_getCategoryPageview();	
		
        $htmlWidgetCode = $this->_dataHelper->getHtmlWidgetCode();	
		$htmlWidgetCode = str_replace("var _paq = _paq || [];", $ecommerceText, $htmlWidgetCode);		
			
		return $htmlWidgetCode;
    } 
}